# Overview

This is an AI-powered scientific assistant for antimicrobial discovery and wound-healing formulation research. The application combines a comprehensive phytochemical database with machine learning analysis to help researchers identify promising plant-based compounds for medical applications. It features plant-compound relationship mapping, multi-evidence scoring systems, literature integration, and specialized wound-type matching algorithms for evidence-based formulation development.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture
The application uses Streamlit as the primary web framework with a multi-page architecture. The main entry point (`app.py`) provides a dashboard overview, while specialized functionality is organized into separate pages under the `pages/` directory:
- Phytochemical Database interface for plant and compound searches
- AI Analysis module for antimicrobial potential assessment
- Plant-Wound Matching algorithm for targeted formulation
- Admin Panel for data management
- Literature Integration for research citation management

The UI follows a sidebar navigation pattern with metrics-based dashboard visualization using Plotly for interactive charts and graphs.

## Backend Architecture
The application follows a modular service-oriented design with specialized modules for different scientific functions:

**Database Layer**: `database.py` handles all PostgreSQL interactions using psycopg2 with connection pooling and context managers for safe transaction handling.

**Core Services**:
- `phytochemical_db.py`: Plant and compound data management with search and filtering capabilities
- `ai_analysis.py`: OpenAI GPT-5 integration for antimicrobial potential analysis with result caching
- `scoring_system.py`: Multi-evidence scoring combining QSAR/ML predictions, literature data, ADMET properties, and docking scores
- `literature_integration.py`: Scientific publication search using CrossRef and PubMed APIs
- `admin_panel.py`: Administrative interface with authentication for data management

**Utility Layer**: `utils.py` provides validation functions for chemical formulas, DOIs, and SMILES notation along with data formatting utilities.

## Data Storage Solutions
The application uses PostgreSQL as the primary database with a relational schema designed for scientific data:
- Plants table for botanical species information
- Phytochemicals table for compound molecular data
- Plant-compounds relationship table for linking species to their chemical constituents
- AI analysis cache for storing computational results with expiration timestamps
- Literature references with DOI validation and citation metadata

The database initialization includes automatic schema creation with proper indexing for search operations.

## Authentication and Authorization
Simple password-based authentication is implemented for the admin panel (demo password: "admin123"). The system uses session state management to maintain authentication status. In production, this should be replaced with proper user management and environment-variable-based password storage.

## External Dependencies

**APIs and Services**:
- OpenAI API for GPT-5 powered scientific analysis and formulation recommendations
- CrossRef API for publication metadata and DOI validation
- PubMed E-utilities for biomedical literature search
- All API integrations include proper rate limiting and error handling

**Machine Learning**:
- scikit-learn for QSAR modeling and multi-evidence scoring
- Random Forest models for compound activity prediction
- MinMax scaling for feature normalization

**Data Visualization**:
- Plotly Express and Plotly Graph Objects for interactive scientific charts
- Streamlit native components for metrics and dashboard elements

**Database**:
- PostgreSQL with psycopg2 driver
- Environment variable configuration for connection parameters
- Transaction management with rollback capabilities

**Scientific Computing**:
- pandas for data manipulation and analysis
- numpy for numerical computations
- Chemical formula and SMILES validation utilities