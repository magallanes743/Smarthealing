import pandas as pd
import streamlit as st
from database import execute_query, insert_data, update_data
import plotly.express as px
import plotly.graph_objects as go

def get_plant_overview_stats():
    """Get overview statistics for the dashboard"""
    try:
        plants_count = execute_query("SELECT COUNT(*) as count FROM plants")
        compounds_count = execute_query("SELECT COUNT(*) as count FROM phytochemicals")
        studies_count = execute_query("SELECT COUNT(DISTINCT reference_study) as count FROM plant_compounds WHERE reference_study IS NOT NULL")
        
        return {
            'total_plants': plants_count.iloc[0]['count'] if not plants_count.empty else 0,
            'total_compounds': compounds_count.iloc[0]['count'] if not compounds_count.empty else 0,
            'total_studies': studies_count.iloc[0]['count'] if not studies_count.empty else 0
        }
    except Exception as e:
        st.error(f"Error getting overview stats: {str(e)}")
        return {'total_plants': 0, 'total_compounds': 0, 'total_studies': 0}

def search_plants(search_term="", family_filter="", activity_filter=""):
    """Search plants based on various criteria"""
    base_query = """
        SELECT DISTINCT p.id, p.scientific_name, p.common_name, p.family, 
               p.traditional_use, COUNT(pc.phytochemical_id) as compound_count
        FROM plants p
        LEFT JOIN plant_compounds pc ON p.id = pc.plant_id
        WHERE 1=1
    """
    
    params = []
    
    if search_term:
        base_query += " AND (LOWER(p.scientific_name) LIKE LOWER(%s) OR LOWER(p.common_name) LIKE LOWER(%s))"
        params.extend([f"%{search_term}%", f"%{search_term}%"])
    
    if family_filter:
        base_query += " AND LOWER(p.family) = LOWER(%s)"
        params.append(family_filter)
    
    if activity_filter:
        base_query += """ AND p.id IN (
            SELECT DISTINCT pc2.plant_id 
            FROM plant_compounds pc2 
            JOIN phytochemicals ph ON pc2.phytochemical_id = ph.id 
            WHERE LOWER(ph.biological_activity) LIKE LOWER(%s)
        )"""
        params.append(f"%{activity_filter}%")
    
    base_query += " GROUP BY p.id, p.scientific_name, p.common_name, p.family, p.traditional_use ORDER BY p.scientific_name"
    
    return execute_query(base_query, params)

def get_plant_details(plant_id):
    """Get detailed information about a specific plant"""
    plant_query = """
        SELECT * FROM plants WHERE id = %s
    """
    plant_data = execute_query(plant_query, (plant_id,))
    
    if plant_data.empty:
        return None, pd.DataFrame(), pd.DataFrame()
    
    # Get compounds for this plant
    compounds_query = """
        SELECT ph.name, ph.chemical_formula, ph.molecular_weight, 
               ph.chemical_class, ph.biological_activity,
               pc.concentration_range, pc.extraction_method, pc.reference_study
        FROM phytochemicals ph
        JOIN plant_compounds pc ON ph.id = pc.phytochemical_id
        WHERE pc.plant_id = %s
        ORDER BY ph.name
    """
    compounds_data = execute_query(compounds_query, (plant_id,))
    
    # Get antimicrobial activity data
    activity_query = """
        SELECT aa.pathogen_name, aa.pathogen_type, aa.mic_value, 
               aa.zoi_value, aa.test_method, aa.reference_doi, aa.confidence_score,
               ph.name as compound_name
        FROM antimicrobial_activity aa
        JOIN phytochemicals ph ON aa.compound_id = ph.id
        JOIN plant_compounds pc ON ph.id = pc.phytochemical_id
        WHERE pc.plant_id = %s
        ORDER BY aa.pathogen_name
    """
    activity_data = execute_query(activity_query, (plant_id,))
    
    return plant_data.iloc[0], compounds_data, activity_data

def get_phytochemical_families():
    """Get list of chemical families for filtering"""
    query = """
        SELECT DISTINCT chemical_class 
        FROM phytochemicals 
        WHERE chemical_class IS NOT NULL 
        ORDER BY chemical_class
    """
    result = execute_query(query)
    return result['chemical_class'].tolist() if not result.empty else []

def get_plant_families():
    """Get list of plant families for filtering"""
    query = """
        SELECT DISTINCT family 
        FROM plants 
        WHERE family IS NOT NULL 
        ORDER BY family
    """
    result = execute_query(query)
    return result['family'].tolist() if not result.empty else []

def search_compounds(search_term="", chemical_class_filter="", activity_filter=""):
    """Search phytochemicals based on various criteria"""
    base_query = """
        SELECT ph.id, ph.name, ph.chemical_formula, ph.molecular_weight,
               ph.chemical_class, ph.biological_activity,
               COUNT(DISTINCT pc.plant_id) as plant_count,
               COUNT(DISTINCT aa.id) as activity_records
        FROM phytochemicals ph
        LEFT JOIN plant_compounds pc ON ph.id = pc.phytochemical_id
        LEFT JOIN antimicrobial_activity aa ON ph.id = aa.compound_id
        WHERE 1=1
    """
    
    params = []
    
    if search_term:
        base_query += " AND LOWER(ph.name) LIKE LOWER(%s)"
        params.append(f"%{search_term}%")
    
    if chemical_class_filter:
        base_query += " AND LOWER(ph.chemical_class) = LOWER(%s)"
        params.append(chemical_class_filter)
    
    if activity_filter:
        base_query += " AND LOWER(ph.biological_activity) LIKE LOWER(%s)"
        params.append(f"%{activity_filter}%")
    
    base_query += " GROUP BY ph.id, ph.name, ph.chemical_formula, ph.molecular_weight, ph.chemical_class, ph.biological_activity ORDER BY ph.name"
    
    return execute_query(base_query, params)

def get_compound_details(compound_id):
    """Get detailed information about a specific compound"""
    compound_query = """
        SELECT * FROM phytochemicals WHERE id = %s
    """
    compound_data = execute_query(compound_query, (compound_id,))
    
    if compound_data.empty:
        return None, pd.DataFrame(), pd.DataFrame(), pd.DataFrame(), pd.DataFrame()
    
    # Get plants containing this compound
    plants_query = """
        SELECT p.scientific_name, p.common_name, p.family,
               pc.concentration_range, pc.extraction_method, pc.reference_study
        FROM plants p
        JOIN plant_compounds pc ON p.id = pc.plant_id
        WHERE pc.phytochemical_id = %s
        ORDER BY p.scientific_name
    """
    plants_data = execute_query(plants_query, (compound_id,))
    
    # Get antimicrobial activity
    activity_query = """
        SELECT pathogen_name, pathogen_type, mic_value, zoi_value,
               test_method, reference_doi, confidence_score
        FROM antimicrobial_activity
        WHERE compound_id = %s
        ORDER BY pathogen_name
    """
    activity_data = execute_query(activity_query, (compound_id,))
    
    # Get ADMET properties
    admet_query = """
        SELECT absorption, distribution, metabolism, excretion,
               toxicity_score, skin_permeability, solubility,
               predicted, prediction_confidence
        FROM admet_properties
        WHERE compound_id = %s
    """
    admet_data = execute_query(admet_query, (compound_id,))
    
    # Get docking results
    docking_query = """
        SELECT target_protein, binding_affinity, rmsd,
               docking_software, protein_pdb_id, ligand_efficiency
        FROM docking_results
        WHERE compound_id = %s
        ORDER BY binding_affinity DESC
    """
    docking_data = execute_query(docking_query, (compound_id,))
    
    return compound_data.iloc[0], plants_data, activity_data, admet_data, docking_data

def create_activity_visualization(activity_data):
    """Create visualization for antimicrobial activity data"""
    if activity_data.empty:
        return None
    
    # MIC values visualization
    mic_data = activity_data[activity_data['mic_value'].notna()]
    if not mic_data.empty:
        fig_mic = px.bar(
            mic_data, 
            x='pathogen_name', 
            y='mic_value',
            color='pathogen_type',
            title='Minimum Inhibitory Concentration (MIC) Values',
            labels={'mic_value': 'MIC (µg/mL)', 'pathogen_name': 'Pathogen'}
        )
        fig_mic.update_layout(xaxis_tickangle=-45)
        return fig_mic
    
    return None

def create_compound_distribution_chart():
    """Create chart showing distribution of compounds by chemical class"""
    query = """
        SELECT chemical_class, COUNT(*) as count
        FROM phytochemicals
        WHERE chemical_class IS NOT NULL
        GROUP BY chemical_class
        ORDER BY count DESC
        LIMIT 15
    """
    
    data = execute_query(query)
    
    if data.empty:
        return None
    
    fig = px.pie(
        data, 
        values='count', 
        names='chemical_class',
        title='Distribution of Phytochemicals by Chemical Class'
    )
    
    return fig

def create_plant_family_chart():
    """Create chart showing distribution of plants by family"""
    query = """
        SELECT family, COUNT(*) as count
        FROM plants
        WHERE family IS NOT NULL
        GROUP BY family
        ORDER BY count DESC
        LIMIT 15
    """
    
    data = execute_query(query)
    
    if data.empty:
        return None
    
    fig = px.bar(
        data, 
        x='family', 
        y='count',
        title='Plant Species by Family',
        labels={'count': 'Number of Species', 'family': 'Plant Family'}
    )
    fig.update_layout(xaxis_tickangle=-45)
    
    return fig

def get_activity_heatmap_data():
    """Get data for pathogen-compound activity heatmap"""
    query = """
        SELECT ph.name as compound_name, aa.pathogen_name, 
               CASE 
                   WHEN aa.mic_value IS NOT NULL THEN -LOG10(aa.mic_value/1000000) 
                   ELSE NULL 
               END as log_mic_inverse
        FROM antimicrobial_activity aa
        JOIN phytochemicals ph ON aa.compound_id = ph.id
        WHERE aa.mic_value IS NOT NULL
        ORDER BY ph.name, aa.pathogen_name
    """
    
    return execute_query(query)

def create_activity_heatmap():
    """Create heatmap of antimicrobial activities"""
    data = get_activity_heatmap_data()
    
    if data.empty:
        return None
    
    # Pivot data for heatmap
    heatmap_data = data.pivot(
        index='compound_name', 
        columns='pathogen_name', 
        values='log_mic_inverse'
    )
    
    if heatmap_data.empty:
        return None
    
    fig = go.Figure(data=go.Heatmap(
        z=heatmap_data.values,
        x=heatmap_data.columns,
        y=heatmap_data.index,
        colorscale='Viridis',
        colorbar=dict(title="Activity Score<br>(-log MIC)")
    ))
    
    fig.update_layout(
        title='Antimicrobial Activity Heatmap',
        xaxis_title='Pathogen',
        yaxis_title='Compound',
        xaxis_tickangle=-45
    )
    
    return fig
