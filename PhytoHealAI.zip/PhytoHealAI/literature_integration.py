import streamlit as st
import pandas as pd
import json
import requests
from database import execute_query, insert_data
from utils import validate_doi
import time
import xml.etree.ElementTree as ET
from typing import Dict, List, Optional

class LiteratureIntegrator:
    """
    Integration with scientific literature databases and citation management
    """
    
    def __init__(self):
        self.crossref_api = "https://api.crossref.org/works/"
        self.pubmed_api = "https://eutils.ncbi.nlm.nih.gov/entrez/eutils/"
        
    def search_crossref(self, doi: str) -> Optional[Dict]:
        """
        Search CrossRef database for publication information
        
        Args:
            doi: Digital Object Identifier
            
        Returns:
            Dictionary with publication metadata or None if not found
        """
        try:
            if not validate_doi(doi):
                return None
            
            url = f"{self.crossref_api}{doi}"
            headers = {'User-Agent': 'Antimicrobial-Research-Assistant/1.0'}
            
            response = requests.get(url, headers=headers, timeout=10)
            
            if response.status_code == 200:
                data = response.json()
                work = data.get('message', {})
                
                # Extract relevant information
                authors = []
                if 'author' in work:
                    for author in work['author']:
                        given = author.get('given', '')
                        family = author.get('family', '')
                        authors.append(f"{given} {family}".strip())
                
                return {
                    'doi': work.get('DOI', doi),
                    'title': work.get('title', [''])[0] if work.get('title') else '',
                    'authors': ', '.join(authors),
                    'journal': work.get('container-title', [''])[0] if work.get('container-title') else '',
                    'publication_year': work.get('published-print', {}).get('date-parts', [[None]])[0][0] or 
                                      work.get('published-online', {}).get('date-parts', [[None]])[0][0],
                    'abstract': work.get('abstract', ''),
                    'url': work.get('URL', ''),
                    'type': work.get('type', ''),
                    'subject': work.get('subject', [])
                }
            
            return None
            
        except Exception as e:
            st.error(f"CrossRef search error: {str(e)}")
            return None
    
    def search_pubmed(self, query: str, max_results: int = 10) -> List[Dict]:
        """
        Search PubMed database for relevant publications
        
        Args:
            query: Search query
            max_results: Maximum number of results to return
            
        Returns:
            List of publication dictionaries
        """
        try:
            # Search for PMIDs
            search_url = f"{self.pubmed_api}esearch.fcgi"
            search_params = {
                'db': 'pubmed',
                'term': query,
                'retmax': max_results,
                'retmode': 'json'
            }
            
            search_response = requests.get(search_url, params=search_params, timeout=10)
            
            if search_response.status_code != 200:
                return []
            
            search_data = search_response.json()
            pmids = search_data.get('esearchresult', {}).get('idlist', [])
            
            if not pmids:
                return []
            
            # Fetch detailed information
            fetch_url = f"{self.pubmed_api}efetch.fcgi"
            fetch_params = {
                'db': 'pubmed',
                'id': ','.join(pmids),
                'retmode': 'xml'
            }
            
            fetch_response = requests.get(fetch_url, params=fetch_params, timeout=15)
            
            if fetch_response.status_code == 200:
                # Parse XML response
                return self._parse_pubmed_xml(fetch_response.text)
            
            return []
            
        except Exception as e:
            st.error(f"PubMed search error: {str(e)}")
            return []
    
    def _parse_pubmed_xml(self, xml_content: str) -> List[Dict]:
        """
        Parse PubMed XML response to extract article information
        
        Args:
            xml_content: Raw XML response from PubMed EFetch
            
        Returns:
            List of parsed article dictionaries
        """
        try:
            root = ET.fromstring(xml_content)
            results = []
            
            # Find all PubmedArticle elements
            for article in root.findall('.//PubmedArticle'):
                article_data = {}
                
                # Extract PMID
                pmid_elem = article.find('.//PMID')
                article_data['pmid'] = pmid_elem.text if pmid_elem is not None else None
                
                # Extract title
                title_elem = article.find('.//ArticleTitle')
                article_data['title'] = title_elem.text if title_elem is not None else 'No title'
                
                # Extract authors
                authors = []
                author_list = article.find('.//AuthorList')
                if author_list is not None:
                    for author in author_list.findall('.//Author'):
                        last_name = author.find('.//LastName')
                        first_name = author.find('.//ForeName')
                        initials = author.find('.//Initials')
                        
                        if last_name is not None:
                            author_name = last_name.text
                            if first_name is not None:
                                author_name += f" {first_name.text}"
                            elif initials is not None:
                                author_name += f" {initials.text}"
                            authors.append(author_name)
                
                article_data['authors'] = ', '.join(authors) if authors else 'No authors listed'
                
                # Extract journal information
                journal_elem = article.find('.//Journal/Title')
                if journal_elem is None:
                    journal_elem = article.find('.//Journal/ISOAbbreviation')
                article_data['journal'] = journal_elem.text if journal_elem is not None else 'Unknown journal'
                
                # Extract publication year
                pub_date = article.find('.//PubDate/Year')
                if pub_date is None:
                    pub_date = article.find('.//PubDate/MedlineDate')
                    if pub_date is not None:
                        # Extract year from MedlineDate format like "2023 Jan-Mar"
                        date_text = pub_date.text
                        year_match = date_text.split()[0] if date_text else None
                        try:
                            article_data['publication_year'] = int(year_match) if year_match and year_match.isdigit() else None
                        except (ValueError, AttributeError):
                            article_data['publication_year'] = None
                    else:
                        article_data['publication_year'] = None
                else:
                    try:
                        article_data['publication_year'] = int(pub_date.text)
                    except (ValueError, TypeError):
                        article_data['publication_year'] = None
                
                # Extract abstract
                abstract_elem = article.find('.//Abstract/AbstractText')
                if abstract_elem is not None:
                    # Handle structured abstracts
                    abstract_parts = []
                    for abstract_text in article.findall('.//Abstract/AbstractText'):
                        label = abstract_text.get('Label')
                        text = abstract_text.text or ''
                        if label:
                            abstract_parts.append(f"{label}: {text}")
                        else:
                            abstract_parts.append(text)
                    article_data['abstract'] = ' '.join(abstract_parts)
                else:
                    article_data['abstract'] = 'No abstract available'
                
                # Extract DOI if available
                doi_elem = article.find('.//ArticleId[@IdType="doi"]')
                article_data['doi'] = doi_elem.text if doi_elem is not None else None
                
                results.append(article_data)
            
            return results
            
        except ET.ParseError as e:
            st.error(f"XML parsing error: {str(e)}")
            return []
        except Exception as e:
            st.error(f"Error parsing PubMed XML: {str(e)}")
            return []
    
    def extract_antimicrobial_mentions(self, text: str) -> Dict:
        """
        Extract mentions of antimicrobial activity from text using simple patterns
        
        Args:
            text: Text to analyze
            
        Returns:
            Dictionary with extracted information
        """
        text_lower = text.lower()
        
        # Simple pattern matching for antimicrobial terms
        antimicrobial_terms = [
            'antimicrobial', 'antibacterial', 'antifungal', 'antiviral',
            'mic', 'minimum inhibitory concentration', 'zone of inhibition',
            'bactericidal', 'fungicidal', 'pathogen'
        ]
        
        pathogen_patterns = [
            'staphylococcus', 'streptococcus', 'escherichia', 'pseudomonas',
            'candida', 'aspergillus', 'salmonella', 'bacillus'
        ]
        
        found_terms = []
        found_pathogens = []
        
        for term in antimicrobial_terms:
            if term in text_lower:
                found_terms.append(term)
        
        for pathogen in pathogen_patterns:
            if pathogen in text_lower:
                found_pathogens.append(pathogen)
        
        return {
            'antimicrobial_terms': found_terms,
            'mentioned_pathogens': found_pathogens,
            'relevance_score': len(found_terms) + len(found_pathogens) * 2
        }
    
    def validate_citation(self, reference_data: Dict) -> Dict:
        """
        Validate citation information and check for completeness
        
        Args:
            reference_data: Dictionary with reference information
            
        Returns:
            Dictionary with validation results
        """
        validation_results = {
            'is_valid': True,
            'warnings': [],
            'errors': [],
            'completeness_score': 0
        }
        
        required_fields = ['title']
        important_fields = ['authors', 'journal', 'publication_year', 'doi']
        
        # Check required fields
        for field in required_fields:
            if not reference_data.get(field):
                validation_results['errors'].append(f"Missing required field: {field}")
                validation_results['is_valid'] = False
        
        # Check important fields
        for field in important_fields:
            if reference_data.get(field):
                validation_results['completeness_score'] += 1
        
        validation_results['completeness_score'] = (
            validation_results['completeness_score'] / len(important_fields)
        ) * 100
        
        # Validate DOI format if present
        if reference_data.get('doi') and not validate_doi(reference_data['doi']):
            validation_results['warnings'].append("DOI format may be invalid")
        
        # Check publication year reasonableness
        pub_year = reference_data.get('publication_year')
        if pub_year and (pub_year < 1900 or pub_year > 2025):
            validation_results['warnings'].append("Publication year seems unrealistic")
        
        return validation_results

def search_literature_interface():
    """Interface for searching scientific literature"""
    st.subheader("🔍 Literature Search")
    
    integrator = LiteratureIntegrator()
    
    search_type = st.selectbox(
        "Search Type",
        ["DOI Lookup", "PubMed Search", "Local Database Search"]
    )
    
    if search_type == "DOI Lookup":
        st.subheader("📄 DOI Lookup")
        
        doi_input = st.text_input(
            "Enter DOI",
            help="e.g., 10.1016/j.phymed.2023.154123"
        )
        
        if st.button("Search CrossRef") and doi_input:
            with st.spinner("Searching CrossRef database..."):
                result = integrator.search_crossref(doi_input)
                
                if result:
                    st.success("Publication found!")
                    
                    col1, col2 = st.columns([2, 1])
                    
                    with col1:
                        st.write(f"**Title:** {result['title']}")
                        st.write(f"**Authors:** {result['authors']}")
                        st.write(f"**Journal:** {result['journal']}")
                        st.write(f"**Year:** {result['publication_year']}")
                        
                        if result['abstract']:
                            st.write(f"**Abstract:** {result['abstract'][:500]}...")
                    
                    with col2:
                        if st.button("Add to Database"):
                            reference_data = {
                                'doi': result['doi'],
                                'title': result['title'],
                                'authors': result['authors'],
                                'journal': result['journal'],
                                'publication_year': result['publication_year'],
                                'abstract': result['abstract']
                            }
                            
                            ref_id = insert_data('literature_references', reference_data)
                            if ref_id:
                                st.success("Reference added to database!")
                            else:
                                st.error("Failed to add reference (may already exist)")
                else:
                    st.error("Publication not found or invalid DOI")
    
    elif search_type == "PubMed Search":
        st.subheader("🔬 PubMed Search")
        
        query = st.text_input(
            "Search Query",
            help="e.g., 'antimicrobial AND plant extract AND wound healing'"
        )
        
        max_results = st.slider("Maximum Results", 1, 50, 10)
        
        if st.button("Search PubMed") and query:
            with st.spinner("Searching PubMed..."):
                results = integrator.search_pubmed(query, max_results)
                
                if results:
                    st.success(f"Found {len(results)} results")
                    
                    for i, result in enumerate(results):
                        with st.expander(f"Result {i+1}: {result['title'][:100]}..."):
                            st.write(f"**PMID:** {result['pmid']}")
                            st.write(f"**Title:** {result['title']}")
                            st.write(f"**Authors:** {result['authors']}")
                            st.write(f"**Journal:** {result['journal']}")
                            if result['publication_year']:
                                st.write(f"**Year:** {result['publication_year']}")
                            if result['doi']:
                                st.write(f"**DOI:** {result['doi']}")
                            
                            with st.expander("Abstract"):
                                st.write(result['abstract'])
                            
                            if st.button(f"Add Result {i+1} to Database", key=f"add_{i}"):
                                # Prepare data for database insertion
                                reference_data = {
                                    'title': result['title'],
                                    'authors': result['authors'],
                                    'journal': result['journal'],
                                    'publication_year': result['publication_year'],
                                    'doi': result['doi'],
                                    'abstract': result['abstract'],
                                    'pmid': result['pmid']
                                }
                                
                                # Add antimicrobial relevance analysis
                                relevance_analysis = integrator.extract_antimicrobial_mentions(
                                    f"{result['title']} {result['abstract']}"
                                )
                                
                                ref_id = insert_data('literature_references', reference_data)
                                if ref_id:
                                    st.success(f"✅ Reference added to database! (ID: {ref_id})")
                                    st.write(f"**Antimicrobial Relevance Score:** {relevance_analysis['relevance_score']}")
                                    if relevance_analysis['antimicrobial_terms']:
                                        st.write(f"**Found Terms:** {', '.join(relevance_analysis['antimicrobial_terms'])}")
                                    if relevance_analysis['mentioned_pathogens']:
                                        st.write(f"**Mentioned Pathogens:** {', '.join(relevance_analysis['mentioned_pathogens'])}")
                                else:
                                    st.error("❌ Failed to add reference (may already exist or database error)")
                else:
                    st.warning("No results found")
    
    elif search_type == "Local Database Search":
        st.subheader("💾 Local Database Search")
        
        search_term = st.text_input("Search Term")
        
        if search_term:
            query = """
                SELECT id, title, authors, journal, publication_year, doi
                FROM literature_references
                WHERE LOWER(title) LIKE LOWER(%s) 
                   OR LOWER(authors) LIKE LOWER(%s)
                   OR LOWER(abstract) LIKE LOWER(%s)
                ORDER BY publication_year DESC
            """
            
            search_pattern = f"%{search_term}%"
            results = execute_query(query, (search_pattern, search_pattern, search_pattern))
            
            if not results.empty:
                st.success(f"Found {len(results)} references in local database")
                st.dataframe(results)
            else:
                st.warning("No matching references found in local database")

def citation_management():
    """Citation management and validation interface"""
    st.subheader("📚 Citation Management")
    
    tab1, tab2, tab3 = st.tabs(["Validate Citations", "Citation Network", "Export Citations"])
    
    with tab1:
        st.subheader("✅ Citation Validation")
        
        references = execute_query("""
            SELECT id, title, authors, journal, publication_year, doi
            FROM literature_references
            ORDER BY id DESC
            LIMIT 20
        """)
        
        if not references.empty:
            integrator = LiteratureIntegrator()
            
            for _, ref in references.iterrows():
                with st.expander(f"Reference {ref['id']}: {ref['title'][:50]}..."):
                    validation = integrator.validate_citation(ref.to_dict())
                    
                    col1, col2 = st.columns([3, 1])
                    
                    with col1:
                        st.write(f"**Title:** {ref['title']}")
                        st.write(f"**Authors:** {ref['authors'] or 'Not specified'}")
                        st.write(f"**Journal:** {ref['journal'] or 'Not specified'}")
                        st.write(f"**Year:** {ref['publication_year'] or 'Not specified'}")
                        st.write(f"**DOI:** {ref['doi'] or 'Not specified'}")
                    
                    with col2:
                        if validation['is_valid']:
                            st.success("✅ Valid")
                        else:
                            st.error("❌ Issues found")
                        
                        st.metric("Completeness", f"{validation['completeness_score']:.0f}%")
                        
                        if validation['warnings']:
                            st.warning("Warnings:")
                            for warning in validation['warnings']:
                                st.write(f"• {warning}")
                        
                        if validation['errors']:
                            st.error("Errors:")
                            for error in validation['errors']:
                                st.write(f"• {error}")
        else:
            st.info("No references in database")
    
    with tab2:
        st.subheader("🕸️ Citation Network Analysis")
        
        # Get citations with antimicrobial activity data
        network_query = """
            SELECT lr.id, lr.title, lr.authors, lr.publication_year,
                   COUNT(aa.id) as activity_records
            FROM literature_references lr
            LEFT JOIN antimicrobial_activity aa ON lr.doi = aa.reference_doi
            GROUP BY lr.id, lr.title, lr.authors, lr.publication_year
            HAVING COUNT(aa.id) > 0
            ORDER BY activity_records DESC
        """
        
        network_data = execute_query(network_query)
        
        if not network_data.empty:
            st.write("**Most Cited References (by activity records):**")
            st.dataframe(network_data)
            
            # Simple network visualization placeholder
            st.info("Advanced network visualization would be implemented here using libraries like networkx and plotly")
        else:
            st.info("No citation network data available")
    
    with tab3:
        st.subheader("📤 Export Citations")
        
        export_format = st.selectbox(
            "Export Format",
            ["BibTeX", "RIS", "EndNote", "JSON"]
        )
        
        if st.button("Generate Export"):
            references = execute_query("""
                SELECT doi, title, authors, journal, publication_year, abstract
                FROM literature_references
                ORDER BY publication_year DESC
            """)
            
            if not references.empty:
                if export_format == "JSON":
                    export_data = references.to_json(orient='records', indent=2)
                    st.text_area("JSON Export", export_data, height=300)
                    
                    st.download_button(
                        label="Download JSON",
                        data=export_data,
                        file_name="references.json",
                        mime="application/json"
                    )
                
                elif export_format == "BibTeX":
                    bibtex_entries = []
                    for _, ref in references.iterrows():
                        entry = f"""@article{{ref_{ref.name},
    title = {{{ref['title']}}},
    author = {{{ref['authors'] or 'Unknown'}}},
    journal = {{{ref['journal'] or 'Unknown'}}},
    year = {{{ref['publication_year'] or 'Unknown'}}},
    doi = {{{ref['doi'] or 'Unknown'}}}
}}"""
                        bibtex_entries.append(entry)
                    
                    bibtex_data = "\n\n".join(bibtex_entries)
                    st.text_area("BibTeX Export", bibtex_data, height=300)
                    
                    st.download_button(
                        label="Download BibTeX",
                        data=bibtex_data,
                        file_name="references.bib",
                        mime="text/plain"
                    )
                
                else:
                    st.info(f"{export_format} export format not yet implemented")
            else:
                st.warning("No references to export")

def literature_analysis():
    """Analyze literature for antimicrobial trends and gaps"""
    st.subheader("📊 Literature Analysis")
    
    tab1, tab2, tab3 = st.tabs(["Trend Analysis", "Gap Analysis", "Research Recommendations"])
    
    with tab1:
        st.subheader("📈 Publication Trends")
        
        # Year-wise publication trends
        trend_query = """
            SELECT publication_year, COUNT(*) as publication_count
            FROM literature_references
            WHERE publication_year IS NOT NULL
            GROUP BY publication_year
            ORDER BY publication_year
        """
        
        trend_data = execute_query(trend_query)
        
        if not trend_data.empty:
            import plotly.express as px
            
            fig = px.line(
                trend_data, 
                x='publication_year', 
                y='publication_count',
                title='Publications by Year',
                labels={'publication_year': 'Year', 'publication_count': 'Number of Publications'}
            )
            st.plotly_chart(fig, use_container_width=True)
        else:
            st.info("No trend data available")
        
        # Journal distribution
        journal_query = """
            SELECT journal, COUNT(*) as count
            FROM literature_references
            WHERE journal IS NOT NULL
            GROUP BY journal
            ORDER BY count DESC
            LIMIT 10
        """
        
        journal_data = execute_query(journal_query)
        
        if not journal_data.empty:
            st.subheader("Top Journals")
            st.bar_chart(journal_data.set_index('journal')['count'])
    
    with tab2:
        st.subheader("🔍 Research Gap Analysis")
        
        # Pathogen coverage analysis
        pathogen_query = """
            SELECT pathogen_name, pathogen_type, COUNT(*) as study_count
            FROM antimicrobial_activity
            GROUP BY pathogen_name, pathogen_type
            ORDER BY study_count DESC
        """
        
        pathogen_data = execute_query(pathogen_query)
        
        if not pathogen_data.empty:
            st.write("**Pathogen Coverage in Studies:**")
            st.dataframe(pathogen_data)
            
            # Identify under-studied pathogens
            under_studied = pathogen_data[pathogen_data['study_count'] < 3]
            if not under_studied.empty:
                st.warning("**Under-studied Pathogens (< 3 studies):**")
                st.dataframe(under_studied)
        
        # Chemical class gaps
        class_query = """
            SELECT ph.chemical_class, COUNT(DISTINCT aa.id) as activity_studies
            FROM phytochemicals ph
            LEFT JOIN antimicrobial_activity aa ON ph.id = aa.compound_id
            WHERE ph.chemical_class IS NOT NULL
            GROUP BY ph.chemical_class
            ORDER BY activity_studies
        """
        
        class_data = execute_query(class_query)
        
        if not class_data.empty:
            st.write("**Chemical Class Coverage:**")
            st.bar_chart(class_data.set_index('chemical_class')['activity_studies'])
    
    with tab3:
        st.subheader("🎯 Research Recommendations")
        
        # Generate recommendations based on gaps
        recommendations = []
        
        # Check for data gaps
        total_compounds = execute_query("SELECT COUNT(*) as count FROM phytochemicals")
        compounds_with_activity = execute_query("""
            SELECT COUNT(DISTINCT compound_id) as count 
            FROM antimicrobial_activity
        """)
        
        if not total_compounds.empty and not compounds_with_activity.empty:
            total = total_compounds.iloc[0]['count']
            with_activity = compounds_with_activity.iloc[0]['count']
            
            if total > 0:
                coverage = (with_activity / total) * 100
                
                if coverage < 50:
                    recommendations.append({
                        "priority": "High",
                        "area": "Compound Screening",
                        "recommendation": f"Only {coverage:.1f}% of compounds have antimicrobial activity data. Prioritize screening of remaining compounds.",
                        "suggested_action": "Conduct high-throughput antimicrobial screening"
                    })
        
        # Check for ADMET data gaps
        admet_coverage = execute_query("""
            SELECT COUNT(DISTINCT compound_id) as count 
            FROM admet_properties
        """)
        
        if not admet_coverage.empty and not total_compounds.empty:
            admet_count = admet_coverage.iloc[0]['count']
            total = total_compounds.iloc[0]['count']
            
            if total > 0 and (admet_count / total) < 0.3:
                recommendations.append({
                    "priority": "Medium",
                    "area": "ADMET Studies",
                    "recommendation": "Limited ADMET data available. Consider computational ADMET prediction or experimental studies.",
                    "suggested_action": "Implement ADMET prediction pipeline"
                })
        
        # Display recommendations
        if recommendations:
            for i, rec in enumerate(recommendations):
                with st.expander(f"{rec['priority']} Priority: {rec['area']}"):
                    st.write(f"**Recommendation:** {rec['recommendation']}")
                    st.write(f"**Suggested Action:** {rec['suggested_action']}")
        else:
            st.success("No critical research gaps identified based on current data.")
        
        # Additional research suggestions
        st.subheader("💡 Additional Research Opportunities")
        
        st.markdown("""
        **Computational Studies:**
        - Machine learning models for antimicrobial activity prediction
        - QSAR analysis for chemical class optimization
        - Molecular dynamics simulations of protein-ligand interactions
        
        **Experimental Validation:**
        - Time-kill kinetics studies
        - Biofilm formation inhibition assays
        - Synergistic effects of compound combinations
        - In vivo efficacy studies in wound healing models
        
        **Formulation Development:**
        - Stability studies in different formulation bases
        - Skin penetration enhancement strategies
        - Controlled release formulation design
        """)
