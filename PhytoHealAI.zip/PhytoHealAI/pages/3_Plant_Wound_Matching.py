import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import numpy as np
from database import execute_query, insert_data
from phytochemical_db import search_plants, get_plant_details
from scoring_system import MultiEvidenceScorer
from ai_analysis import generate_formulation_recommendations
import json
import warnings
warnings.filterwarnings('ignore')

# Helper functions for matching algorithms
def calculate_plant_wound_match_score(plant, wound_type, severity, size_category, patient_factors, 
                                     antimicrobial_priority, safety_priority, formulation_priority, traditional_use_priority):
    """Calculate plant-wound matching score"""
    
    # Get plant compounds and activity data
    compounds_query = """
        SELECT ph.*, pc.concentration_range, aa.mic_value, aa.zoi_value, aa.pathogen_name
        FROM phytochemicals ph
        JOIN plant_compounds pc ON ph.id = pc.phytochemical_id
        LEFT JOIN antimicrobial_activity aa ON ph.id = aa.compound_id
        WHERE pc.plant_id = %s
    """
    
    compounds_data = execute_query(compounds_query, (plant['id'],))
    
    # Initialize scores
    antimicrobial_score = 0
    safety_score = 50  # Default moderate safety
    formulation_score = 50  # Default moderate formulation feasibility
    traditional_use_score = 0
    
    # Calculate antimicrobial score
    if not compounds_data.empty:
        active_compounds = compounds_data[compounds_data['mic_value'].notna() | compounds_data['zoi_value'].notna()]
        
        if not active_compounds.empty:
            mic_scores = []
            for _, compound in active_compounds.iterrows():
                if pd.notna(compound['mic_value']):
                    # Convert MIC to score (lower MIC = higher score)
                    # Convert Decimal to float for mathematical operations
                    mic_value_float = float(compound['mic_value'])
                    mic_score = max(0, 100 - (np.log10(mic_value_float + 0.1) + 2) * 20)
                    mic_scores.append(mic_score)
                
                if pd.notna(compound['zoi_value']):
                    # Convert ZOI to score
                    # Convert Decimal to float for mathematical operations
                    zoi_value_float = float(compound['zoi_value'])
                    zoi_score = min(100, zoi_value_float * 5)
                    mic_scores.append(zoi_score)
            
            if mic_scores:
                antimicrobial_score = np.mean(mic_scores)
    
    # Calculate safety score
    if plant['safety_profile']:
        safety_profile = plant['safety_profile'].lower()
        if any(term in safety_profile for term in ['safe', 'generally recognized', 'well tolerated']):
            safety_score += 30
        elif any(term in safety_profile for term in ['caution', 'contraindicated', 'toxic']):
            safety_score -= 30
    
    # Adjust for patient factors
    for factor in patient_factors:
        if factor.lower() in ['diabetes', 'immunocompromised']:
            safety_score -= 10  # Require higher safety margins
    
    # Calculate traditional use score
    if plant['traditional_use']:
        traditional_use = plant['traditional_use'].lower()
        wound_terms = ['wound', 'cut', 'burn', 'ulcer', 'healing', 'antiseptic', 'antimicrobial']
        
        matching_terms = sum(1 for term in wound_terms if term in traditional_use)
        traditional_use_score = min(100, matching_terms * 15)
    
    # Calculate formulation score
    compound_count = plant['compound_count']
    if compound_count > 0:
        formulation_score = min(100, 30 + compound_count * 5)  # More compounds = better formulation potential
    
    # Calculate overall score with weighted priorities
    overall_score = (
        antimicrobial_score * antimicrobial_priority +
        safety_score * safety_priority +
        formulation_score * formulation_priority +
        traditional_use_score * traditional_use_priority
    ) / (antimicrobial_priority + safety_priority + formulation_priority + traditional_use_priority)
    
    # Calculate confidence based on data availability
    confidence = 0.4  # Base confidence
    
    if plant['activity_records'] > 0:
        confidence += 0.3
    if plant['traditional_use']:
        confidence += 0.2
    if compound_count > 3:
        confidence += 0.1
    
    confidence = min(1.0, confidence)
    
    # Generate recommendation
    if overall_score >= 80:
        recommendation = "Highly recommended - strong evidence and excellent match"
    elif overall_score >= 60:
        recommendation = "Recommended - good potential with moderate evidence"
    elif overall_score >= 40:
        recommendation = "Consider with caution - limited evidence available"
    else:
        recommendation = "Not recommended - insufficient evidence or poor match"
    
    return {
        'overall_score': overall_score,
        'antimicrobial_score': antimicrobial_score,
        'safety_score': safety_score,
        'formulation_score': formulation_score,
        'traditional_use_score': traditional_use_score,
        'confidence': confidence,
        'recommendation': recommendation
    }

st.set_page_config(
    page_title="Plant-Wound Matching",
    page_icon="🌿",
    layout="wide"
)

st.title("🌿 Plant-Wound Matching Algorithm")
st.markdown("**AI-powered matching of medicinal plants to specific wound types based on phytochemical profiles and antimicrobial activity**")

# Initialize wound types if not in database
def initialize_wound_types():
    """Initialize wound types in database if not present"""
    wound_types_data = [
        {
            'wound_type': 'Acute wounds',
            'description': 'Fresh wounds that heal through normal process without complications',
            'common_pathogens': ['Staphylococcus aureus', 'Streptococcus pyogenes', 'Pseudomonas aeruginosa'],
            'healing_factors': ['hemostasis', 'inflammation control', 'cell proliferation', 'tissue remodeling'],
            'formulation_requirements': 'Non-adherent, antimicrobial, promotes natural healing'
        },
        {
            'wound_type': 'Chronic wounds',
            'description': 'Wounds that fail to heal within expected timeframe, often with biofilms',
            'common_pathogens': ['Pseudomonas aeruginosa', 'Staphylococcus aureus', 'Enterococcus species', 'Candida albicans'],
            'healing_factors': ['biofilm disruption', 'inflammation reduction', 'angiogenesis', 'tissue regeneration'],
            'formulation_requirements': 'Anti-biofilm activity, sustained release, biocompatible'
        },
        {
            'wound_type': 'Infected wounds',
            'description': 'Wounds with established bacterial, fungal, or mixed infections',
            'common_pathogens': ['MRSA', 'Pseudomonas aeruginosa', 'Acinetobacter baumannii', 'Candida species'],
            'healing_factors': ['antimicrobial action', 'immune support', 'tissue protection'],
            'formulation_requirements': 'Broad-spectrum antimicrobial, rapid action, minimal resistance development'
        },
        {
            'wound_type': 'Burn wounds',
            'description': 'Thermal, chemical, or electrical injury with damaged skin barrier',
            'common_pathogens': ['Pseudomonas aeruginosa', 'Staphylococcus aureus', 'Acinetobacter species'],
            'healing_factors': ['pain relief', 'infection prevention', 'moisture retention', 'epithelialization'],
            'formulation_requirements': 'Non-irritating, cooling effect, easy application and removal'
        },
        {
            'wound_type': 'Surgical wounds',
            'description': 'Intentional incisions made during surgical procedures',
            'common_pathogens': ['Staphylococcus epidermidis', 'Staphylococcus aureus', 'Enterococcus species'],
            'healing_factors': ['sterile healing', 'minimal scarring', 'rapid closure'],
            'formulation_requirements': 'Sterile, promotes primary healing, minimal inflammatory response'
        },
        {
            'wound_type': 'Diabetic ulcers',
            'description': 'Wounds in diabetic patients with impaired healing due to vascular and neuropathic changes',
            'common_pathogens': ['Staphylococcus aureus', 'Streptococcus species', 'Pseudomonas aeruginosa', 'Anaerobic bacteria'],
            'healing_factors': ['glucose management', 'circulation improvement', 'neuroprotection'],
            'formulation_requirements': 'Extended wear time, glucose-responsive, anti-inflammatory'
        }
    ]
    
    # Check if wound types exist
    existing_types = execute_query("SELECT COUNT(*) as count FROM wound_types")
    
    if existing_types.empty or existing_types.iloc[0]['count'] == 0:
        # Insert wound types
        for wound_type in wound_types_data:
            try:
                # Convert arrays to PostgreSQL array format
                wound_type_insert = {
                    'wound_type': wound_type['wound_type'],
                    'description': wound_type['description'],
                    'formulation_requirements': wound_type['formulation_requirements']
                }
                insert_data('wound_types', wound_type_insert)
            except Exception as e:
                st.error(f"Error initializing wound type {wound_type['wound_type']}: {str(e)}")

# Initialize wound types
initialize_wound_types()

# Matching algorithm interface
matching_mode = st.selectbox(
    "Matching Algorithm Mode",
    [
        "Find Plants for Wound Type",
        "Assess Plant for Specific Wound",
        "Comparative Plant Analysis",
        "Custom Wound Profile Matching"
    ]
)

if matching_mode == "Find Plants for Wound Type":
    st.header("🎯 Find Optimal Plants for Wound Type")
    
    # Wound type selection
    wound_types = execute_query("SELECT wound_type, description FROM wound_types ORDER BY wound_type")
    
    if not wound_types.empty:
        wound_options = [f"{row['wound_type']}: {row['description'][:100]}..." 
                        for _, row in wound_types.iterrows()]
        selected_wound_idx = st.selectbox(
            "Select Wound Type",
            range(len(wound_options)),
            format_func=lambda x: wound_options[x]
        )
        
        selected_wound_type = wound_types.iloc[selected_wound_idx]['wound_type']
        
        # Additional parameters
        col1, col2, col3 = st.columns(3)
        
        with col1:
            severity = st.selectbox(
                "Wound Severity",
                ["Mild", "Moderate", "Severe"]
            )
        
        with col2:
            size_category = st.selectbox(
                "Wound Size",
                ["Small (<2cm)", "Medium (2-10cm)", "Large (>10cm)"]
            )
        
        with col3:
            patient_factors = st.multiselect(
                "Patient Factors",
                ["Diabetes", "Immunocompromised", "Elderly", "Pediatric", "Allergies", "Multiple medications"]
            )
        
        # Advanced matching parameters
        with st.expander("Advanced Matching Parameters"):
            col1, col2 = st.columns(2)
            
            with col1:
                antimicrobial_priority = st.slider(
                    "Antimicrobial Activity Priority",
                    min_value=0.0,
                    max_value=1.0,
                    value=0.7,
                    step=0.1,
                    help="Weight given to antimicrobial evidence in matching"
                )
                
                safety_priority = st.slider(
                    "Safety Profile Priority",
                    min_value=0.0,
                    max_value=1.0,
                    value=0.8,
                    step=0.1
                )
            
            with col2:
                formulation_priority = st.slider(
                    "Formulation Feasibility Priority",
                    min_value=0.0,
                    max_value=1.0,
                    value=0.6,
                    step=0.1
                )
                
                traditional_use_priority = st.slider(
                    "Traditional Use Evidence Priority",
                    min_value=0.0,
                    max_value=1.0,
                    value=0.5,
                    step=0.1
                )
        
        # Execute matching
        if st.button("Find Matching Plants"):
            with st.spinner("Analyzing plant-wound compatibility..."):
                
                # Get all plants with compounds
                plants_query = """
                    SELECT DISTINCT p.id, p.scientific_name, p.common_name, p.family, 
                           p.traditional_use, p.safety_profile,
                           COUNT(DISTINCT pc.phytochemical_id) as compound_count,
                           COUNT(DISTINCT aa.id) as activity_records
                    FROM plants p
                    LEFT JOIN plant_compounds pc ON p.id = pc.plant_id
                    LEFT JOIN phytochemicals ph ON pc.phytochemical_id = ph.id
                    LEFT JOIN antimicrobial_activity aa ON ph.id = aa.compound_id
                    GROUP BY p.id, p.scientific_name, p.common_name, p.family, p.traditional_use, p.safety_profile
                    HAVING COUNT(DISTINCT pc.phytochemical_id) > 0
                    ORDER BY activity_records DESC, compound_count DESC
                """
                
                candidate_plants = execute_query(plants_query)
                
                if not candidate_plants.empty:
                    plant_scores = []
                    
                    # Analyze each plant
                    progress_bar = st.progress(0)
                    status_text = st.empty()
                    
                    for idx, plant in candidate_plants.iterrows():
                        status_text.text(f"Analyzing {plant['scientific_name']}...")
                        
                        # Calculate matching score
                        score = calculate_plant_wound_match_score(
                            plant, selected_wound_type, severity, size_category, patient_factors,
                            antimicrobial_priority, safety_priority, formulation_priority, traditional_use_priority
                        )
                        
                        plant_scores.append({
                            'plant_id': plant['id'],
                            'scientific_name': plant['scientific_name'],
                            'common_name': plant['common_name'],
                            'family': plant['family'],
                            'overall_score': score['overall_score'],
                            'antimicrobial_score': score['antimicrobial_score'],
                            'safety_score': score['safety_score'],
                            'formulation_score': score['formulation_score'],
                            'traditional_use_score': score['traditional_use_score'],
                            'confidence': score['confidence'],
                            'recommendation': score['recommendation']
                        })
                        
                        progress_bar.progress((idx + 1) / len(candidate_plants))
                    
                    status_text.empty()
                    progress_bar.empty()
                    
                    # Sort by overall score
                    plant_scores_df = pd.DataFrame(plant_scores)
                    plant_scores_df = plant_scores_df.sort_values('overall_score', ascending=False)
                    
                    st.success(f"Analysis completed! Found {len(plant_scores_df)} candidate plants.")
                    
                    # Top recommendations
                    st.subheader("🏆 Top Plant Recommendations")
                    
                    top_plants = plant_scores_df.head(10)
                    
                    # Visualization
                    fig = px.bar(
                        top_plants,
                        x='scientific_name',
                        y='overall_score',
                        color='confidence',
                        title=f'Top 10 Plants for {selected_wound_type}',
                        labels={'overall_score': 'Matching Score', 'scientific_name': 'Plant Species'},
                        color_continuous_scale='RdYlGn'
                    )
                    fig.update_layout(xaxis_tickangle=-45)
                    st.plotly_chart(fig, use_container_width=True)
                    
                    # Detailed recommendations
                    for idx, plant in top_plants.iterrows():
                        with st.expander(f"#{idx+1}: {plant['scientific_name']} (Score: {plant['overall_score']:.1f})"):
                            
                            col1, col2 = st.columns([2, 1])
                            
                            with col1:
                                st.write(f"**Common Name:** {plant['common_name'] or 'Not specified'}")
                                st.write(f"**Family:** {plant['family'] or 'Unknown'}")
                                st.write(f"**Recommendation:** {plant['recommendation']}")
                            
                            with col2:
                                st.metric("Overall Score", f"{plant['overall_score']:.1f}/100")
                                st.metric("Confidence", f"{plant['confidence']:.2f}")
                            
                            # Score breakdown
                            score_breakdown = {
                                'Antimicrobial': plant['antimicrobial_score'],
                                'Safety': plant['safety_score'],
                                'Formulation': plant['formulation_score'],
                                'Traditional Use': plant['traditional_use_score']
                            }
                            
                            breakdown_df = pd.DataFrame([score_breakdown])
                            st.bar_chart(breakdown_df.T)
                            
                            # Get detailed plant information
                            if st.button(f"View Detailed Profile", key=f"detail_{plant['plant_id']}"):
                                plant_data, compounds_data, activity_data = get_plant_details(plant['plant_id'])
                                
                                if plant_data is not None:
                                    st.markdown("**Traditional Use:**")
                                    st.write(plant_data['traditional_use'] or 'Not documented')
                                    
                                    st.markdown("**Safety Profile:**")
                                    st.write(plant_data['safety_profile'] or 'Not documented')
                                    
                                    if not compounds_data.empty:
                                        st.markdown("**Key Compounds:**")
                                        key_compounds = compounds_data[['name', 'chemical_class', 'biological_activity']].head(5)
                                        st.dataframe(key_compounds, use_container_width=True)
                    
                    # Export results
                    st.subheader("📥 Export Results")
                    
                    export_data = {
                        "matching_metadata": {
                            "wound_type": selected_wound_type,
                            "severity": severity,
                            "size_category": size_category,
                            "patient_factors": patient_factors,
                            "analysis_timestamp": pd.Timestamp.now().isoformat(),
                            "parameters": {
                                "antimicrobial_priority": antimicrobial_priority,
                                "safety_priority": safety_priority,
                                "formulation_priority": formulation_priority,
                                "traditional_use_priority": traditional_use_priority
                            }
                        },
                        "plant_recommendations": plant_scores_df.to_dict('records')
                    }
                    
                    json_str = json.dumps(export_data, indent=2, default=str)
                    st.download_button(
                        label="Download Plant Recommendations",
                        data=json_str,
                        file_name=f"plant_wound_matching_{selected_wound_type.replace(' ', '_')}.json",
                        mime="application/json"
                    )
                
                else:
                    st.warning("No plants with compound data found in database")
    else:
        st.error("No wound types found in database")

elif matching_mode == "Assess Plant for Specific Wound":
    st.header("🌱 Assess Specific Plant for Wound Treatment")
    
    # Plant selection
    plant_search = st.text_input(
        "Search Plant Species",
        placeholder="Enter scientific or common name..."
    )
    
    if plant_search:
        plants = search_plants(plant_search)
        
        if not plants.empty:
            plant_options = [f"{row['scientific_name']} ({row['common_name'] or 'No common name'})" 
                           for _, row in plants.iterrows()]
            selected_plant_idx = st.selectbox(
                "Select Plant",
                range(len(plant_options)),
                format_func=lambda x: plant_options[x]
            )
            
            selected_plant = plants.iloc[selected_plant_idx]
            
            # Wound specification
            col1, col2 = st.columns(2)
            
            with col1:
                target_wound_type = st.selectbox(
                    "Target Wound Type",
                    ["Acute wounds", "Chronic wounds", "Infected wounds", "Burn wounds", "Surgical wounds", "Diabetic ulcers"]
                )
                
                target_pathogens = st.multiselect(
                    "Target Pathogens (if known)",
                    [
                        "Staphylococcus aureus", "MRSA", "Streptococcus pyogenes",
                        "Pseudomonas aeruginosa", "Escherichia coli", "Enterococcus species",
                        "Candida albicans", "Aspergillus niger", "Acinetobacter baumannii"
                    ]
                )
            
            with col2:
                application_method = st.selectbox(
                    "Preferred Application Method",
                    ["Topical cream/ointment", "Gel", "Liquid extract", "Powder", "Poultice", "Essential oil"]
                )
                
                treatment_duration = st.selectbox(
                    "Expected Treatment Duration",
                    ["Acute (1-7 days)", "Short-term (1-4 weeks)", "Long-term (>4 weeks)"]
                )
            
            # Assessment execution
            if st.button("Assess Plant Suitability"):
                with st.spinner("Assessing plant suitability for specified wound..."):
                    
                    # Get plant details
                    plant_data, compounds_data, activity_data = get_plant_details(selected_plant['id'])
                    
                    if plant_data is not None:
                        assessment_result = assess_plant_wound_suitability(
                            plant_data, compounds_data, activity_data,
                            target_wound_type, target_pathogens, application_method, treatment_duration
                        )
                        
                        st.success("Assessment completed!")
                        
                        # Overall suitability
                        suitability_score = assessment_result['suitability_score']
                        
                        if suitability_score >= 80:
                            st.success(f"🌟 EXCELLENT MATCH (Score: {suitability_score:.1f}/100)")
                            st.success("This plant shows strong potential for the specified wound type")
                        elif suitability_score >= 60:
                            st.warning(f"✅ GOOD MATCH (Score: {suitability_score:.1f}/100)")
                            st.info("This plant shows promising potential with some considerations")
                        elif suitability_score >= 40:
                            st.warning(f"⚠️ MODERATE MATCH (Score: {suitability_score:.1f}/100)")
                            st.warning("This plant may have limited applicability")
                        else:
                            st.error(f"❌ POOR MATCH (Score: {suitability_score:.1f}/100)")
                            st.error("This plant is not recommended for this wound type")
                        
                        # Assessment details
                        col1, col2 = st.columns(2)
                        
                        with col1:
                            st.subheader("✅ Strengths")
                            strengths = assessment_result.get('strengths', [])
                            for strength in strengths:
                                st.success(f"• {strength}")
                            
                            st.subheader("💡 Active Compounds")
                            active_compounds = assessment_result.get('active_compounds', [])
                            if active_compounds:
                                for compound in active_compounds:
                                    st.info(f"• {compound['name']}: {compound['activity']}")
                        
                        with col2:
                            st.subheader("⚠️ Limitations")
                            limitations = assessment_result.get('limitations', [])
                            for limitation in limitations:
                                st.warning(f"• {limitation}")
                            
                            st.subheader("🔬 Research Gaps")
                            research_gaps = assessment_result.get('research_gaps', [])
                            for gap in research_gaps:
                                st.error(f"• {gap}")
                        
                        # Formulation recommendations
                        if assessment_result.get('formulation_recommendations'):
                            st.subheader("💊 Formulation Recommendations")
                            
                            formulation_recs = assessment_result['formulation_recommendations']
                            
                            st.write(f"**Recommended Concentration:** {formulation_recs.get('concentration', 'Not specified')}")
                            st.write(f"**Vehicle:** {formulation_recs.get('vehicle', 'Not specified')}")
                            st.write(f"**Stability Considerations:** {formulation_recs.get('stability', 'Not specified')}")
                            
                            if formulation_recs.get('synergists'):
                                st.write("**Potential Synergists:**")
                                for synergist in formulation_recs['synergists']:
                                    st.write(f"• {synergist}")
                        
                        # Clinical considerations
                        st.subheader("🏥 Clinical Considerations")
                        
                        clinical = assessment_result.get('clinical_considerations', {})
                        
                        if clinical:
                            st.write(f"**Contraindications:** {clinical.get('contraindications', 'None known')}")
                            st.write(f"**Drug Interactions:** {clinical.get('interactions', 'None known')}")
                            st.write(f"**Special Populations:** {clinical.get('special_populations', 'Standard precautions')}")
                        
                        # Literature support
                        st.subheader("📚 Literature Support")
                        
                        literature_support = assessment_result.get('literature_support', {})
                        
                        if literature_support:
                            st.metric("Evidence Quality", literature_support.get('quality', 'Unknown'))
                            st.metric("Number of Studies", literature_support.get('study_count', 0))
                            
                            key_studies = literature_support.get('key_studies', [])
                            if key_studies:
                                st.write("**Key Supporting Studies:**")
                                for study in key_studies:
                                    st.write(f"• {study}")
                    
                    else:
                        st.error("Could not retrieve plant data for assessment")

elif matching_mode == "Comparative Plant Analysis":
    st.header("⚖️ Comparative Plant Analysis")
    
    st.markdown("""
    **Side-by-side comparison** of multiple plants for specific wound treatment applications.
    """)
    
    # Plant selection for comparison
    st.subheader("Select Plants for Comparison (2-5 plants)")
    
    comparison_plants = []
    
    for i in range(5):
        col1, col2 = st.columns([3, 1])
        
        with col1:
            plant_search = st.text_input(
                f"Plant {i+1} {'*' if i < 2 else '(optional)'}",
                key=f"compare_plant_{i}",
                placeholder="Search plant name..."
            )
            
            if plant_search:
                plants = search_plants(plant_search)
                
                if not plants.empty:
                    plant_options = [f"{row['scientific_name']} ({row['common_name'] or 'No common name'})" 
                                   for _, row in plants.iterrows()]
                    selected_idx = st.selectbox(
                        f"Select Plant {i+1}",
                        range(len(plant_options)),
                        format_func=lambda x: plant_options[x],
                        key=f"compare_select_{i}"
                    )
                    
                    selected_plant = plants.iloc[selected_idx]
                    comparison_plants.append(selected_plant)
        
        with col2:
            if i < len(comparison_plants):
                st.success("✓ Selected")
    
    # Comparison parameters
    if len(comparison_plants) >= 2:
        col1, col2 = st.columns(2)
        
        with col1:
            comparison_wound_type = st.selectbox(
                "Wound Type for Comparison",
                ["Acute wounds", "Chronic wounds", "Infected wounds", "Burn wounds", "Surgical wounds", "Diabetic ulcers"]
            )
        
        with col2:
            comparison_criteria = st.multiselect(
                "Comparison Criteria",
                ["Antimicrobial Activity", "Safety Profile", "Traditional Use", "Formulation Feasibility", 
                 "Literature Support", "Compound Diversity"],
                default=["Antimicrobial Activity", "Safety Profile"]
            )
        
        # Execute comparison
        if st.button("Compare Plants"):
            with st.spinner("Performing comparative analysis..."):
                
                comparison_results = []
                
                for plant in comparison_plants:
                    plant_data, compounds_data, activity_data = get_plant_details(plant['id'])
                    
                    if plant_data is not None:
                        # Calculate scores for each criterion
                        plant_result = {
                            'plant_name': plant['scientific_name'],
                            'common_name': plant['common_name'],
                            'family': plant['family']
                        }
                        
                        # Calculate individual scores
                        scores = calculate_plant_comparison_scores(
                            plant_data, compounds_data, activity_data, comparison_wound_type, comparison_criteria
                        )
                        
                        plant_result.update(scores)
                        comparison_results.append(plant_result)
                
                if comparison_results:
                    st.success("Comparative analysis completed!")
                    
                    # Create comparison visualization
                    comparison_df = pd.DataFrame(comparison_results)
                    
                    # Radar chart comparison
                    fig = go.Figure()
                    
                    criteria_cols = [col for col in comparison_df.columns if col.endswith('_score')]
                    criteria_names = [col.replace('_score', '').replace('_', ' ').title() for col in criteria_cols]
                    
                    colors = ['blue', 'red', 'green', 'orange', 'purple']
                    
                    for idx, plant in comparison_df.iterrows():
                        values = [plant[col] for col in criteria_cols]
                        
                        fig.add_trace(go.Scatterpolar(
                            r=values,
                            theta=criteria_names,
                            fill='toself',
                            name=plant['plant_name'],
                            line_color=colors[idx % len(colors)]
                        ))
                    
                    fig.update_layout(
                        polar=dict(
                            radialaxis=dict(
                                visible=True,
                                range=[0, 100]
                            )),
                        showlegend=True,
                        title="Plant Comparison Radar Chart"
                    )
                    
                    st.plotly_chart(fig, use_container_width=True)
                    
                    # Comparison table
                    st.subheader("📊 Detailed Comparison Table")
                    
                    display_df = comparison_df.copy()
                    
                    # Format scores for display
                    for col in criteria_cols:
                        display_df[col] = display_df[col].apply(lambda x: f"{x:.1f}")
                    
                    st.dataframe(display_df, use_container_width=True)
                    
                    # Ranking summary
                    st.subheader("🏆 Ranking Summary")
                    
                    for criterion in criteria_cols:
                        criterion_name = criterion.replace('_score', '').replace('_', ' ').title()
                        
                        ranked = comparison_df.nlargest(len(comparison_df), criterion)
                        
                        with st.expander(f"Best for {criterion_name}"):
                            for idx, (_, plant) in enumerate(ranked.iterrows()):
                                rank_color = "🥇" if idx == 0 else "🥈" if idx == 1 else "🥉" if idx == 2 else "📍"
                                st.write(f"{rank_color} {plant['plant_name']} ({plant[criterion]:.1f}/100)")
                
                else:
                    st.error("Could not retrieve data for plant comparison")

elif matching_mode == "Custom Wound Profile Matching":
    st.header("🎨 Custom Wound Profile Matching")
    
    st.markdown("""
    **Create a custom wound profile** with specific characteristics and find the best matching plants.
    """)
    
    # Custom wound profile creation
    st.subheader("Define Custom Wound Profile")
    
    col1, col2 = st.columns(2)
    
    with col1:
        custom_wound_name = st.text_input(
            "Wound Profile Name",
            placeholder="e.g., Post-surgical diabetic wound"
        )
        
        wound_characteristics = st.multiselect(
            "Wound Characteristics",
            [
                "Deep tissue involvement", "Superficial", "Exudative", "Dry",
                "Infected", "Clean", "Necrotic tissue", "Granulating",
                "Painful", "Painless", "Large surface area", "Small puncture"
            ]
        )
        
        anatomical_location = st.selectbox(
            "Anatomical Location",
            ["Extremities", "Torso", "Head/neck", "Hands/feet", "Pressure points", "Joint areas"]
        )
    
    with col2:
        target_pathogens_custom = st.multiselect(
            "Known/Suspected Pathogens",
            [
                "Gram-positive bacteria", "Gram-negative bacteria", "Anaerobic bacteria",
                "MRSA", "MSSA", "Pseudomonas", "E. coli", "Enterococcus",
                "Candida species", "Aspergillus species", "Mixed infection"
            ]
        )
        
        patient_comorbidities = st.multiselect(
            "Patient Comorbidities",
            [
                "Diabetes mellitus", "Immunosuppression", "Cardiovascular disease",
                "Kidney disease", "Liver disease", "Cancer", "Autoimmune disorders",
                "Vascular insufficiency", "Neuropathy"
            ]
        )
        
        treatment_goals = st.multiselect(
            "Primary Treatment Goals",
            [
                "Infection control", "Pain management", "Inflammation reduction",
                "Promote granulation", "Enhance epithelialization", "Reduce exudate",
                "Prevent scarring", "Improve circulation", "Debridement"
            ]
        )
    
    # Matching preferences
    st.subheader("Matching Preferences")
    
    col1, col2, col3 = st.columns(3)
    
    with col1:
        evidence_preference = st.selectbox(
            "Evidence Preference",
            ["Traditional use", "Scientific literature", "Both equally"]
        )
        
        safety_concern_level = st.selectbox(
            "Safety Concern Level",
            ["Low (healthy adults)", "Moderate (chronic conditions)", "High (vulnerable populations)"]
        )
    
    with col2:
        formulation_complexity = st.selectbox(
            "Formulation Complexity",
            ["Simple (single extract)", "Moderate (combination)", "Complex (advanced formulation)"]
        )
        
        cost_consideration = st.selectbox(
            "Cost Consideration",
            ["Not important", "Moderate", "High priority"]
        )
    
    with col3:
        availability_preference = st.selectbox(
            "Plant Availability",
            ["Local/regional plants", "Commonly cultivated", "Any source"]
        )
        
        preparation_method = st.selectbox(
            "Preferred Preparation",
            ["Simple extraction", "Standardized extract", "Essential oil", "Fresh preparation"]
        )
    
    # Execute custom matching
    if st.button("Find Plants for Custom Profile") and custom_wound_name:
        with st.spinner("Analyzing plants for custom wound profile..."):
            
            # Create custom wound profile
            custom_profile = {
                'name': custom_wound_name,
                'characteristics': wound_characteristics,
                'location': anatomical_location,
                'pathogens': target_pathogens_custom,
                'comorbidities': patient_comorbidities,
                'goals': treatment_goals,
                'preferences': {
                    'evidence': evidence_preference,
                    'safety': safety_concern_level,
                    'formulation': formulation_complexity,
                    'cost': cost_consideration,
                    'availability': availability_preference,
                    'preparation': preparation_method
                }
            }
            
            # Find matching plants
            custom_matches = find_plants_for_custom_profile(custom_profile)
            
            if custom_matches:
                st.success(f"Found {len(custom_matches)} plants matching your custom profile!")
                
                # Display matches
                for idx, match in enumerate(custom_matches[:10]):  # Top 10
                    with st.expander(f"#{idx+1}: {match['plant_name']} (Match: {match['match_score']:.1f}%)"):
                        
                        col1, col2 = st.columns([2, 1])
                        
                        with col1:
                            st.write(f"**Family:** {match['family']}")
                            st.write(f"**Matching Rationale:** {match['rationale']}")
                            
                            # Key matching factors
                            st.write("**Key Matching Factors:**")
                            for factor in match['matching_factors']:
                                st.success(f"✓ {factor}")
                        
                        with col2:
                            st.metric("Match Score", f"{match['match_score']:.1f}%")
                            st.metric("Confidence", f"{match['confidence']:.2f}")
                            
                            # Evidence level
                            evidence_level = match.get('evidence_level', 'Unknown')
                            if evidence_level == 'High':
                                st.success(f"Evidence: {evidence_level}")
                            elif evidence_level == 'Medium':
                                st.warning(f"Evidence: {evidence_level}")
                            else:
                                st.error(f"Evidence: {evidence_level}")
                        
                        # Specific recommendations
                        if match.get('recommendations'):
                            st.write("**Specific Recommendations:**")
                            for rec in match['recommendations']:
                                st.info(f"• {rec}")
                        
                        # Precautions
                        if match.get('precautions'):
                            st.write("**Precautions:**")
                            for precaution in match['precautions']:
                                st.warning(f"⚠️ {precaution}")
                
                # Save custom profile
                if st.button("Save Custom Profile"):
                    # In a real application, save to database
                    st.success("Custom wound profile saved successfully!")
                    
                    profile_data = {
                        "custom_profile": custom_profile,
                        "matching_results": custom_matches,
                        "created_timestamp": pd.Timestamp.now().isoformat()
                    }
                    
                    json_str = json.dumps(profile_data, indent=2)
                    st.download_button(
                        label="Download Custom Profile Results",
                        data=json_str,
                        file_name=f"custom_wound_profile_{custom_wound_name.replace(' ', '_')}.json",
                        mime="application/json"
                    )
            
            else:
                st.warning("No suitable plants found for the specified custom profile. Consider adjusting criteria.")


def assess_plant_wound_suitability(plant_data, compounds_data, activity_data, wound_type, target_pathogens, application_method, treatment_duration):
    """Assess a specific plant's suitability for a wound type"""
    
    assessment = {
        'suitability_score': 0,
        'strengths': [],
        'limitations': [],
        'active_compounds': [],
        'research_gaps': [],
        'formulation_recommendations': {},
        'clinical_considerations': {},
        'literature_support': {}
    }
    
    base_score = 40  # Starting score
    
    # Analyze compounds
    if not compounds_data.empty:
        for _, compound in compounds_data.iterrows():
            if compound['biological_activity']:
                activity = compound['biological_activity'].lower()
                
                if any(term in activity for term in ['antimicrobial', 'antibacterial', 'antiseptic']):
                    base_score += 15
                    assessment['strengths'].append(f"Contains antimicrobial compound: {compound['name']}")
                    assessment['active_compounds'].append({
                        'name': compound['name'],
                        'activity': compound['biological_activity']
                    })
                
                if any(term in activity for term in ['anti-inflammatory', 'healing', 'regenerative']):
                    base_score += 10
                    assessment['strengths'].append(f"Wound healing properties: {compound['name']}")
    
    # Analyze activity data
    if not activity_data.empty:
        relevant_pathogens = []
        
        for _, activity in activity_data.iterrows():
            if not target_pathogens or activity['pathogen_name'] in target_pathogens:
                relevant_pathogens.append(activity['pathogen_name'])
                
                if pd.notna(activity['mic_value']):
                    if activity['mic_value'] <= 50:  # Good MIC
                        base_score += 20
                        assessment['strengths'].append(f"Strong activity against {activity['pathogen_name']} (MIC: {activity['mic_value']} µg/mL)")
                    elif activity['mic_value'] <= 200:
                        base_score += 10
                        assessment['strengths'].append(f"Moderate activity against {activity['pathogen_name']}")
        
        if relevant_pathogens:
            assessment['strengths'].append(f"Documented activity against {len(relevant_pathogens)} relevant pathogens")
        else:
            assessment['limitations'].append("No documented activity against target pathogens")
            base_score -= 15
    else:
        assessment['research_gaps'].append("No antimicrobial activity data available")
        base_score -= 10
    
    # Traditional use assessment
    if plant_data['traditional_use']:
        traditional_use = plant_data['traditional_use'].lower()
        wound_terms = ['wound', 'cut', 'burn', 'ulcer', 'healing', 'antiseptic']
        
        if any(term in traditional_use for term in wound_terms):
            base_score += 15
            assessment['strengths'].append("Traditional use supports wound healing applications")
        else:
            assessment['limitations'].append("Limited traditional use for wound healing")
    
    # Safety assessment
    if plant_data['safety_profile']:
        safety = plant_data['safety_profile'].lower()
        
        if any(term in safety for term in ['safe', 'well tolerated']):
            base_score += 10
            assessment['strengths'].append("Good safety profile documented")
        elif any(term in safety for term in ['toxic', 'contraindicated', 'adverse']):
            base_score -= 20
            assessment['limitations'].append("Safety concerns documented")
            assessment['clinical_considerations']['contraindications'] = "Refer to safety profile"
    else:
        assessment['research_gaps'].append("Safety profile not documented")
    
    # Application method compatibility
    formulation_recommendations = {}
    
    if application_method in ['Topical cream/ointment', 'Gel']:
        formulation_recommendations['vehicle'] = "Oil-in-water or water-in-oil emulsion"
        formulation_recommendations['concentration'] = "1-5% plant extract"
        base_score += 5
    elif application_method == 'Essential oil':
        if any('essential oil' in str(comp.get('biological_activity', '')).lower() 
               for _, comp in compounds_data.iterrows()):
            formulation_recommendations['vehicle'] = "Carrier oil required (coconut, jojoba)"
            formulation_recommendations['concentration'] = "0.5-2% essential oil"
            base_score += 10
        else:
            assessment['limitations'].append("No essential oil data available")
    
    assessment['formulation_recommendations'] = formulation_recommendations
    
    # Final score calculation
    assessment['suitability_score'] = max(0, min(100, base_score))
    
    return assessment

def calculate_plant_comparison_scores(plant_data, compounds_data, activity_data, wound_type, criteria):
    """Calculate scores for plant comparison"""
    
    scores = {}
    
    for criterion in criteria:
        if criterion == "Antimicrobial Activity":
            if not activity_data.empty:
                activity_scores = []
                for _, activity in activity_data.iterrows():
                    if pd.notna(activity['mic_value']):
                        score = max(0, 100 - (np.log10(activity['mic_value'] + 0.1) + 2) * 20)
                        activity_scores.append(score)
                
                scores['antimicrobial_activity_score'] = np.mean(activity_scores) if activity_scores else 0
            else:
                scores['antimicrobial_activity_score'] = 0
        
        elif criterion == "Safety Profile":
            if plant_data['safety_profile']:
                safety = plant_data['safety_profile'].lower()
                if any(term in safety for term in ['safe', 'well tolerated']):
                    scores['safety_profile_score'] = 85
                elif any(term in safety for term in ['caution']):
                    scores['safety_profile_score'] = 60
                elif any(term in safety for term in ['toxic', 'contraindicated']):
                    scores['safety_profile_score'] = 20
                else:
                    scores['safety_profile_score'] = 50
            else:
                scores['safety_profile_score'] = 40
        
        elif criterion == "Traditional Use":
            if plant_data['traditional_use']:
                traditional_use = plant_data['traditional_use'].lower()
                wound_terms = ['wound', 'cut', 'burn', 'ulcer', 'healing', 'antiseptic']
                matching_terms = sum(1 for term in wound_terms if term in traditional_use)
                scores['traditional_use_score'] = min(100, matching_terms * 20)
            else:
                scores['traditional_use_score'] = 0
        
        elif criterion == "Compound Diversity":
            compound_count = len(compounds_data) if not compounds_data.empty else 0
            scores['compound_diversity_score'] = min(100, compound_count * 10)
        
        elif criterion == "Literature Support":
            activity_records = len(activity_data) if not activity_data.empty else 0
            scores['literature_support_score'] = min(100, activity_records * 15)
        
        elif criterion == "Formulation Feasibility":
            # Simple scoring based on compound properties
            if not compounds_data.empty:
                molecular_weights = compounds_data['molecular_weight'].dropna()
                if not molecular_weights.empty:
                    avg_mw = molecular_weights.mean()
                    if 200 <= avg_mw <= 500:
                        scores['formulation_feasibility_score'] = 80
                    elif 150 <= avg_mw <= 600:
                        scores['formulation_feasibility_score'] = 60
                    else:
                        scores['formulation_feasibility_score'] = 40
                else:
                    scores['formulation_feasibility_score'] = 50
            else:
                scores['formulation_feasibility_score'] = 30
    
    return scores

def find_plants_for_custom_profile(custom_profile):
    """Find plants matching a custom wound profile"""
    
    # Get all plants with their compounds
    plants_query = """
        SELECT DISTINCT p.id, p.scientific_name, p.common_name, p.family, 
               p.traditional_use, p.safety_profile
        FROM plants p
        JOIN plant_compounds pc ON p.id = pc.plant_id
        JOIN phytochemicals ph ON pc.phytochemical_id = ph.id
    """
    
    all_plants = execute_query(plants_query)
    
    matches = []
    
    for _, plant in all_plants.iterrows():
        match_score = 0
        matching_factors = []
        recommendations = []
        precautions = []
        
        # Get plant details
        plant_data, compounds_data, activity_data = get_plant_details(plant['id'])
        
        if plant_data is not None:
            # Score based on traditional use
            if plant_data['traditional_use']:
                traditional_use = plant_data['traditional_use'].lower()
                
                # Check for wound-related terms
                wound_characteristics = custom_profile['characteristics']
                for characteristic in wound_characteristics:
                    if any(word in traditional_use for word in characteristic.lower().split()):
                        match_score += 10
                        matching_factors.append(f"Traditional use mentions {characteristic.lower()}")
                
                # Check for treatment goals
                treatment_goals = custom_profile['goals']
                for goal in treatment_goals:
                    goal_words = goal.lower().replace(' ', '').split()
                    if any(word in traditional_use for word in goal_words):
                        match_score += 15
                        matching_factors.append(f"Traditional use supports {goal.lower()}")
            
            # Score based on antimicrobial activity
            if not activity_data.empty:
                target_pathogens = custom_profile['pathogens']
                
                for pathogen_category in target_pathogens:
                    # Map pathogen categories to specific organisms
                    pathogen_mapping = {
                        'gram-positive bacteria': ['staphylococcus', 'streptococcus', 'enterococcus'],
                        'gram-negative bacteria': ['pseudomonas', 'escherichia', 'acinetobacter'],
                        'mrsa': ['methicillin-resistant staphylococcus'],
                        'candida species': ['candida'],
                        'mixed infection': ['bacteria', 'fungus']
                    }
                    
                    category_organisms = pathogen_mapping.get(pathogen_category.lower(), [pathogen_category.lower()])
                    
                    for _, activity in activity_data.iterrows():
                        pathogen_name = activity['pathogen_name'].lower()
                        
                        if any(org in pathogen_name for org in category_organisms):
                            if pd.notna(activity['mic_value']) and activity['mic_value'] <= 100:
                                match_score += 20
                                matching_factors.append(f"Active against {activity['pathogen_name']}")
            
            # Safety considerations
            safety_level = custom_profile['preferences']['safety']
            
            if plant_data['safety_profile']:
                safety = plant_data['safety_profile'].lower()
                
                if safety_level == "High (vulnerable populations)":
                    if any(term in safety for term in ['safe', 'well tolerated']):
                        match_score += 15
                        matching_factors.append("Excellent safety profile for vulnerable populations")
                    elif any(term in safety for term in ['caution', 'contraindicated']):
                        match_score -= 25
                        precautions.append("Safety concerns in vulnerable populations")
                elif safety_level == "Moderate (chronic conditions)":
                    if not any(term in safety for term in ['toxic', 'severe']):
                        match_score += 10
                        matching_factors.append("Acceptable safety for chronic conditions")
            
            # Formulation preferences
            formulation_pref = custom_profile['preferences']['formulation']
            
            if formulation_pref == "Simple (single extract)":
                match_score += 5
                recommendations.append("Use as single plant extract")
            elif formulation_pref == "Complex (advanced formulation)":
                if len(compounds_data) > 5:
                    match_score += 10
                    matching_factors.append("Rich phytochemical profile suitable for complex formulation")
            
            # Calculate confidence
            confidence = 0.5
            
            if plant_data['traditional_use']:
                confidence += 0.2
            if not activity_data.empty:
                confidence += 0.2
            if plant_data['safety_profile']:
                confidence += 0.1
            
            confidence = min(1.0, confidence)
            
            # Determine evidence level
            if not activity_data.empty and plant_data['traditional_use'] and plant_data['safety_profile']:
                evidence_level = "High"
            elif (not activity_data.empty and plant_data['traditional_use']) or (plant_data['traditional_use'] and plant_data['safety_profile']):
                evidence_level = "Medium"
            else:
                evidence_level = "Low"
            
            # Only include plants with reasonable match scores
            if match_score >= 20:
                # Generate rationale
                rationale = f"This plant shows compatibility with your wound profile based on "
                if matching_factors:
                    rationale += ", ".join(matching_factors[:3])
                else:
                    rationale += "general wound healing properties"
                
                matches.append({
                    'plant_name': plant['scientific_name'],
                    'common_name': plant['common_name'],
                    'family': plant['family'],
                    'match_score': min(100, match_score),
                    'confidence': confidence,
                    'evidence_level': evidence_level,
                    'matching_factors': matching_factors,
                    'rationale': rationale,
                    'recommendations': recommendations,
                    'precautions': precautions
                })
    
    # Sort by match score
    matches.sort(key=lambda x: x['match_score'], reverse=True)
    
    return matches

# Footer
st.markdown("---")
st.markdown("""
<div style='text-align: center; color: #666;'>
<p><strong>Plant-Wound Matching Algorithm</strong> | Evidence-based botanical medicine selection</p>
<p>Combines traditional knowledge with modern scientific evidence for optimal plant selection</p>
</div>
""", unsafe_allow_html=True)

