import streamlit as st
import pandas as pd
import json
import plotly.express as px
import plotly.graph_objects as go
from literature_integration import (
    search_literature_interface, citation_management, literature_analysis,
    LiteratureIntegrator
)
from database import execute_query
import warnings
warnings.filterwarnings('ignore')

st.set_page_config(
    page_title="Literature Integration",
    page_icon="📚",
    layout="wide"
)

st.title("📚 Literature Integration & Analysis")
st.markdown("**Scientific literature search, citation management, and research trend analysis**")

# Literature integration mode
integration_mode = st.selectbox(
    "Select Literature Function",
    [
        "Literature Search",
        "Citation Management", 
        "Literature Analysis",
        "Research Gap Identification",
        "Publication Trends",
        "Evidence Quality Assessment"
    ]
)

if integration_mode == "Literature Search":
    st.header("🔍 Scientific Literature Search")
    
    st.markdown("""
    **Multi-database literature search** with automatic citation extraction and 
    relevance scoring for antimicrobial and wound healing research.
    """)
    
    search_literature_interface()

elif integration_mode == "Citation Management":
    st.header("📖 Citation Management")
    
    st.markdown("""
    **Comprehensive citation management** with validation, formatting, and 
    export capabilities for reproducible research workflows.
    """)
    
    citation_management()

elif integration_mode == "Literature Analysis":
    st.header("📊 Literature Analysis & Trends")
    
    st.markdown("""
    **Analyze publication trends and research patterns** in antimicrobial 
    phytochemistry and wound healing research.
    """)
    
    literature_analysis()

elif integration_mode == "Research Gap Identification":
    st.header("🔍 Research Gap Identification")
    
    st.markdown("""
    **Systematic identification of research gaps** based on literature coverage 
    and experimental data availability.
    """)
    
    # Gap analysis methodology
    gap_analysis_method = st.selectbox(
        "Gap Analysis Method",
        [
            "Pathogen Coverage Analysis",
            "Chemical Class Coverage",
            "Plant Family Analysis", 
            "Experimental Method Gaps",
            "Geographic Coverage Gaps"
        ]
    )
    
    if gap_analysis_method == "Pathogen Coverage Analysis":
        st.subheader("🦠 Pathogen Coverage Analysis")
        
        # Get pathogen coverage data
        pathogen_coverage = execute_query("""
            SELECT aa.pathogen_name, aa.pathogen_type,
                   COUNT(DISTINCT aa.compound_id) as compounds_tested,
                   COUNT(DISTINCT lr.id) as literature_studies,
                   AVG(aa.confidence_score) as avg_confidence,
                   MIN(aa.mic_value) as best_mic,
                   COUNT(aa.id) as total_tests
            FROM antimicrobial_activity aa
            LEFT JOIN literature_references lr ON aa.reference_doi = lr.doi
            GROUP BY aa.pathogen_name, aa.pathogen_type
            ORDER BY compounds_tested DESC, total_tests DESC
        """)
        
        if not pathogen_coverage.empty:
            st.success(f"Found data for {len(pathogen_coverage)} pathogens")
            
            # Visualization of pathogen coverage
            fig = px.scatter(
                pathogen_coverage,
                x='compounds_tested',
                y='total_tests',
                size='literature_studies',
                color='pathogen_type',
                hover_name='pathogen_name',
                title='Pathogen Research Coverage',
                labels={
                    'compounds_tested': 'Number of Compounds Tested',
                    'total_tests': 'Total Number of Tests',
                    'literature_studies': 'Literature Studies'
                }
            )
            st.plotly_chart(fig, use_container_width=True)
            
            # Identify under-researched pathogens
            under_researched = pathogen_coverage[
                (pathogen_coverage['compounds_tested'] < 5) | 
                (pathogen_coverage['total_tests'] < 10)
            ]
            
            if not under_researched.empty:
                st.subheader("⚠️ Under-Researched Pathogens")
                st.markdown("**Pathogens with limited research coverage:**")
                
                for _, pathogen in under_researched.iterrows():
                    with st.expander(f"{pathogen['pathogen_name']} ({pathogen['pathogen_type']})"):
                        col1, col2, col3 = st.columns(3)
                        
                        with col1:
                            st.metric("Compounds Tested", int(pathogen['compounds_tested']))
                        
                        with col2:
                            st.metric("Total Tests", int(pathogen['total_tests']))
                        
                        with col3:
                            if pd.notna(pathogen['avg_confidence']):
                                st.metric("Avg Confidence", f"{pathogen['avg_confidence']:.2f}")
                            else:
                                st.metric("Avg Confidence", "N/A")
                        
                        # Research recommendations
                        st.markdown("**Research Recommendations:**")
                        
                        if pathogen['compounds_tested'] < 5:
                            st.warning("• Expand compound screening against this pathogen")
                        
                        if pathogen['total_tests'] < 10:
                            st.warning("• Increase number of antimicrobial studies")
                        
                        if pd.notna(pathogen['avg_confidence']) and pathogen['avg_confidence'] < 0.7:
                            st.warning("• Improve experimental quality and data confidence")
                        
                        if pd.isna(pathogen['literature_studies']) or pathogen['literature_studies'] < 3:
                            st.warning("• Conduct systematic literature review")
                        
                        # Clinical importance
                        clinical_importance = {
                            'Staphylococcus aureus': 'High - Major cause of wound infections',
                            'Pseudomonas aeruginosa': 'High - Biofilm formation and antibiotic resistance',
                            'Escherichia coli': 'Medium - Common in contaminated wounds',
                            'Candida albicans': 'Medium - Fungal infections in immunocompromised',
                            'MRSA': 'Critical - Methicillin-resistant infections'
                        }
                        
                        importance = clinical_importance.get(pathogen['pathogen_name'], 'Variable')
                        st.info(f"**Clinical Importance:** {importance}")
            
            else:
                st.success("✅ Good research coverage across all pathogens in database")
        
        else:
            st.warning("No pathogen coverage data available")
    
    elif gap_analysis_method == "Chemical Class Coverage":
        st.subheader("⚗️ Chemical Class Coverage Analysis")
        
        # Get chemical class coverage
        class_coverage = execute_query("""
            SELECT ph.chemical_class,
                   COUNT(DISTINCT ph.id) as total_compounds,
                   COUNT(DISTINCT aa.compound_id) as tested_compounds,
                   COUNT(DISTINCT aa.pathogen_name) as pathogens_tested,
                   COUNT(aa.id) as total_activity_records,
                   AVG(aa.confidence_score) as avg_confidence
            FROM phytochemicals ph
            LEFT JOIN antimicrobial_activity aa ON ph.id = aa.compound_id
            WHERE ph.chemical_class IS NOT NULL
            GROUP BY ph.chemical_class
            ORDER BY total_compounds DESC
        """)
        
        if not class_coverage.empty:
            # Calculate testing percentage
            class_coverage['testing_percentage'] = (
                class_coverage['tested_compounds'] / class_coverage['total_compounds'] * 100
            ).fillna(0)
            
            # Visualization
            fig = px.bar(
                class_coverage,
                x='chemical_class',
                y='testing_percentage',
                color='total_activity_records',
                title='Antimicrobial Testing Coverage by Chemical Class',
                labels={
                    'testing_percentage': 'Testing Coverage (%)',
                    'chemical_class': 'Chemical Class',
                    'total_activity_records': 'Activity Records'
                }
            )
            fig.update_layout(xaxis_tickangle=-45)
            st.plotly_chart(fig, use_container_width=True)
            
            # Detailed table
            st.subheader("📊 Chemical Class Coverage Details")
            
            display_coverage = class_coverage.copy()
            display_coverage['testing_percentage'] = display_coverage['testing_percentage'].round(1)
            display_coverage = display_coverage.rename(columns={
                'chemical_class': 'Chemical Class',
                'total_compounds': 'Total Compounds',
                'tested_compounds': 'Tested Compounds',
                'testing_percentage': 'Testing Coverage (%)',
                'pathogens_tested': 'Pathogens Tested',
                'total_activity_records': 'Activity Records'
            })
            
            st.dataframe(display_coverage, use_container_width=True)
            
            # Priority recommendations
            st.subheader("🎯 Research Priorities")
            
            # Under-tested classes with high compound numbers
            priority_classes = class_coverage[
                (class_coverage['total_compounds'] >= 5) & 
                (class_coverage['testing_percentage'] < 50)
            ].sort_values('total_compounds', ascending=False)
            
            if not priority_classes.empty:
                st.markdown("**High Priority Chemical Classes for Testing:**")
                
                for _, chem_class in priority_classes.iterrows():
                    st.warning(
                        f"**{chem_class['chemical_class']}**: "
                        f"{chem_class['total_compounds']} compounds, "
                        f"only {chem_class['testing_percentage']:.1f}% tested"
                    )
            
            # Well-researched classes
            well_researched = class_coverage[
                (class_coverage['testing_percentage'] >= 70) &
                (class_coverage['total_activity_records'] >= 10)
            ]
            
            if not well_researched.empty:
                st.markdown("**Well-Researched Chemical Classes:**")
                
                for _, chem_class in well_researched.iterrows():
                    st.success(
                        f"**{chem_class['chemical_class']}**: "
                        f"{chem_class['testing_percentage']:.1f}% coverage, "
                        f"{chem_class['total_activity_records']} studies"
                    )
        
        else:
            st.warning("No chemical class coverage data available")
    
    elif gap_analysis_method == "Plant Family Analysis":
        st.subheader("🌿 Plant Family Research Coverage")
        
        # Get plant family research coverage
        family_coverage = execute_query("""
            SELECT p.family,
                   COUNT(DISTINCT p.id) as total_plants,
                   COUNT(DISTINCT pc.phytochemical_id) as total_compounds,
                   COUNT(DISTINCT aa.id) as activity_studies,
                   COUNT(DISTINCT aa.pathogen_name) as pathogens_tested,
                   COUNT(CASE WHEN p.traditional_use IS NOT NULL AND p.traditional_use != '' THEN 1 END) as plants_with_traditional_use
            FROM plants p
            LEFT JOIN plant_compounds pc ON p.id = pc.plant_id
            LEFT JOIN antimicrobial_activity aa ON pc.phytochemical_id = aa.compound_id
            WHERE p.family IS NOT NULL
            GROUP BY p.family
            ORDER BY total_plants DESC
        """)
        
        if not family_coverage.empty:
            # Calculate research intensity
            family_coverage['research_intensity'] = (
                family_coverage['activity_studies'] / family_coverage['total_plants']
            ).fillna(0)
            
            family_coverage['traditional_use_percentage'] = (
                family_coverage['plants_with_traditional_use'] / family_coverage['total_plants'] * 100
            ).fillna(0)
            
            # Visualization
            fig = px.scatter(
                family_coverage,
                x='total_plants',
                y='research_intensity',
                size='total_compounds',
                color='traditional_use_percentage',
                hover_name='family',
                title='Plant Family Research Intensity',
                labels={
                    'total_plants': 'Number of Plant Species',
                    'research_intensity': 'Research Intensity (Studies per Plant)',
                    'total_compounds': 'Compounds Identified',
                    'traditional_use_percentage': 'Traditional Use Coverage (%)'
                }
            )
            st.plotly_chart(fig, use_container_width=True)
            
            # Research gap identification
            st.subheader("🔍 Plant Family Research Gaps")
            
            # Large families with low research intensity
            under_researched_families = family_coverage[
                (family_coverage['total_plants'] >= 3) &
                (family_coverage['research_intensity'] < 2)
            ].sort_values('total_plants', ascending=False)
            
            if not under_researched_families.empty:
                st.markdown("**Under-Researched Plant Families:**")
                
                for _, family in under_researched_families.iterrows():
                    with st.expander(f"{family['family']} ({family['total_plants']} species)"):
                        col1, col2, col3 = st.columns(3)
                        
                        with col1:
                            st.metric("Plant Species", int(family['total_plants']))
                            st.metric("Research Intensity", f"{family['research_intensity']:.1f}")
                        
                        with col2:
                            st.metric("Compounds Identified", int(family['total_compounds']))
                            st.metric("Activity Studies", int(family['activity_studies']))
                        
                        with col3:
                            st.metric("Traditional Use Coverage", f"{family['traditional_use_percentage']:.1f}%")
                            st.metric("Pathogens Tested", int(family['pathogens_tested']))
                        
                        # Research recommendations
                        st.markdown("**Research Recommendations:**")
                        
                        if family['research_intensity'] < 1:
                            st.error("• Critical gap: Very low research activity relative to family size")
                        
                        if family['total_compounds'] < family['total_plants']:
                            st.warning("• Expand phytochemical profiling studies")
                        
                        if family['traditional_use_percentage'] < 50:
                            st.warning("• Document traditional medicinal uses")
                        
                        if family['pathogens_tested'] < 5:
                            st.warning("• Broaden antimicrobial screening")
        
        else:
            st.warning("No plant family coverage data available")
    
    elif gap_analysis_method == "Experimental Method Gaps":
        st.subheader("🧪 Experimental Method Coverage")
        
        # Analyze testing methods used
        method_coverage = execute_query("""
            SELECT test_method,
                   COUNT(*) as usage_count,
                   COUNT(DISTINCT compound_id) as compounds_tested,
                   COUNT(DISTINCT pathogen_name) as pathogens_tested,
                   AVG(confidence_score) as avg_confidence
            FROM antimicrobial_activity
            WHERE test_method IS NOT NULL
            GROUP BY test_method
            ORDER BY usage_count DESC
        """)
        
        if not method_coverage.empty:
            # Method usage visualization
            fig = px.bar(
                method_coverage,
                x='test_method',
                y='usage_count',
                color='avg_confidence',
                title='Antimicrobial Testing Method Usage',
                labels={
                    'test_method': 'Testing Method',
                    'usage_count': 'Number of Studies',
                    'avg_confidence': 'Average Confidence'
                }
            )
            fig.update_layout(xaxis_tickangle=-45)
            st.plotly_chart(fig, use_container_width=True)
            
            # Method comparison table
            st.dataframe(method_coverage, use_container_width=True)
            
            # Method standardization recommendations
            st.subheader("📋 Method Standardization Recommendations")
            
            # Check for method diversity
            total_studies = execute_query("SELECT COUNT(*) as count FROM antimicrobial_activity")
            studies_with_method = execute_query("""
                SELECT COUNT(*) as count FROM antimicrobial_activity 
                WHERE test_method IS NOT NULL
            """)
            
            if not total_studies.empty and not studies_with_method.empty:
                method_documentation_rate = (
                    studies_with_method.iloc[0]['count'] / total_studies.iloc[0]['count'] * 100
                )
                
                st.metric("Method Documentation Rate", f"{method_documentation_rate:.1f}%")
                
                if method_documentation_rate < 80:
                    st.error("• Improve documentation of experimental methods")
                
                # Check for standardized methods
                standard_methods = ['Disc diffusion', 'Broth microdilution', 'Agar dilution']
                standard_method_usage = method_coverage[
                    method_coverage['test_method'].isin(standard_methods)
                ]['usage_count'].sum()
                
                total_method_usage = method_coverage['usage_count'].sum()
                standard_method_percentage = (standard_method_usage / total_method_usage * 100)
                
                st.metric("Standard Method Usage", f"{standard_method_percentage:.1f}%")
                
                if standard_method_percentage < 70:
                    st.warning("• Increase use of standardized testing methods (CLSI/EUCAST guidelines)")
                
                # Identify missing advanced methods
                advanced_methods = ['Time-kill assay', 'Biofilm assay', 'Resistance development']
                missing_advanced = [
                    method for method in advanced_methods
                    if method not in method_coverage['test_method'].values
                ]
                
                if missing_advanced:
                    st.info("**Advanced Methods to Implement:**")
                    for method in missing_advanced:
                        st.write(f"• {method}")
        
        else:
            st.warning("No experimental method data available")

elif integration_mode == "Publication Trends":
    st.header("📈 Publication Trends Analysis")
    
    st.markdown("""
    **Comprehensive analysis of publication trends** in antimicrobial phytochemistry 
    and wound healing research over time.
    """)
    
    # Publication trends over time
    publication_trends = execute_query("""
        SELECT publication_year,
               COUNT(*) as publication_count,
               COUNT(CASE WHEN study_type = 'in_vitro' THEN 1 END) as in_vitro_studies,
               COUNT(CASE WHEN study_type = 'in_vivo' THEN 1 END) as in_vivo_studies,
               COUNT(CASE WHEN study_type = 'clinical_trial' THEN 1 END) as clinical_trials,
               COUNT(CASE WHEN study_type = 'review' THEN 1 END) as reviews,
               AVG(confidence_rating) as avg_quality_rating
        FROM literature_references
        WHERE publication_year IS NOT NULL 
        AND publication_year >= 2000 
        AND publication_year <= 2025
        GROUP BY publication_year
        ORDER BY publication_year
    """)
    
    if not publication_trends.empty:
        st.subheader("📊 Publications by Year")
        
        # Overall trend
        fig = px.line(
            publication_trends,
            x='publication_year',
            y='publication_count',
            title='Annual Publication Count',
            labels={
                'publication_year': 'Year',
                'publication_count': 'Number of Publications'
            }
        )
        st.plotly_chart(fig, use_container_width=True)
        
        # Study type trends
        st.subheader("🔬 Study Type Distribution Over Time")
        
        study_type_cols = ['in_vitro_studies', 'in_vivo_studies', 'clinical_trials', 'reviews']
        
        fig = go.Figure()
        
        for col in study_type_cols:
            fig.add_trace(go.Scatter(
                x=publication_trends['publication_year'],
                y=publication_trends[col],
                mode='lines+markers',
                name=col.replace('_', ' ').title()
            ))
        
        fig.update_layout(
            title='Study Types Over Time',
            xaxis_title='Year',
            yaxis_title='Number of Studies'
        )
        
        st.plotly_chart(fig, use_container_width=True)
        
        # Research quality trends
        st.subheader("⭐ Research Quality Trends")
        
        quality_trends = publication_trends[publication_trends['avg_quality_rating'].notna()]
        
        if not quality_trends.empty:
            fig = px.line(
                quality_trends,
                x='publication_year',
                y='avg_quality_rating',
                title='Average Research Quality Rating Over Time',
                labels={
                    'publication_year': 'Year',
                    'avg_quality_rating': 'Average Quality Rating (1-5)'
                }
            )
            fig.update_yaxis(range=[1, 5])
            st.plotly_chart(fig, use_container_width=True)
        
        # Growth rate analysis
        st.subheader("📈 Growth Rate Analysis")
        
        if len(publication_trends) >= 5:
            recent_years = publication_trends.tail(5)
            older_years = publication_trends.head(5)
            
            recent_avg = recent_years['publication_count'].mean()
            older_avg = older_years['publication_count'].mean()
            
            if older_avg > 0:
                growth_rate = ((recent_avg - older_avg) / older_avg) * 100
                
                col1, col2, col3 = st.columns(3)
                
                with col1:
                    st.metric("Recent Years Average", f"{recent_avg:.1f} publications/year")
                
                with col2:
                    st.metric("Earlier Years Average", f"{older_avg:.1f} publications/year")
                
                with col3:
                    st.metric("Growth Rate", f"{growth_rate:+.1f}%")
                
                if growth_rate > 10:
                    st.success("📈 Strong growth in research activity")
                elif growth_rate > 0:
                    st.info("📊 Steady growth in research activity")
                else:
                    st.warning("📉 Declining research activity")
    
    else:
        st.warning("No publication trend data available")
    
    # Journal analysis
    st.subheader("📰 Journal Distribution Analysis")
    
    journal_analysis = execute_query("""
        SELECT journal,
               COUNT(*) as publication_count,
               AVG(confidence_rating) as avg_quality,
               MIN(publication_year) as first_publication,
               MAX(publication_year) as latest_publication
        FROM literature_references
        WHERE journal IS NOT NULL
        GROUP BY journal
        HAVING COUNT(*) >= 2
        ORDER BY publication_count DESC
        LIMIT 20
    """)
    
    if not journal_analysis.empty:
        # Top journals
        fig = px.bar(
            journal_analysis.head(10),
            x='journal',
            y='publication_count',
            color='avg_quality',
            title='Top 10 Journals by Publication Count',
            labels={
                'journal': 'Journal',
                'publication_count': 'Number of Publications',
                'avg_quality': 'Average Quality Rating'
            }
        )
        fig.update_layout(xaxis_tickangle=-45)
        st.plotly_chart(fig, use_container_width=True)
        
        # Journal metrics table
        display_journals = journal_analysis.copy()
        display_journals['avg_quality'] = display_journals['avg_quality'].round(2)
        st.dataframe(display_journals, use_container_width=True)

elif integration_mode == "Evidence Quality Assessment":
    st.header("⭐ Evidence Quality Assessment")
    
    st.markdown("""
    **Systematic assessment of evidence quality** across the literature database 
    with identification of high-confidence and low-confidence studies.
    """)
    
    # Overall evidence quality metrics
    quality_metrics = execute_query("""
        SELECT 
            COUNT(*) as total_references,
            COUNT(CASE WHEN confidence_rating >= 4 THEN 1 END) as high_quality,
            COUNT(CASE WHEN confidence_rating = 3 THEN 1 END) as medium_quality,
            COUNT(CASE WHEN confidence_rating <= 2 THEN 1 END) as low_quality,
            AVG(confidence_rating) as overall_avg_quality,
            COUNT(CASE WHEN doi IS NOT NULL AND doi != '' THEN 1 END) as with_doi,
            COUNT(CASE WHEN study_type IS NOT NULL THEN 1 END) as with_study_type
        FROM literature_references
    """)
    
    if not quality_metrics.empty:
        metrics = quality_metrics.iloc[0]
        
        st.subheader("📊 Overall Evidence Quality")
        
        col1, col2, col3, col4 = st.columns(4)
        
        with col1:
            st.metric("Total References", int(metrics['total_references']))
            
            if metrics['total_references'] > 0:
                doi_percentage = (metrics['with_doi'] / metrics['total_references']) * 100
                st.metric("References with DOI", f"{doi_percentage:.1f}%")
        
        with col2:
            st.metric("High Quality (4-5⭐)", int(metrics['high_quality']))
            
            if metrics['total_references'] > 0:
                study_type_percentage = (metrics['with_study_type'] / metrics['total_references']) * 100
                st.metric("Study Type Documented", f"{study_type_percentage:.1f}%")
        
        with col3:
            st.metric("Medium Quality (3⭐)", int(metrics['medium_quality']))
            
            if pd.notna(metrics['overall_avg_quality']):
                st.metric("Average Quality", f"{metrics['overall_avg_quality']:.2f}⭐")
        
        with col4:
            st.metric("Low Quality (1-2⭐)", int(metrics['low_quality']))
            
            if metrics['total_references'] > 0:
                high_quality_percentage = (metrics['high_quality'] / metrics['total_references']) * 100
                st.metric("High Quality Rate", f"{high_quality_percentage:.1f}%")
        
        # Quality distribution visualization
        quality_dist_data = {
            'Quality Level': ['High (4-5⭐)', 'Medium (3⭐)', 'Low (1-2⭐)'],
            'Count': [int(metrics['high_quality']), int(metrics['medium_quality']), int(metrics['low_quality'])],
            'Color': ['green', 'yellow', 'red']
        }
        
        quality_dist_df = pd.DataFrame(quality_dist_data)
        
        fig = px.pie(
            quality_dist_df,
            values='Count',
            names='Quality Level',
            title='Evidence Quality Distribution',
            color='Quality Level',
            color_discrete_map={
                'High (4-5⭐)': 'green',
                'Medium (3⭐)': 'gold',
                'Low (1-2⭐)': 'red'
            }
        )
        st.plotly_chart(fig, use_container_width=True)
    
    # Study type quality analysis
    st.subheader("🔬 Quality by Study Type")
    
    study_type_quality = execute_query("""
        SELECT study_type,
               COUNT(*) as study_count,
               AVG(confidence_rating) as avg_quality,
               COUNT(CASE WHEN confidence_rating >= 4 THEN 1 END) as high_quality_count,
               COUNT(CASE WHEN doi IS NOT NULL AND doi != '' THEN 1 END) as with_doi_count
        FROM literature_references
        WHERE study_type IS NOT NULL
        GROUP BY study_type
        ORDER BY avg_quality DESC
    """)
    
    if not study_type_quality.empty:
        # Calculate percentages
        study_type_quality['high_quality_percentage'] = (
            study_type_quality['high_quality_count'] / study_type_quality['study_count'] * 100
        )
        study_type_quality['doi_percentage'] = (
            study_type_quality['with_doi_count'] / study_type_quality['study_count'] * 100
        )
        
        # Visualization
        fig = px.bar(
            study_type_quality,
            x='study_type',
            y='avg_quality',
            color='high_quality_percentage',
            title='Average Quality Rating by Study Type',
            labels={
                'study_type': 'Study Type',
                'avg_quality': 'Average Quality Rating',
                'high_quality_percentage': 'High Quality %'
            }
        )
        st.plotly_chart(fig, use_container_width=True)
        
        # Detailed table
        display_study_types = study_type_quality.copy()
        display_study_types['avg_quality'] = display_study_types['avg_quality'].round(2)
        display_study_types['high_quality_percentage'] = display_study_types['high_quality_percentage'].round(1)
        display_study_types['doi_percentage'] = display_study_types['doi_percentage'].round(1)
        
        st.dataframe(display_study_types, use_container_width=True)
    
    # High-quality studies showcase
    st.subheader("🏆 High-Quality Studies")
    
    high_quality_studies = execute_query("""
        SELECT title, authors, journal, publication_year, 
               study_type, confidence_rating, doi
        FROM literature_references
        WHERE confidence_rating >= 4
        ORDER BY confidence_rating DESC, publication_year DESC
        LIMIT 20
    """)
    
    if not high_quality_studies.empty:
        st.markdown(f"**Showing top {len(high_quality_studies)} high-quality studies:**")
        
        for _, study in high_quality_studies.iterrows():
            with st.expander(f"⭐{study['confidence_rating']} - {study['title'][:80]}..."):
                col1, col2 = st.columns([2, 1])
                
                with col1:
                    st.write(f"**Authors:** {study['authors'] or 'Not specified'}")
                    st.write(f"**Journal:** {study['journal'] or 'Not specified'}")
                    st.write(f"**Study Type:** {study['study_type'] or 'Not specified'}")
                
                with col2:
                    st.metric("Quality Rating", f"{study['confidence_rating']}⭐")
                    st.metric("Year", study['publication_year'] or 'Unknown')
                
                if study['doi']:
                    st.write(f"**DOI:** {study['doi']}")
                    st.markdown(f"[View Publication](https://doi.org/{study['doi']})")
    
    else:
        st.info("No high-quality studies found in database")
    
    # Quality improvement recommendations
    st.subheader("💡 Quality Improvement Recommendations")
    
    recommendations = []
    
    if not quality_metrics.empty:
        metrics = quality_metrics.iloc[0]
        
        if metrics['total_references'] > 0:
            high_quality_rate = (metrics['high_quality'] / metrics['total_references']) * 100
            doi_rate = (metrics['with_doi'] / metrics['total_references']) * 100
            study_type_rate = (metrics['with_study_type'] / metrics['total_references']) * 100
            
            if high_quality_rate < 50:
                recommendations.append("Prioritize inclusion of higher quality studies (systematic reviews, well-designed RCTs)")
            
            if doi_rate < 80:
                recommendations.append("Improve DOI coverage for better citation tracking and verification")
            
            if study_type_rate < 90:
                recommendations.append("Ensure all references have documented study types")
            
            if pd.notna(metrics['overall_avg_quality']) and metrics['overall_avg_quality'] < 3.5:
                recommendations.append("Focus on including studies with stronger methodological quality")
    
    if recommendations:
        for rec in recommendations:
            st.warning(f"• {rec}")
    else:
        st.success("✅ Good overall evidence quality standards maintained")

# Footer
st.markdown("---")
st.markdown("""
<div style='text-align: center; color: #666;'>
<p><strong>Literature Integration Platform</strong> | Systematic evidence synthesis and analysis</p>
<p>Ensuring reproducible research through comprehensive citation management and quality assessment</p>
</div>
""", unsafe_allow_html=True)
