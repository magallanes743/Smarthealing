import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from phytochemical_db import (
    search_plants, search_compounds, get_plant_details, get_compound_details,
    get_plant_families, get_phytochemical_families, create_activity_visualization,
    create_compound_distribution_chart, create_plant_family_chart, create_activity_heatmap
)
from scoring_system import MultiEvidenceScorer, rank_compounds_by_evidence
from database import execute_query
import warnings
warnings.filterwarnings('ignore')

st.set_page_config(
    page_title="Phytochemical Database",
    page_icon="🔬",
    layout="wide"
)

st.title("🔬 Phytochemical Database")
st.markdown("**Comprehensive database of plant species, phytochemicals, and antimicrobial properties**")

# Sidebar filters and search
st.sidebar.header("Search & Filter Options")

search_mode = st.sidebar.selectbox(
    "Search Mode",
    ["Plants", "Compounds", "Browse Database"]
)

if search_mode == "Plants":
    st.header("🌿 Plant Species Search")
    
    # Search filters
    col1, col2 = st.columns([2, 1])
    
    with col1:
        search_term = st.text_input(
            "Search Plants",
            placeholder="Enter scientific name, common name, or keyword..."
        )
    
    with col2:
        plant_families = get_plant_families()
        family_filter = st.selectbox(
            "Filter by Family",
            [""] + plant_families
        )
    
    activity_filter = st.text_input(
        "Filter by Biological Activity",
        placeholder="e.g., antimicrobial, antioxidant..."
    )
    
    # Search execution
    if st.button("Search Plants") or search_term or family_filter or activity_filter:
        with st.spinner("Searching plant database..."):
            results = search_plants(search_term, family_filter, activity_filter)
        
        if not results.empty:
            st.success(f"Found {len(results)} plant species")
            
            # Results display
            for idx, plant in results.iterrows():
                with st.expander(f"{plant['scientific_name']} ({plant['common_name'] or 'No common name'})"):
                    col1, col2 = st.columns([2, 1])
                    
                    with col1:
                        st.write(f"**Family:** {plant['family'] or 'Unknown'}")
                        st.write(f"**Traditional Use:** {plant['traditional_use'] or 'Not specified'}")
                        st.write(f"**Compounds Identified:** {plant['compound_count']}")
                    
                    with col2:
                        if st.button(f"View Details", key=f"plant_{plant['id']}"):
                            st.session_state.selected_plant_id = plant['id']
                            st.session_state.show_plant_details = True
            
            # Detailed view for selected plant
            if st.session_state.get('show_plant_details') and st.session_state.get('selected_plant_id'):
                plant_id = st.session_state.selected_plant_id
                plant_data, compounds_data, activity_data = get_plant_details(plant_id)
                
                if plant_data is not None:
                    st.markdown("---")
                    st.subheader(f"📋 Detailed View: {plant_data['scientific_name']}")
                    
                    # Plant information
                    info_col1, info_col2 = st.columns(2)
                    
                    with info_col1:
                        st.markdown("**Basic Information**")
                        st.write(f"**Scientific Name:** {plant_data['scientific_name']}")
                        st.write(f"**Common Name:** {plant_data['common_name'] or 'Not specified'}")
                        st.write(f"**Family:** {plant_data['family'] or 'Unknown'}")
                    
                    with info_col2:
                        st.markdown("**Traditional & Safety Information**")
                        st.write(f"**Traditional Use:** {plant_data['traditional_use'] or 'Not documented'}")
                        st.write(f"**Safety Profile:** {plant_data['safety_profile'] or 'Not documented'}")
                    
                    # Compounds table
                    if not compounds_data.empty:
                        st.subheader("🧪 Identified Phytochemicals")
                        st.dataframe(
                            compounds_data[['name', 'chemical_class', 'molecular_weight', 'concentration_range', 'biological_activity']],
                            use_container_width=True
                        )
                    else:
                        st.info("No phytochemical data available for this plant")
                    
                    # Activity data visualization
                    if not activity_data.empty:
                        st.subheader("🦠 Antimicrobial Activity Data")
                        
                        # Activity chart
                        activity_fig = create_activity_visualization(activity_data)
                        if activity_fig:
                            st.plotly_chart(activity_fig, use_container_width=True)
                        
                        # Activity table
                        st.dataframe(activity_data, use_container_width=True)
                    else:
                        st.info("No antimicrobial activity data available")
                    
                    if st.button("Close Details"):
                        st.session_state.show_plant_details = False
                        st.session_state.selected_plant_id = None
                        st.rerun()
        else:
            st.warning("No plants found matching your search criteria")

elif search_mode == "Compounds":
    st.header("⚗️ Phytochemical Search")
    
    # Search filters
    col1, col2 = st.columns([2, 1])
    
    with col1:
        compound_search = st.text_input(
            "Search Compounds",
            placeholder="Enter compound name or keyword..."
        )
    
    with col2:
        chemical_families = get_phytochemical_families()
        class_filter = st.selectbox(
            "Filter by Chemical Class",
            [""] + chemical_families
        )
    
    bio_activity_filter = st.text_input(
        "Filter by Biological Activity",
        placeholder="e.g., antimicrobial, anti-inflammatory..."
    )
    
    # Search execution
    if st.button("Search Compounds") or compound_search or class_filter or bio_activity_filter:
        with st.spinner("Searching compound database..."):
            compound_results = search_compounds(compound_search, class_filter, bio_activity_filter)
        
        if not compound_results.empty:
            st.success(f"Found {len(compound_results)} compounds")
            
            # Ranking option
            if len(compound_results) > 1:
                col1, col2 = st.columns([2, 1])
                
                with col1:
                    wound_type_for_ranking = st.selectbox(
                        "Rank compounds for wound type:",
                        ["general", "acute", "chronic", "infected", "burn", "surgical"]
                    )
                
                with col2:
                    if st.button("Rank by Evidence"):
                        with st.spinner("Calculating multi-evidence scores..."):
                            ranked_compounds = rank_compounds_by_evidence(compound_results, wound_type_for_ranking)
                            
                            if not ranked_compounds.empty:
                                st.subheader("📊 Evidence-Based Ranking")
                                
                                # Create ranking visualization
                                fig = px.bar(
                                    ranked_compounds.head(10),
                                    x='compound_name',
                                    y='overall_score',
                                    color='evidence_strength',
                                    title=f'Top 10 Compounds for {wound_type_for_ranking.title()} Wounds',
                                    labels={'overall_score': 'Overall Score', 'compound_name': 'Compound'}
                                )
                                fig.update_layout(xaxis_tickangle=-45)
                                st.plotly_chart(fig, use_container_width=True)
                                
                                # Show ranking table
                                st.dataframe(
                                    ranked_compounds[['compound_name', 'overall_score', 'overall_confidence', 'evidence_strength']],
                                    use_container_width=True
                                )
            
            # Results display
            for idx, compound in compound_results.iterrows():
                with st.expander(f"{compound['name']} ({compound['chemical_class'] or 'Unknown class'})"):
                    col1, col2 = st.columns([2, 1])
                    
                    with col1:
                        st.write(f"**Chemical Formula:** {compound['chemical_formula'] or 'Unknown'}")
                        st.write(f"**Molecular Weight:** {compound['molecular_weight'] or 'Unknown'} g/mol")
                        st.write(f"**Biological Activity:** {compound['biological_activity'] or 'Not specified'}")
                        st.write(f"**Found in Plants:** {compound['plant_count']}")
                        st.write(f"**Activity Records:** {compound['activity_records']}")
                    
                    with col2:
                        if st.button(f"View Details", key=f"compound_{compound['id']}"):
                            st.session_state.selected_compound_id = compound['id']
                            st.session_state.show_compound_details = True
            
            # Detailed view for selected compound
            if st.session_state.get('show_compound_details') and st.session_state.get('selected_compound_id'):
                compound_id = st.session_state.selected_compound_id
                compound_data, plants_data, activity_data, admet_data, docking_data = get_compound_details(compound_id)
                
                if compound_data is not None:
                    st.markdown("---")
                    st.subheader(f"📋 Detailed View: {compound_data['name']}")
                    
                    # Compound information
                    info_col1, info_col2 = st.columns(2)
                    
                    with info_col1:
                        st.markdown("**Chemical Properties**")
                        st.write(f"**Name:** {compound_data['name']}")
                        st.write(f"**Chemical Formula:** {compound_data['chemical_formula'] or 'Unknown'}")
                        st.write(f"**Molecular Weight:** {compound_data['molecular_weight'] or 'Unknown'} g/mol")
                        st.write(f"**Chemical Class:** {compound_data['chemical_class'] or 'Unknown'}")
                        if compound_data['smiles']:
                            st.write(f"**SMILES:** {compound_data['smiles']}")
                    
                    with info_col2:
                        st.markdown("**Biological Information**")
                        st.write(f"**Biological Activity:** {compound_data['biological_activity'] or 'Not specified'}")
                        
                        # Multi-evidence scoring
                        if st.button("Calculate Evidence Score", key="calc_evidence"):
                            scorer = MultiEvidenceScorer()
                            compound_dict = {
                                'molecular_weight': compound_data['molecular_weight'],
                                'chemical_class': compound_data['chemical_class'],
                                'name': compound_data['name']
                            }
                            
                            with st.spinner("Calculating multi-evidence score..."):
                                score_result = scorer.calculate_overall_score(compound_id, compound_dict)
                            
                            st.metric("Overall Score", f"{score_result['overall_score']}/100")
                            st.metric("Confidence", f"{score_result['overall_confidence']:.2f}")
                            st.write(f"**Evidence Strength:** {score_result['evidence_strength']}")
                    
                    # Plants containing this compound
                    if not plants_data.empty:
                        st.subheader("🌿 Plant Sources")
                        st.dataframe(plants_data, use_container_width=True)
                    
                    # Activity data
                    if not activity_data.empty:
                        st.subheader("🦠 Antimicrobial Activity")
                        activity_fig = create_activity_visualization(activity_data)
                        if activity_fig:
                            st.plotly_chart(activity_fig, use_container_width=True)
                        st.dataframe(activity_data, use_container_width=True)
                    
                    # ADMET properties
                    if not admet_data.empty:
                        st.subheader("💊 ADMET Properties")
                        admet_info = admet_data.iloc[0]
                        
                        admet_col1, admet_col2 = st.columns(2)
                        with admet_col1:
                            st.metric("Absorption", f"{admet_info['absorption'] or 'Unknown'}")
                            st.metric("Toxicity Score", f"{admet_info['toxicity_score'] or 'Unknown'}")
                        
                        with admet_col2:
                            st.metric("Skin Permeability", f"{admet_info['skin_permeability'] or 'Unknown'}")
                            st.metric("Solubility", f"{admet_info['solubility'] or 'Unknown'}")
                    
                    # Docking results
                    if not docking_data.empty:
                        st.subheader("🔗 Molecular Docking Results")
                        st.dataframe(docking_data, use_container_width=True)
                    
                    if st.button("Close Details"):
                        st.session_state.show_compound_details = False
                        st.session_state.selected_compound_id = None
                        st.rerun()
        else:
            st.warning("No compounds found matching your search criteria")

elif search_mode == "Browse Database":
    st.header("📊 Database Overview & Statistics")
    
    # Database statistics
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        plants_count = execute_query("SELECT COUNT(*) as count FROM plants")
        st.metric("Plant Species", plants_count.iloc[0]['count'] if not plants_count.empty else 0)
    
    with col2:
        compounds_count = execute_query("SELECT COUNT(*) as count FROM phytochemicals")
        st.metric("Phytochemicals", compounds_count.iloc[0]['count'] if not compounds_count.empty else 0)
    
    with col3:
        activity_count = execute_query("SELECT COUNT(*) as count FROM antimicrobial_activity")
        st.metric("Activity Records", activity_count.iloc[0]['count'] if not activity_count.empty else 0)
    
    with col4:
        unique_pathogens = execute_query("SELECT COUNT(DISTINCT pathogen_name) as count FROM antimicrobial_activity")
        st.metric("Unique Pathogens", unique_pathogens.iloc[0]['count'] if not unique_pathogens.empty else 0)
    
    # Visualizations
    col1, col2 = st.columns(2)
    
    with col1:
        # Compound distribution chart
        compound_dist_fig = create_compound_distribution_chart()
        if compound_dist_fig:
            st.plotly_chart(compound_dist_fig, use_container_width=True)
        else:
            st.info("No compound distribution data available")
    
    with col2:
        # Plant family chart
        plant_family_fig = create_plant_family_chart()
        if plant_family_fig:
            st.plotly_chart(plant_family_fig, use_container_width=True)
        else:
            st.info("No plant family data available")
    
    # Activity heatmap
    st.subheader("🔥 Antimicrobial Activity Heatmap")
    activity_heatmap = create_activity_heatmap()
    if activity_heatmap:
        st.plotly_chart(activity_heatmap, use_container_width=True)
    else:
        st.info("No activity data available for heatmap visualization")
    
    # Recent additions
    st.subheader("🆕 Recent Database Additions")
    
    tab1, tab2 = st.tabs(["Recent Plants", "Recent Compounds"])
    
    with tab1:
        recent_plants = execute_query("""
            SELECT scientific_name, common_name, family, created_at
            FROM plants 
            ORDER BY created_at DESC 
            LIMIT 10
        """)
        
        if not recent_plants.empty:
            st.dataframe(recent_plants, use_container_width=True)
        else:
            st.info("No recent plant additions")
    
    with tab2:
        recent_compounds = execute_query("""
            SELECT name, chemical_class, molecular_weight, created_at
            FROM phytochemicals 
            ORDER BY created_at DESC 
            LIMIT 10
        """)
        
        if not recent_compounds.empty:
            st.dataframe(recent_compounds, use_container_width=True)
        else:
            st.info("No recent compound additions")

# Footer
st.markdown("---")
st.markdown("""
<div style='text-align: center; color: #666;'>
<p><strong>Phytochemical Database</strong> | Evidence-based antimicrobial research platform</p>
<p>Data sources: Peer-reviewed literature and experimental studies</p>
</div>
""", unsafe_allow_html=True)

