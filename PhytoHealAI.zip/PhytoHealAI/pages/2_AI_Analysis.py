import streamlit as st
import pandas as pd
import json
import plotly.express as px
import plotly.graph_objects as go
from ai_analysis import (
    analyze_antimicrobial_potential, generate_formulation_recommendations, 
    predict_drug_drug_interactions
)
from database import execute_query
from phytochemical_db import search_compounds, get_compound_details
from scoring_system import MultiEvidenceScorer
from utils import create_evidence_summary, format_uncertainty_display
import warnings
warnings.filterwarnings('ignore')

st.set_page_config(
    page_title="AI Analysis",
    page_icon="🤖",
    layout="wide"
)

st.title("🤖 AI-Powered Scientific Analysis")
st.markdown("**Advanced AI analysis for antimicrobial discovery and wound-healing formulation**")

# Analysis mode selection
analysis_mode = st.selectbox(
    "Select Analysis Type",
    [
        "Compound Antimicrobial Potential",
        "Formulation Recommendations", 
        "Drug-Drug Interactions",
        "Multi-Evidence Scoring",
        "Batch Analysis"
    ]
)

if analysis_mode == "Compound Antimicrobial Potential":
    st.header("🔬 Antimicrobial Potential Analysis")
    
    st.markdown("""
    **Scientific Approach**: This analysis combines computational predictions with literature evidence
    to assess antimicrobial potential. Results are hypothesis-generating and require experimental validation.
    """)
    
    # Compound selection
    col1, col2 = st.columns([2, 1])
    
    with col1:
        compound_search = st.text_input(
            "Search Compound",
            placeholder="Enter compound name..."
        )
        
        if compound_search:
            compounds = search_compounds(compound_search)
            
            if not compounds.empty:
                compound_options = [f"{row['name']} ({row['chemical_class'] or 'Unknown class'})" 
                                  for _, row in compounds.iterrows()]
                selected_compound_idx = st.selectbox(
                    "Select Compound",
                    range(len(compound_options)),
                    format_func=lambda x: compound_options[x]
                )
                
                selected_compound = compounds.iloc[selected_compound_idx]
    
    with col2:
        st.markdown("**Target Parameters**")
        
        pathogen_name = st.text_input(
            "Target Pathogen",
            value="Staphylococcus aureus",
            help="Scientific name of target microorganism"
        )
        
        pathogen_type = st.selectbox(
            "Pathogen Type",
            ["bacteria", "fungus", "virus", "parasite"]
        )
        
        wound_type = st.selectbox(
            "Wound Type",
            ["acute", "chronic", "infected", "burn", "surgical", "general"]
        )
    
    # Analysis execution
    if st.button("Analyze Antimicrobial Potential") and 'selected_compound' in locals():
        with st.spinner("Performing AI analysis... This may take a moment."):
            
            # Prepare compound data (convert Decimal to float for JSON serialization)
            compound_data = {
                'name': selected_compound['name'],
                'formula': selected_compound['chemical_formula'],
                'molecular_weight': float(selected_compound['molecular_weight']) if selected_compound['molecular_weight'] is not None else None,
                'chemical_class': selected_compound['chemical_class'],
                'biological_activity': selected_compound['biological_activity']
            }
            
            # Prepare pathogen info
            pathogen_info = {
                'name': pathogen_name,
                'type': pathogen_type,
                'resistance_profile': 'Unknown'  # Could be enhanced with database lookup
            }
            
            # Prepare wound characteristics
            wound_characteristics = {
                'type': wound_type,
                'environment': 'Variable',
                'healing_stage': 'All stages'
            }
            
            # Perform analysis
            analysis_result, confidence = analyze_antimicrobial_potential(
                compound_data, pathogen_info, wound_characteristics
            )
        
        if 'error' not in analysis_result:
            # Display results
            st.success("Analysis completed successfully!")
            
            # Overall score and confidence
            col1, col2, col3 = st.columns(3)
            
            with col1:
                st.metric("Overall Score", f"{analysis_result['overall_score']}/100")
            
            with col2:
                st.metric("AI Confidence", f"{confidence:.2f}")
            
            with col3:
                evidence_strength = analysis_result.get('confidence_assessment', {}).get('evidence_strength', 'Unknown')
                st.metric("Evidence Strength", evidence_strength.title())
            
            # Evidence breakdown
            st.subheader("📊 Evidence Breakdown")
            
            evidence_scores = analysis_result.get('evidence_scores', {})
            
            if evidence_scores:
                # Create evidence visualization
                score_df = pd.DataFrame([
                    {'Evidence Type': k.replace('_', ' ').title(), 'Score': v}
                    for k, v in evidence_scores.items()
                ])
                
                fig = px.bar(
                    score_df,
                    x='Evidence Type',
                    y='Score',
                    title='Evidence Scores by Category',
                    color='Score',
                    color_continuous_scale='RdYlGn'
                )
                fig.update_layout(showlegend=False)
                st.plotly_chart(fig, use_container_width=True)
                
                # Evidence details table
                evidence_details = []
                for evidence_type, score in evidence_scores.items():
                    evidence_details.append({
                        'Evidence Type': evidence_type.replace('_', ' ').title(),
                        'Score': f"{score}/100",
                        'Interpretation': (
                            "Strong evidence" if score >= 70 else
                            "Moderate evidence" if score >= 50 else
                            "Limited evidence"
                        )
                    })
                
                st.dataframe(pd.DataFrame(evidence_details), use_container_width=True)
            
            # Predictions
            st.subheader("🔮 Predictions")
            
            predictions = analysis_result.get('predictions', {})
            
            pred_col1, pred_col2, pred_col3 = st.columns(3)
            
            with pred_col1:
                mic_estimate = predictions.get('mic_range_estimate', 'Unknown')
                st.metric("MIC Range Estimate", mic_estimate)
            
            with pred_col2:
                skin_penetration = predictions.get('skin_penetration', 'Unknown')
                st.metric("Skin Penetration", skin_penetration.title())
            
            with pred_col3:
                safety_profile = predictions.get('safety_profile', 'Unknown')
                st.metric("Safety Profile", safety_profile.title())
            
            # Uncertainties and recommendations
            col1, col2 = st.columns(2)
            
            with col1:
                st.subheader("⚠️ Uncertainties")
                uncertainties = analysis_result.get('uncertainties', [])
                
                if uncertainties:
                    for uncertainty in uncertainties:
                        st.warning(f"• {uncertainty}")
                else:
                    st.info("No major uncertainties identified")
            
            with col2:
                st.subheader("🧪 Recommended Experiments")
                experiments = analysis_result.get('recommended_experiments', [])
                
                if experiments:
                    for experiment in experiments:
                        st.info(f"• {experiment}")
                else:
                    st.success("No additional experiments recommended")
            
            # Machine-readable output
            st.subheader("📄 Machine-Readable Output")
            
            with st.expander("View JSON Output"):
                output_data = {
                    "analysis_metadata": {
                        "compound": compound_data,
                        "target_pathogen": pathogen_info,
                        "wound_context": wound_characteristics,
                        "analysis_timestamp": pd.Timestamp.now().isoformat(),
                        "ai_model": "gpt-5",
                        "confidence_score": confidence
                    },
                    "results": analysis_result
                }
                
                st.json(output_data)
                
                # Download option
                json_str = json.dumps(output_data, indent=2)
                st.download_button(
                    label="Download Analysis Results",
                    data=json_str,
                    file_name=f"antimicrobial_analysis_{compound_data['name'].replace(' ', '_')}.json",
                    mime="application/json"
                )
        
        else:
            st.error(f"Analysis failed: {analysis_result.get('message', 'Unknown error')}")

elif analysis_mode == "Formulation Recommendations":
    st.header("💊 Formulation Recommendations")
    
    st.markdown("""
    **Pharmaceutical Formulation Design**: AI-generated recommendations for wound treatment formulations
    based on phytochemical properties and target applications.
    """)
    
    # Compound selection for formulation
    st.subheader("Select Compounds for Formulation")
    
    # Multiple compound selection
    selected_compounds = []
    
    for i in range(3):  # Allow up to 3 compounds
        col1, col2 = st.columns([2, 1])
        
        with col1:
            compound_search = st.text_input(
                f"Compound {i+1} (optional)" if i > 0 else "Primary Compound *",
                key=f"formulation_compound_{i}",
                placeholder="Search compound name..."
            )
            
            if compound_search:
                compounds = search_compounds(compound_search)
                
                if not compounds.empty:
                    compound_options = [f"{row['name']} ({row['chemical_class'] or 'Unknown'})" 
                                      for _, row in compounds.iterrows()]
                    selected_idx = st.selectbox(
                        f"Select Compound {i+1}",
                        range(len(compound_options)),
                        format_func=lambda x: compound_options[x],
                        key=f"formulation_select_{i}"
                    )
                    
                    selected_comp = compounds.iloc[selected_idx]
                    
                    with col2:
                        concentration = st.number_input(
                            f"Concentration (%)",
                            min_value=0.01,
                            max_value=10.0,
                            value=1.0,
                            step=0.1,
                            key=f"concentration_{i}"
                        )
                    
                    selected_compounds.append({
                        'name': selected_comp['name'],
                        'chemical_class': selected_comp['chemical_class'],
                        'molecular_weight': selected_comp['molecular_weight'],
                        'concentration': concentration,
                        'activity': selected_comp['biological_activity']
                    })
    
    # Formulation parameters
    col1, col2 = st.columns(2)
    
    with col1:
        formulation_wound_type = st.selectbox(
            "Target Wound Type",
            ["acute", "chronic", "infected", "burn", "surgical"]
        )
    
    with col2:
        target_pathogens = st.multiselect(
            "Target Pathogens",
            [
                "Staphylococcus aureus",
                "Pseudomonas aeruginosa", 
                "Escherichia coli",
                "Streptococcus pyogenes",
                "Candida albicans",
                "Aspergillus niger"
            ],
            default=["Staphylococcus aureus"]
        )
    
    # Generate formulation
    if st.button("Generate Formulation Recommendations") and selected_compounds:
        with st.spinner("Generating formulation recommendations..."):
            formulation_result = generate_formulation_recommendations(
                selected_compounds, formulation_wound_type, target_pathogens
            )
        
        if 'error' not in formulation_result:
            st.success("Formulation recommendations generated!")
            
            # Primary actives
            st.subheader("🎯 Primary Active Ingredients")
            
            primary_actives = formulation_result.get('primary_actives', [])
            
            if primary_actives:
                for active in primary_actives:
                    with st.expander(f"{active.get('compound', 'Unknown')} - {active.get('concentration_percent', 0)}%"):
                        st.write(f"**Rationale:** {active.get('rationale', 'Not specified')}")
            
            # Formulation base
            st.subheader("🧴 Formulation Base")
            
            formulation_base = formulation_result.get('formulation_base', {})
            
            if formulation_base:
                base_col1, base_col2 = st.columns(2)
                
                with base_col1:
                    st.write(f"**Recommended Vehicle:** {formulation_base.get('vehicle', 'Not specified')}")
                    st.write(f"**Rationale:** {formulation_base.get('rationale', 'Not provided')}")
                
                with base_col2:
                    excipients = formulation_base.get('additional_excipients', [])
                    if excipients:
                        st.write("**Additional Excipients:**")
                        for excipient in excipients:
                            st.write(f"• {excipient}")
            
            # Application guidelines
            st.subheader("📋 Application Guidelines")
            
            application = formulation_result.get('application_guidelines', {})
            
            app_col1, app_col2 = st.columns(2)
            
            with app_col1:
                st.write(f"**Frequency:** {application.get('frequency', 'Not specified')}")
                st.write(f"**Duration:** {application.get('duration', 'Not specified')}")
            
            with app_col2:
                precautions = application.get('precautions', [])
                if precautions:
                    st.write("**Precautions:**")
                    for precaution in precautions:
                        st.write(f"• {precaution}")
            
            # Expected efficacy
            st.subheader("⚡ Expected Efficacy")
            
            efficacy = formulation_result.get('expected_efficacy', {})
            
            if efficacy:
                spectrum = efficacy.get('antimicrobial_spectrum', [])
                if spectrum:
                    st.write("**Antimicrobial Spectrum:**")
                    spectrum_df = pd.DataFrame({'Susceptible Pathogens': spectrum})
                    st.dataframe(spectrum_df, use_container_width=True)
                
                st.write(f"**Healing Promotion:** {efficacy.get('healing_promotion', 'Not specified')}")
                st.write(f"**Onset of Action:** {efficacy.get('onset_of_action', 'Not specified')}")
            
            # Limitations and considerations
            col1, col2 = st.columns(2)
            
            with col1:
                st.subheader("⚠️ Limitations")
                limitations = formulation_result.get('limitations', [])
                
                if limitations:
                    for limitation in limitations:
                        st.warning(f"• {limitation}")
                else:
                    st.info("No major limitations identified")
            
            with col2:
                st.subheader("🔬 Quality Control")
                qc_tests = formulation_result.get('quality_control', [])
                
                if qc_tests:
                    for test in qc_tests:
                        st.info(f"• {test}")
            
            # Regulatory considerations
            st.subheader("📜 Regulatory Considerations")
            regulatory = formulation_result.get('regulatory_considerations', [])
            
            if regulatory:
                for consideration in regulatory:
                    st.write(f"• {consideration}")
            
            # Download formulation report
            with st.expander("Download Formulation Report"):
                formulation_data = {
                    "formulation_metadata": {
                        "compounds": selected_compounds,
                        "wound_type": formulation_wound_type,
                        "target_pathogens": target_pathogens,
                        "generation_timestamp": pd.Timestamp.now().isoformat()
                    },
                    "recommendations": formulation_result
                }
                
                st.json(formulation_data)
                
                json_str = json.dumps(formulation_data, indent=2)
                st.download_button(
                    label="Download Formulation Report",
                    data=json_str,
                    file_name=f"formulation_report_{formulation_wound_type}.json",
                    mime="application/json"
                )
        
        else:
            st.error(f"Formulation generation failed: {formulation_result.get('message', 'Unknown error')}")

elif analysis_mode == "Drug-Drug Interactions":
    st.header("🔄 Drug-Drug Interaction Analysis")
    
    st.markdown("""
    **Interaction Prediction**: AI analysis of potential interactions between phytochemicals
    for combination therapy safety assessment.
    """)
    
    # Compound selection for interaction analysis
    st.subheader("Select Compounds for Interaction Analysis")
    
    interaction_compounds = []
    
    for i in range(5):  # Allow up to 5 compounds
        compound_search = st.text_input(
            f"Compound {i+1} {'*' if i < 2 else '(optional)'}",
            key=f"interaction_compound_{i}",
            placeholder="Search compound name..."
        )
        
        if compound_search:
            compounds = search_compounds(compound_search)
            
            if not compounds.empty:
                compound_options = [f"{row['name']} ({row['chemical_class'] or 'Unknown'})" 
                                  for _, row in compounds.iterrows()]
                selected_idx = st.selectbox(
                    f"Select Compound {i+1}",
                    range(len(compound_options)),
                    format_func=lambda x: compound_options[x],
                    key=f"interaction_select_{i}"
                )
                
                selected_comp = compounds.iloc[selected_idx]
                
                interaction_compounds.append({
                    'name': selected_comp['name'],
                    'chemical_class': selected_comp['chemical_class'],
                    'molecular_weight': selected_comp['molecular_weight'],
                    'biological_activity': selected_comp['biological_activity']
                })
    
    # Analyze interactions
    if st.button("Analyze Drug Interactions") and len(interaction_compounds) >= 2:
        with st.spinner("Analyzing potential drug interactions..."):
            interaction_result = predict_drug_drug_interactions(interaction_compounds)
        
        if 'error' not in interaction_result:
            st.success("Interaction analysis completed!")
            
            # Overall risk assessment
            overall_risk = interaction_result.get('interaction_risk', 'unknown')
            
            if overall_risk == 'high':
                st.error(f"⚠️ HIGH RISK: Significant interaction potential detected")
            elif overall_risk == 'medium':
                st.warning(f"⚠️ MEDIUM RISK: Moderate interaction potential")
            else:
                st.success(f"✅ LOW RISK: Minimal interaction potential")
            
            # Potential interactions
            st.subheader("🔗 Potential Interactions")
            
            interactions = interaction_result.get('potential_interactions', [])
            
            if interactions:
                for interaction in interactions:
                    compound_pair = interaction.get('compound_pair', ['Unknown', 'Unknown'])
                    interaction_type = interaction.get('interaction_type', 'unknown')
                    confidence = interaction.get('confidence', 0)
                    
                    with st.expander(f"{compound_pair[0]} ↔ {compound_pair[1]} ({interaction_type.title()})"):
                        col1, col2 = st.columns([2, 1])
                        
                        with col1:
                            st.write(f"**Mechanism:** {interaction.get('mechanism', 'Not specified')}")
                            st.write(f"**Clinical Significance:** {interaction.get('clinical_significance', 'Not specified')}")
                        
                        with col2:
                            st.metric("Confidence", f"{confidence:.2f}")
                            
                            # Color code interaction type
                            if interaction_type == 'antagonistic':
                                st.error("Antagonistic")
                            elif interaction_type == 'synergistic':
                                st.success("Synergistic")
                            elif interaction_type == 'additive':
                                st.info("Additive")
                            else:
                                st.warning("Unknown")
            else:
                st.info("No significant interactions predicted")
            
            # Safety assessment
            st.subheader("🛡️ Safety Assessment")
            
            safety = interaction_result.get('safety_assessment', {})
            
            safety_col1, safety_col2 = st.columns(2)
            
            with safety_col1:
                st.write(f"**Overall Safety:** {safety.get('overall_safety', 'Not assessed')}")
                
                contraindications = safety.get('contraindications', [])
                if contraindications:
                    st.write("**Contraindications:**")
                    for contraindication in contraindications:
                        st.error(f"• {contraindication}")
            
            with safety_col2:
                monitoring = safety.get('monitoring_parameters', [])
                if monitoring:
                    st.write("**Monitoring Parameters:**")
                    for parameter in monitoring:
                        st.info(f"• {parameter}")
            
            # Dosing considerations
            st.subheader("💊 Dosing Considerations")
            
            dosing = interaction_result.get('dosing_considerations', [])
            
            if dosing:
                for consideration in dosing:
                    st.info(f"• {consideration}")
            else:
                st.success("No special dosing adjustments required")
            
            # Research gaps
            st.subheader("🔍 Research Gaps")
            
            gaps = interaction_result.get('research_gaps', [])
            
            if gaps:
                for gap in gaps:
                    st.warning(f"• {gap}")
        
        else:
            st.error(f"Interaction analysis failed: {interaction_result.get('message', 'Unknown error')}")

elif analysis_mode == "Multi-Evidence Scoring":
    st.header("📊 Multi-Evidence Scoring System")
    
    st.markdown("""
    **Evidence Integration**: Comprehensive scoring system that combines QSAR predictions, 
    literature data, ADMET properties, molecular docking, and formulation constraints.
    """)
    
    # Compound selection
    compound_search = st.text_input(
        "Search Compound for Scoring",
        placeholder="Enter compound name..."
    )
    
    if compound_search:
        compounds = search_compounds(compound_search)
        
        if not compounds.empty:
            compound_options = [f"{row['name']} ({row['chemical_class'] or 'Unknown'})" 
                              for _, row in compounds.iterrows()]
            selected_compound_idx = st.selectbox(
                "Select Compound",
                range(len(compound_options)),
                format_func=lambda x: compound_options[x]
            )
            
            selected_compound = compounds.iloc[selected_compound_idx]
            
            # Scoring parameters
            col1, col2 = st.columns(2)
            
            with col1:
                scoring_wound_type = st.selectbox(
                    "Wound Type Context",
                    ["general", "acute", "chronic", "infected", "burn", "surgical"]
                )
            
            with col2:
                if st.button("Calculate Multi-Evidence Score"):
                    with st.spinner("Calculating comprehensive evidence score..."):
                        scorer = MultiEvidenceScorer()
                        
                        compound_data = {
                            'molecular_weight': selected_compound['molecular_weight'],
                            'chemical_class': selected_compound['chemical_class'],
                            'name': selected_compound['name']
                        }
                        
                        score_result = scorer.calculate_overall_score(
                            selected_compound['id'], 
                            compound_data, 
                            scoring_wound_type
                        )
                    
                    if 'error' not in score_result:
                        st.success("Multi-evidence scoring completed!")
                        
                        # Overall metrics
                        score_col1, score_col2, score_col3 = st.columns(3)
                        
                        with score_col1:
                            st.metric("Overall Score", f"{score_result['overall_score']}/100")
                        
                        with score_col2:
                            st.metric("Confidence", f"{score_result['overall_confidence']:.3f}")
                        
                        with score_col3:
                            st.metric("Evidence Strength", score_result['evidence_strength'])
                        
                        # Individual scores breakdown
                        st.subheader("📋 Evidence Breakdown")
                        
                        individual_scores = score_result.get('individual_scores', {})
                        
                        # Create radar chart
                        if individual_scores:
                            categories = []
                            scores = []
                            confidences = []
                            
                            for evidence_type, data in individual_scores.items():
                                categories.append(evidence_type.replace('_', ' ').title())
                                scores.append(data['score'])
                                confidences.append(data['confidence'])
                            
                            # Radar chart for scores
                            fig = go.Figure()
                            
                            fig.add_trace(go.Scatterpolar(
                                r=scores,
                                theta=categories,
                                fill='toself',
                                name='Evidence Scores',
                                line_color='blue'
                            ))
                            
                            fig.add_trace(go.Scatterpolar(
                                r=[conf * 100 for conf in confidences],
                                theta=categories,
                                fill='toself',
                                name='Confidence Levels',
                                line_color='red',
                                opacity=0.6
                            ))
                            
                            fig.update_layout(
                                polar=dict(
                                    radialaxis=dict(
                                        visible=True,
                                        range=[0, 100]
                                    )),
                                showlegend=True,
                                title="Multi-Evidence Score Breakdown"
                            )
                            
                            st.plotly_chart(fig, use_container_width=True)
                            
                            # Detailed table
                            score_details = []
                            for evidence_type, data in individual_scores.items():
                                score_details.append({
                                    'Evidence Type': evidence_type.replace('_', ' ').title(),
                                    'Score': f"{data['score']:.1f}/100",
                                    'Confidence': f"{data['confidence']:.3f}",
                                    'Weight': f"{data['weight']:.1%}",
                                    'Notes': data['notes']
                                })
                            
                            st.dataframe(pd.DataFrame(score_details), use_container_width=True)
                        
                        # Uncertainty factors
                        st.subheader("⚠️ Uncertainty Factors")
                        
                        uncertainty_factors = score_result.get('uncertainty_factors', [])
                        
                        if uncertainty_factors:
                            for factor in uncertainty_factors:
                                st.warning(f"• {factor}")
                        else:
                            st.success("No major uncertainty factors identified")
                        
                        # Recommendations
                        st.subheader("💡 Recommendations")
                        
                        recommendations = score_result.get('recommendations', [])
                        
                        if recommendations:
                            for recommendation in recommendations:
                                st.info(f"• {recommendation}")
                        
                        # Evidence summary
                        st.subheader("📖 Evidence Summary")
                        
                        summary = create_evidence_summary(score_result)
                        st.markdown(summary)
                    
                    else:
                        st.error(f"Scoring failed: {score_result.get('error', 'Unknown error')}")

elif analysis_mode == "Batch Analysis":
    st.header("📦 Batch Analysis")
    
    st.markdown("""
    **High-Throughput Analysis**: Analyze multiple compounds simultaneously for 
    antimicrobial potential and evidence-based ranking.
    """)
    
    # Batch selection options
    batch_option = st.selectbox(
        "Batch Selection Method",
        ["Search Results", "Chemical Class", "Upload List"]
    )
    
    compounds_for_batch = pd.DataFrame()
    
    if batch_option == "Search Results":
        batch_search = st.text_input(
            "Search Compounds for Batch Analysis",
            placeholder="Enter search term (e.g., flavonoid, antimicrobial)..."
        )
        
        if batch_search:
            compounds_for_batch = search_compounds(batch_search)
            
            if not compounds_for_batch.empty:
                st.info(f"Found {len(compounds_for_batch)} compounds for batch analysis")
                st.dataframe(compounds_for_batch[['name', 'chemical_class', 'molecular_weight']], use_container_width=True)
    
    elif batch_option == "Chemical Class":
        from phytochemical_db import get_phytochemical_families
        
        chemical_classes = get_phytochemical_families()
        
        if chemical_classes:
            selected_class = st.selectbox(
                "Select Chemical Class",
                chemical_classes
            )
            
            if selected_class:
                compounds_for_batch = search_compounds("", selected_class)
                
                if not compounds_for_batch.empty:
                    st.info(f"Found {len(compounds_for_batch)} compounds in {selected_class} class")
                    st.dataframe(compounds_for_batch[['name', 'chemical_class', 'molecular_weight']], use_container_width=True)
    
    # Batch analysis parameters
    if not compounds_for_batch.empty:
        col1, col2 = st.columns(2)
        
        with col1:
            batch_wound_type = st.selectbox(
                "Target Wound Type",
                ["general", "acute", "chronic", "infected", "burn", "surgical"]
            )
        
        with col2:
            max_compounds = st.slider(
                "Maximum Compounds to Analyze",
                min_value=5,
                max_value=min(50, len(compounds_for_batch)),
                value=min(10, len(compounds_for_batch))
            )
        
        # Execute batch analysis
        if st.button("Run Batch Analysis"):
            with st.spinner(f"Analyzing {max_compounds} compounds... This may take several minutes."):
                
                # Limit compounds for analysis
                batch_compounds = compounds_for_batch.head(max_compounds)
                
                # Run multi-evidence scoring
                ranked_results = rank_compounds_by_evidence(batch_compounds, batch_wound_type)
            
            if not ranked_results.empty:
                st.success(f"Batch analysis completed for {len(ranked_results)} compounds!")
                
                # Top compounds visualization
                st.subheader("🏆 Top Ranked Compounds")
                
                top_10 = ranked_results.head(10)
                
                fig = px.bar(
                    top_10,
                    x='compound_name',
                    y='overall_score',
                    color='evidence_strength',
                    title=f'Top 10 Compounds for {batch_wound_type.title()} Wounds',
                    labels={'overall_score': 'Overall Score', 'compound_name': 'Compound'}
                )
                fig.update_layout(xaxis_tickangle=-45)
                st.plotly_chart(fig, use_container_width=True)
                
                # Results table
                st.subheader("📊 Complete Results")
                
                # Format results for display
                display_results = ranked_results.copy()
                display_results['Overall Score'] = display_results['overall_score'].apply(lambda x: f"{x:.1f}")
                display_results['Confidence'] = display_results['overall_confidence'].apply(lambda x: f"{x:.3f}")
                
                st.dataframe(
                    display_results[['compound_name', 'Overall Score', 'Confidence', 'evidence_strength', 
                                   'qsar_score', 'literature_score', 'admet_score', 'docking_score', 'formulation_score']],
                    use_container_width=True
                )
                
                # Download results
                st.subheader("📥 Download Results")
                
                batch_results_data = {
                    "batch_metadata": {
                        "analysis_type": "multi_evidence_batch",
                        "wound_type": batch_wound_type,
                        "compounds_analyzed": len(ranked_results),
                        "analysis_timestamp": pd.Timestamp.now().isoformat()
                    },
                    "results": ranked_results.to_dict('records')
                }
                
                json_str = json.dumps(batch_results_data, indent=2, default=str)
                st.download_button(
                    label="Download Batch Results",
                    data=json_str,
                    file_name=f"batch_analysis_{batch_wound_type}_{len(ranked_results)}compounds.json",
                    mime="application/json"
                )
            
            else:
                st.error("Batch analysis failed to produce results")

# Scientific disclaimers
st.markdown("---")

st.subheader("⚠️ Important Scientific Disclaimers")

st.warning("""
**AI Analysis Limitations**: 
- All AI predictions are computational estimates for research purposes only
- Results require experimental validation before clinical application
- Molecular docking scores are hypothesis-generating, not proof of efficacy
- Confidence levels reflect data availability, not experimental certainty
""")

st.info("""
**Evidence-Based Approach**: 
- Multi-evidence scoring integrates computational and experimental data
- Uncertainty quantification identifies data gaps and limitations
- Literature citations provide traceability for all claims
- Transparent methodology ensures reproducible research workflows
""")

st.markdown("""
<div style='text-align: center; color: #666;'>
<p><strong>AI-Powered Analysis Platform</strong> | Scientific hypothesis generation and evidence integration</p>
<p>Always validate computational predictions with appropriate experimental studies</p>
</div>
""", unsafe_allow_html=True)

