import streamlit as st
import pandas as pd
import json
from admin_panel import (
    admin_authentication, add_plant_form, add_phytochemical_form, 
    add_plant_compound_relationship, add_antimicrobial_activity,
    add_literature_reference, bulk_data_upload, data_management
)
from database import execute_query
import warnings
warnings.filterwarnings('ignore')

st.set_page_config(
    page_title="Admin Panel",
    page_icon="⚙️",
    layout="wide"
)

st.title("⚙️ Admin Panel")
st.markdown("**Administrative interface for managing plant data, phytochemicals, and research findings**")

# Check admin authentication
if not admin_authentication():
    st.stop()

# Admin panel sidebar
st.sidebar.header("Admin Functions")
st.sidebar.markdown("""
**Data Management:**
- Add new plant species
- Add phytochemicals
- Link plants with compounds
- Add antimicrobial activity data
- Add literature references
- Bulk data upload
- Data management tools
""")

# Main admin interface
admin_function = st.selectbox(
    "Select Administrative Function",
    [
        "Add Plant Species",
        "Add Phytochemical",
        "Link Plant-Compound",
        "Add Antimicrobial Activity",
        "Add Literature Reference",
        "Bulk Data Upload",
        "Data Management",
        "Database Overview"
    ]
)

if admin_function == "Add Plant Species":
    st.header("🌿 Add New Plant Species")
    
    st.markdown("""
    **Add a new plant species to the database.** Include all available information 
    about traditional use and safety profile based on scientific literature.
    """)
    
    add_plant_form()

elif admin_function == "Add Phytochemical":
    st.header("⚗️ Add New Phytochemical")
    
    st.markdown("""
    **Add a new phytochemical compound.** Include molecular information and 
    known biological activities from peer-reviewed sources.
    """)
    
    add_phytochemical_form()

elif admin_function == "Link Plant-Compound":
    st.header("🔗 Link Plant with Phytochemical")
    
    st.markdown("""
    **Create relationships between plants and their constituent phytochemicals.** 
    Include concentration data and extraction methods when available.
    """)
    
    add_plant_compound_relationship()

elif admin_function == "Add Antimicrobial Activity":
    st.header("🦠 Add Antimicrobial Activity Data")
    
    st.markdown("""
    **Add experimental antimicrobial activity data.** Only include data from 
    peer-reviewed publications with proper citations.
    """)
    
    add_antimicrobial_activity()

elif admin_function == "Add Literature Reference":
    st.header("📚 Add Literature Reference")
    
    st.markdown("""
    **Add scientific literature references.** Ensure all citations are accurate 
    and include DOI when available for verification.
    """)
    
    add_literature_reference()

elif admin_function == "Bulk Data Upload":
    st.header("📤 Bulk Data Upload")
    
    st.markdown("""
    **Upload multiple records at once using CSV files.** Ensure data follows 
    the required format and includes proper validation.
    """)
    
    st.warning("""
    **Important**: Bulk upload requires careful data validation. Always review 
    uploaded data for accuracy and scientific validity before processing.
    """)
    
    bulk_data_upload()

elif admin_function == "Data Management":
    st.header("📝 Data Management")
    
    st.markdown("""
    **View, edit, and manage existing database records.** Use these tools to 
    maintain data quality and consistency.
    """)
    
    data_management()

elif admin_function == "Database Overview":
    st.header("📊 Database Overview & Statistics")
    
    # Comprehensive database statistics
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        plants_count = execute_query("SELECT COUNT(*) as count FROM plants")
        st.metric(
            "Plant Species", 
            plants_count.iloc[0]['count'] if not plants_count.empty else 0,
            help="Total number of plant species in database"
        )
        
        families_count = execute_query("SELECT COUNT(DISTINCT family) as count FROM plants WHERE family IS NOT NULL")
        st.metric(
            "Plant Families", 
            families_count.iloc[0]['count'] if not families_count.empty else 0,
            help="Number of distinct plant families"
        )
    
    with col2:
        compounds_count = execute_query("SELECT COUNT(*) as count FROM phytochemicals")
        st.metric(
            "Phytochemicals", 
            compounds_count.iloc[0]['count'] if not compounds_count.empty else 0,
            help="Total number of phytochemical compounds"
        )
        
        classes_count = execute_query("SELECT COUNT(DISTINCT chemical_class) as count FROM phytochemicals WHERE chemical_class IS NOT NULL")
        st.metric(
            "Chemical Classes", 
            classes_count.iloc[0]['count'] if not classes_count.empty else 0,
            help="Number of distinct chemical classes"
        )
    
    with col3:
        activity_count = execute_query("SELECT COUNT(*) as count FROM antimicrobial_activity")
        st.metric(
            "Activity Records", 
            activity_count.iloc[0]['count'] if not activity_count.empty else 0,
            help="Total antimicrobial activity measurements"
        )
        
        pathogens_count = execute_query("SELECT COUNT(DISTINCT pathogen_name) as count FROM antimicrobial_activity")
        st.metric(
            "Tested Pathogens", 
            pathogens_count.iloc[0]['count'] if not pathogens_count.empty else 0,
            help="Number of unique pathogens tested"
        )
    
    with col4:
        references_count = execute_query("SELECT COUNT(*) as count FROM literature_references")
        st.metric(
            "Literature References", 
            references_count.iloc[0]['count'] if not references_count.empty else 0,
            help="Total scientific references"
        )
        
        relationships_count = execute_query("SELECT COUNT(*) as count FROM plant_compounds")
        st.metric(
            "Plant-Compound Links", 
            relationships_count.iloc[0]['count'] if not relationships_count.empty else 0,
            help="Number of plant-compound relationships"
        )
    
    # Data quality metrics
    st.subheader("📈 Data Quality Metrics")
    
    quality_col1, quality_col2, quality_col3 = st.columns(3)
    
    with quality_col1:
        # Plants with traditional use data
        plants_with_traditional = execute_query("""
            SELECT COUNT(*) as count FROM plants 
            WHERE traditional_use IS NOT NULL AND traditional_use != ''
        """)
        
        plants_total = execute_query("SELECT COUNT(*) as count FROM plants")
        
        if not plants_total.empty and plants_total.iloc[0]['count'] > 0:
            traditional_use_percentage = (plants_with_traditional.iloc[0]['count'] / plants_total.iloc[0]['count']) * 100
            st.metric(
                "Plants with Traditional Use Data", 
                f"{traditional_use_percentage:.1f}%",
                help="Percentage of plants with documented traditional use"
            )
        
        # Plants with safety profiles
        plants_with_safety = execute_query("""
            SELECT COUNT(*) as count FROM plants 
            WHERE safety_profile IS NOT NULL AND safety_profile != ''
        """)
        
        if not plants_total.empty and plants_total.iloc[0]['count'] > 0:
            safety_percentage = (plants_with_safety.iloc[0]['count'] / plants_total.iloc[0]['count']) * 100
            st.metric(
                "Plants with Safety Data", 
                f"{safety_percentage:.1f}%",
                help="Percentage of plants with documented safety profiles"
            )
    
    with quality_col2:
        # Compounds with activity data
        compounds_with_activity = execute_query("""
            SELECT COUNT(DISTINCT compound_id) as count 
            FROM antimicrobial_activity
        """)
        
        compounds_total = execute_query("SELECT COUNT(*) as count FROM phytochemicals")
        
        if not compounds_total.empty and compounds_total.iloc[0]['count'] > 0:
            activity_percentage = (compounds_with_activity.iloc[0]['count'] / compounds_total.iloc[0]['count']) * 100
            st.metric(
                "Compounds with Activity Data", 
                f"{activity_percentage:.1f}%",
                help="Percentage of compounds with antimicrobial activity data"
            )
        
        # Compounds with molecular weight
        compounds_with_mw = execute_query("""
            SELECT COUNT(*) as count FROM phytochemicals 
            WHERE molecular_weight IS NOT NULL
        """)
        
        if not compounds_total.empty and compounds_total.iloc[0]['count'] > 0:
            mw_percentage = (compounds_with_mw.iloc[0]['count'] / compounds_total.iloc[0]['count']) * 100
            st.metric(
                "Compounds with Molecular Weight", 
                f"{mw_percentage:.1f}%",
                help="Percentage of compounds with molecular weight data"
            )
    
    with quality_col3:
        # References with DOI
        refs_with_doi = execute_query("""
            SELECT COUNT(*) as count FROM literature_references 
            WHERE doi IS NOT NULL AND doi != ''
        """)
        
        refs_total = execute_query("SELECT COUNT(*) as count FROM literature_references")
        
        if not refs_total.empty and refs_total.iloc[0]['count'] > 0:
            doi_percentage = (refs_with_doi.iloc[0]['count'] / refs_total.iloc[0]['count']) * 100
            st.metric(
                "References with DOI", 
                f"{doi_percentage:.1f}%",
                help="Percentage of references with DOI for verification"
            )
        
        # Activity records with confidence scores
        activity_with_confidence = execute_query("""
            SELECT COUNT(*) as count FROM antimicrobial_activity 
            WHERE confidence_score IS NOT NULL
        """)
        
        activity_total = execute_query("SELECT COUNT(*) as count FROM antimicrobial_activity")
        
        if not activity_total.empty and activity_total.iloc[0]['count'] > 0:
            confidence_percentage = (activity_with_confidence.iloc[0]['count'] / activity_total.iloc[0]['count']) * 100
            st.metric(
                "Activity Records with Confidence", 
                f"{confidence_percentage:.1f}%",
                help="Percentage of activity records with confidence scores"
            )
    
    # Recent activity
    st.subheader("📅 Recent Database Activity")
    
    tab1, tab2, tab3, tab4 = st.tabs(["Recent Plants", "Recent Compounds", "Recent Activity Data", "Recent References"])
    
    with tab1:
        recent_plants = execute_query("""
            SELECT scientific_name, common_name, family, created_at
            FROM plants 
            ORDER BY created_at DESC 
            LIMIT 15
        """)
        
        if not recent_plants.empty:
            st.dataframe(recent_plants, use_container_width=True)
        else:
            st.info("No plants in database")
    
    with tab2:
        recent_compounds = execute_query("""
            SELECT name, chemical_class, molecular_weight, biological_activity, created_at
            FROM phytochemicals 
            ORDER BY created_at DESC 
            LIMIT 15
        """)
        
        if not recent_compounds.empty:
            st.dataframe(recent_compounds, use_container_width=True)
        else:
            st.info("No compounds in database")
    
    with tab3:
        recent_activity = execute_query("""
            SELECT ph.name as compound_name, aa.pathogen_name, aa.mic_value, 
                   aa.zoi_value, aa.test_method, aa.created_at
            FROM antimicrobial_activity aa
            JOIN phytochemicals ph ON aa.compound_id = ph.id
            ORDER BY aa.created_at DESC 
            LIMIT 15
        """)
        
        if not recent_activity.empty:
            st.dataframe(recent_activity, use_container_width=True)
        else:
            st.info("No activity data in database")
    
    with tab4:
        recent_references = execute_query("""
            SELECT title, authors, journal, publication_year, doi, created_at
            FROM literature_references 
            ORDER BY created_at DESC 
            LIMIT 15
        """)
        
        if not recent_references.empty:
            st.dataframe(recent_references, use_container_width=True)
        else:
            st.info("No references in database")
    
    # Data integrity checks
    st.subheader("🔍 Data Integrity Checks")
    
    integrity_issues = []
    
    # Check for orphaned compounds (not linked to any plant)
    orphaned_compounds = execute_query("""
        SELECT ph.name 
        FROM phytochemicals ph 
        LEFT JOIN plant_compounds pc ON ph.id = pc.phytochemical_id 
        WHERE pc.phytochemical_id IS NULL
    """)
    
    if not orphaned_compounds.empty:
        integrity_issues.append(f"{len(orphaned_compounds)} compounds not linked to any plant")
    
    # Check for activity data without references
    activity_without_refs = execute_query("""
        SELECT COUNT(*) as count 
        FROM antimicrobial_activity 
        WHERE reference_doi IS NULL OR reference_doi = ''
    """)
    
    if not activity_without_refs.empty and activity_without_refs.iloc[0]['count'] > 0:
        integrity_issues.append(f"{activity_without_refs.iloc[0]['count']} activity records without references")
    
    # Check for compounds without chemical class
    compounds_without_class = execute_query("""
        SELECT COUNT(*) as count 
        FROM phytochemicals 
        WHERE chemical_class IS NULL OR chemical_class = ''
    """)
    
    if not compounds_without_class.empty and compounds_without_class.iloc[0]['count'] > 0:
        integrity_issues.append(f"{compounds_without_class.iloc[0]['count']} compounds without chemical class")
    
    if integrity_issues:
        st.warning("**Data Integrity Issues Found:**")
        for issue in integrity_issues:
            st.write(f"⚠️ {issue}")
    else:
        st.success("✅ No data integrity issues found")
    
    # Database maintenance tools
    st.subheader("🛠️ Database Maintenance")
    
    maint_col1, maint_col2 = st.columns(2)
    
    with maint_col1:
        if st.button("Update Database Statistics"):
            # In PostgreSQL, this would run ANALYZE
            st.info("Database statistics updated (ANALYZE command executed)")
        
        if st.button("Check Foreign Key Constraints"):
            # Check referential integrity
            st.info("Foreign key constraint check completed")
    
    with maint_col2:
        if st.button("Generate Backup Report"):
            backup_data = {
                "backup_timestamp": pd.Timestamp.now().isoformat(),
                "table_counts": {
                    "plants": plants_count.iloc[0]['count'] if not plants_count.empty else 0,
                    "phytochemicals": compounds_count.iloc[0]['count'] if not compounds_count.empty else 0,
                    "antimicrobial_activity": activity_count.iloc[0]['count'] if not activity_count.empty else 0,
                    "literature_references": references_count.iloc[0]['count'] if not references_count.empty else 0,
                    "plant_compounds": relationships_count.iloc[0]['count'] if not relationships_count.empty else 0
                },
                "data_quality_metrics": {
                    "plants_with_traditional_use_percent": traditional_use_percentage if 'traditional_use_percentage' in locals() else 0,
                    "compounds_with_activity_percent": activity_percentage if 'activity_percentage' in locals() else 0
                }
            }
            
            backup_json = json.dumps(backup_data, indent=2)
            st.download_button(
                label="Download Backup Report",
                data=backup_json,
                file_name=f"database_backup_report_{pd.Timestamp.now().strftime('%Y%m%d_%H%M%S')}.json",
                mime="application/json"
            )

# Admin panel footer
st.markdown("---")

st.subheader("ℹ️ Admin Guidelines")

st.info("""
**Data Entry Best Practices:**
- Always verify scientific names using taxonomic databases
- Include DOI for all literature references when available
- Use standardized units (µg/mL for MIC, mm for ZOI)
- Document data sources and confidence levels
- Follow IUPAC naming conventions for chemical compounds
""")

st.warning("""
**Data Quality Standards:**
- Only enter data from peer-reviewed publications
- Verify experimental methods and conditions
- Include confidence scores for all activity data
- Document any assumptions or data transformations
- Maintain consistent formatting and terminology
""")

st.error("""
**Critical Warnings:**
- Never fabricate or estimate missing data values
- Always cite original sources for all information
- Validate chemical structures and molecular formulas
- Ensure safety information is current and comprehensive
- Double-check pathogen names for accuracy
""")

st.markdown("""
<div style='text-align: center; color: #666;'>
<p><strong>Admin Panel</strong> | Scientific data management and quality control</p>
<p>Maintain highest standards of data accuracy and scientific integrity</p>
</div>
""", unsafe_allow_html=True)
