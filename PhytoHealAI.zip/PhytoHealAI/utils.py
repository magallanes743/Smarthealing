import re
import streamlit as st
import pandas as pd
import numpy as np
from typing import Union, List, Dict, Optional
import hashlib
import json

def validate_chemical_formula(formula: str) -> bool:
    """
    Validate chemical formula format
    
    Args:
        formula: Chemical formula string
        
    Returns:
        Boolean indicating if formula is valid
    """
    if not formula or not isinstance(formula, str):
        return False
    
    # Basic chemical formula pattern (elements with optional counts)
    pattern = r'^[A-Z][a-z]?(\d*[A-Z][a-z]?\d*)*$'
    
    # Remove spaces and check pattern
    clean_formula = formula.replace(' ', '')
    return bool(re.match(pattern, clean_formula))

def validate_doi(doi: str) -> bool:
    """
    Validate DOI format
    
    Args:
        doi: DOI string
        
    Returns:
        Boolean indicating if DOI is valid
    """
    if not doi or not isinstance(doi, str):
        return False
    
    # DOI pattern: 10.xxxx/xxxxx
    pattern = r'^10\.\d{4,}\/[-._;()\/:a-zA-Z0-9]+$'
    
    # Clean and validate
    clean_doi = doi.strip()
    return bool(re.match(pattern, clean_doi))

def validate_smiles(smiles: str) -> bool:
    """
    Basic SMILES validation (simplified)
    
    Args:
        smiles: SMILES string
        
    Returns:
        Boolean indicating if SMILES appears valid
    """
    if not smiles or not isinstance(smiles, str):
        return False
    
    # Basic SMILES characters
    valid_chars = set('CNOPSFClBrI[]()=+\\-#@0123456789cnops')
    
    # Check if all characters are valid SMILES characters
    return all(c in valid_chars for c in smiles)

def calculate_molecular_descriptors(smiles: str) -> Dict:
    """
    Calculate basic molecular descriptors from SMILES
    Note: This is a simplified version. In practice, use RDKit
    
    Args:
        smiles: SMILES string
        
    Returns:
        Dictionary with molecular descriptors
    """
    if not validate_smiles(smiles):
        return {}
    
    # Simplified descriptor calculation
    # In practice, you would use RDKit for proper calculation
    descriptors = {
        'length': len(smiles),
        'carbon_count': smiles.count('C') + smiles.count('c'),
        'nitrogen_count': smiles.count('N') + smiles.count('n'),
        'oxygen_count': smiles.count('O') + smiles.count('o'),
        'ring_count': smiles.count('[') + smiles.count('('),
        'aromatic_rings': smiles.count('c')
    }
    
    return descriptors

def format_scientific_notation(value: float, decimals: int = 2) -> str:
    """
    Format number in scientific notation if needed
    
    Args:
        value: Numeric value
        decimals: Number of decimal places
        
    Returns:
        Formatted string
    """
    if pd.isna(value) or value == 0:
        return "0"
    
    if abs(value) >= 1000 or abs(value) < 0.01:
        return f"{value:.{decimals}e}"
    else:
        return f"{value:.{decimals}f}"

def calculate_confidence_interval(data: List[float], confidence_level: float = 0.95) -> Dict:
    """
    Calculate confidence interval for data
    
    Args:
        data: List of numeric values
        confidence_level: Confidence level (default 0.95)
        
    Returns:
        Dictionary with confidence interval information
    """
    if not data or len(data) < 2:
        return {'mean': 0, 'lower': 0, 'upper': 0, 'margin_error': 0}
    
    data_array = np.array(data)
    mean_val = np.mean(data_array)
    std_val = np.std(data_array, ddof=1)
    n = len(data_array)
    
    # Calculate margin of error (simplified - using normal approximation)
    z_score = 1.96 if confidence_level == 0.95 else 2.576  # For 95% or 99%
    margin_error = z_score * (std_val / np.sqrt(n))
    
    return {
        'mean': mean_val,
        'lower': mean_val - margin_error,
        'upper': mean_val + margin_error,
        'margin_error': margin_error,
        'std_dev': std_val,
        'n': n
    }

def categorize_mic_value(mic: float) -> str:
    """
    Categorize MIC value into activity levels
    
    Args:
        mic: MIC value in µg/mL
        
    Returns:
        Activity category string
    """
    if pd.isna(mic) or mic <= 0:
        return "Unknown"
    
    if mic <= 10:
        return "High Activity"
    elif mic <= 100:
        return "Moderate Activity"
    elif mic <= 1000:
        return "Low Activity"
    else:
        return "Minimal Activity"

def categorize_compound_properties(molecular_weight: float, chemical_class: str) -> Dict:
    """
    Categorize compound based on properties for drug-likeness
    
    Args:
        molecular_weight: Molecular weight in g/mol
        chemical_class: Chemical class string
        
    Returns:
        Dictionary with categorization results
    """
    categories = {
        'size_category': 'Unknown',
        'drug_likeness': 'Unknown',
        'natural_product_score': 0
    }
    
    # Size categorization
    if pd.notna(molecular_weight):
        if molecular_weight < 150:
            categories['size_category'] = 'Small'
        elif molecular_weight <= 500:
            categories['size_category'] = 'Drug-like'
        elif molecular_weight <= 800:
            categories['size_category'] = 'Large'
        else:
            categories['size_category'] = 'Very Large'
        
        # Drug-likeness (simplified Lipinski's rule)
        if 150 <= molecular_weight <= 500:
            categories['drug_likeness'] = 'Good'
        elif 100 <= molecular_weight <= 600:
            categories['drug_likeness'] = 'Acceptable'
        else:
            categories['drug_likeness'] = 'Poor'
    
    # Natural product score based on chemical class
    if chemical_class:
        np_scores = {
            'flavonoid': 8,
            'phenolic': 7,
            'terpenoid': 9,
            'alkaloid': 8,
            'saponin': 7,
            'tannin': 6,
            'quinone': 5,
            'essential oil': 8
        }
        
        for class_name, score in np_scores.items():
            if class_name.lower() in chemical_class.lower():
                categories['natural_product_score'] = score
                break
    
    return categories

def generate_compound_hash(compound_data: Dict) -> str:
    """
    Generate unique hash for compound data
    
    Args:
        compound_data: Dictionary with compound information
        
    Returns:
        SHA-256 hash string
    """
    # Create standardized string representation
    hash_string = f"{compound_data.get('name', '').lower()}"
    hash_string += f"{compound_data.get('chemical_formula', '').replace(' ', '')}"
    hash_string += f"{compound_data.get('smiles', '').replace(' ', '')}"
    
    return hashlib.sha256(hash_string.encode()).hexdigest()[:16]

def export_data_json(data: Union[pd.DataFrame, Dict], filename: str = "export.json") -> str:
    """
    Export data to JSON format
    
    Args:
        data: Data to export (DataFrame or Dictionary)
        filename: Output filename
        
    Returns:
        JSON string
    """
    if isinstance(data, pd.DataFrame):
        # Convert DataFrame to JSON
        json_data = data.to_dict('records')
    else:
        json_data = data
    
    # Add metadata
    export_data = {
        'metadata': {
            'export_date': pd.Timestamp.now().isoformat(),
            'record_count': len(json_data) if isinstance(json_data, list) else 1,
            'source': 'AI Antimicrobial Discovery Assistant'
        },
        'data': json_data
    }
    
    return json.dumps(export_data, indent=2, default=str)

def calculate_similarity_score(compound1: Dict, compound2: Dict) -> float:
    """
    Calculate similarity between two compounds (simplified)
    
    Args:
        compound1: First compound data
        compound2: Second compound data
        
    Returns:
        Similarity score (0-1)
    """
    score = 0.0
    comparisons = 0
    
    # Compare chemical class
    if (compound1.get('chemical_class') and compound2.get('chemical_class')):
        if compound1['chemical_class'].lower() == compound2['chemical_class'].lower():
            score += 0.3
        comparisons += 0.3
    
    # Compare molecular weight (within 20% range)
    mw1 = compound1.get('molecular_weight')
    mw2 = compound2.get('molecular_weight')
    
    if mw1 and mw2 and mw1 > 0 and mw2 > 0:
        diff_ratio = abs(mw1 - mw2) / max(mw1, mw2)
        if diff_ratio <= 0.2:  # Within 20%
            score += 0.4 * (1 - diff_ratio / 0.2)
        comparisons += 0.4
    
    # Compare biological activity (text similarity)
    activity1 = compound1.get('biological_activity', '').lower()
    activity2 = compound2.get('biological_activity', '').lower()
    
    if activity1 and activity2:
        # Simple word overlap
        words1 = set(activity1.split())
        words2 = set(activity2.split())
        
        if words1 and words2:
            overlap = len(words1.intersection(words2))
            union = len(words1.union(words2))
            activity_sim = overlap / union if union > 0 else 0
            score += 0.3 * activity_sim
        
        comparisons += 0.3
    
    return score / comparisons if comparisons > 0 else 0.0

def validate_concentration_range(concentration: str) -> bool:
    """
    Validate concentration range format
    
    Args:
        concentration: Concentration string (e.g., "0.5-2.3%", "10-50 mg/g")
        
    Returns:
        Boolean indicating if format is valid
    """
    if not concentration or not isinstance(concentration, str):
        return False
    
    # Common concentration patterns
    patterns = [
        r'^\d+(\.\d+)?-\d+(\.\d+)?%$',  # e.g., "0.5-2.3%"
        r'^\d+(\.\d+)?-\d+(\.\d+)?\s*mg/g$',  # e.g., "10-50 mg/g"
        r'^\d+(\.\d+)?-\d+(\.\d+)?\s*µg/mL$',  # e.g., "5-20 µg/mL"
        r'^\d+(\.\d+)?-\d+(\.\d+)?\s*ppm$',  # e.g., "100-500 ppm"
        r'^~?\d+(\.\d+)?%$',  # e.g., "~1.5%"
        r'^\d+(\.\d+)?\s*mg/mL$'  # e.g., "5 mg/mL"
    ]
    
    concentration_clean = concentration.strip()
    return any(re.match(pattern, concentration_clean, re.IGNORECASE) for pattern in patterns)

def format_uncertainty_display(value: float, uncertainty: float, unit: str = "") -> str:
    """
    Format value with uncertainty for display
    
    Args:
        value: Central value
        uncertainty: Uncertainty value
        unit: Unit string
        
    Returns:
        Formatted string with uncertainty
    """
    if pd.isna(value) or pd.isna(uncertainty):
        return "Unknown"
    
    return f"{value:.2f} ± {uncertainty:.2f} {unit}".strip()

def create_evidence_summary(evidence_dict: Dict) -> str:
    """
    Create human-readable evidence summary
    
    Args:
        evidence_dict: Dictionary with evidence scores and information
        
    Returns:
        Formatted evidence summary string
    """
    if not evidence_dict:
        return "No evidence data available"
    
    summary_parts = []
    
    overall_score = evidence_dict.get('overall_score', 0)
    confidence = evidence_dict.get('overall_confidence', 0)
    
    # Overall assessment
    if overall_score >= 70:
        assessment = "Strong"
    elif overall_score >= 50:
        assessment = "Moderate"
    else:
        assessment = "Limited"
    
    summary_parts.append(f"**Overall Assessment**: {assessment} antimicrobial potential (Score: {overall_score:.1f}/100)")
    
    # Confidence level
    if confidence >= 0.8:
        conf_level = "High"
    elif confidence >= 0.6:
        conf_level = "Moderate"
    else:
        conf_level = "Low"
    
    summary_parts.append(f"**Confidence Level**: {conf_level} ({confidence:.2f})")
    
    # Key evidence points
    individual_scores = evidence_dict.get('individual_scores', {})
    
    if individual_scores:
        summary_parts.append("**Key Evidence:**")
        
        for evidence_type, data in individual_scores.items():
            score = data.get('score', 0)
            if score > 60:
                summary_parts.append(f"• {evidence_type.replace('_', ' ').title()}: {score:.1f}/100 (Good)")
            elif score > 30:
                summary_parts.append(f"• {evidence_type.replace('_', ' ').title()}: {score:.1f}/100 (Moderate)")
            else:
                summary_parts.append(f"• {evidence_type.replace('_', ' ').title()}: {score:.1f}/100 (Limited)")
    
    # Uncertainty factors
    uncertainties = evidence_dict.get('uncertainty_factors', [])
    if uncertainties:
        summary_parts.append("**Key Uncertainties:**")
        for uncertainty in uncertainties[:3]:  # Show top 3
            summary_parts.append(f"• {uncertainty}")
    
    return "\n".join(summary_parts)

def safe_division(numerator: float, denominator: float, default: float = 0.0) -> float:
    """
    Perform safe division with default value for zero division
    
    Args:
        numerator: Numerator value
        denominator: Denominator value
        default: Default value to return if division by zero
        
    Returns:
        Division result or default value
    """
    if pd.isna(numerator) or pd.isna(denominator) or denominator == 0:
        return default
    
    return numerator / denominator

def normalize_pathogen_name(pathogen: str) -> str:
    """
    Normalize pathogen names for consistency
    
    Args:
        pathogen: Original pathogen name
        
    Returns:
        Normalized pathogen name
    """
    if not pathogen:
        return "Unknown"
    
    # Basic normalization
    normalized = pathogen.strip().lower()
    
    # Common corrections
    corrections = {
        'staph aureus': 'staphylococcus aureus',
        'strep pyogenes': 'streptococcus pyogenes',
        'e. coli': 'escherichia coli',
        'p. aeruginosa': 'pseudomonas aeruginosa'
    }
    
    for old, new in corrections.items():
        if old in normalized:
            normalized = normalized.replace(old, new)
    
    # Capitalize first letter of each word
    return ' '.join(word.capitalize() for word in normalized.split())
