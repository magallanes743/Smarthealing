import pandas as pd
import numpy as np
import json
from database import execute_query
import streamlit as st
from sklearn.preprocessing import MinMaxScaler
from sklearn.ensemble import RandomForestRegressor
import warnings
warnings.filterwarnings('ignore')

class MultiEvidenceScorer:
    """
    Multi-evidence scoring system for antimicrobial potential assessment
    Combines QSAR/ML, literature data, ADMET properties, docking scores, and formulation constraints
    """
    
    def __init__(self):
        self.weights = {
            'qsar_ml': 0.25,
            'literature': 0.30,
            'admet': 0.20,
            'docking': 0.15,
            'formulation': 0.10
        }
        self.scaler = MinMaxScaler()
        
    def calculate_qsar_score(self, compound_data):
        """
        Calculate QSAR/ML prediction score based on molecular descriptors
        
        Args:
            compound_data: Dictionary with compound molecular properties
            
        Returns:
            Dictionary with QSAR score and confidence
        """
        try:
            # Extract molecular descriptors
            mw = compound_data.get('molecular_weight', 0)
            
            # Simple QSAR model based on molecular weight and chemical class
            # This is a simplified model - in practice, you'd use more sophisticated descriptors
            
            if mw == 0:
                return {'score': 0, 'confidence': 0.0, 'notes': 'Insufficient molecular data'}
            
            # Basic Lipinski-like rules for drug-likeness
            drug_like_score = 100
            
            # Molecular weight penalty
            if mw > 500:
                drug_like_score -= 20
            elif mw < 150:
                drug_like_score -= 15
                
            # Chemical class bonus based on known antimicrobial activity
            antimicrobial_classes = {
                'phenolic': 15,
                'terpenoid': 12,
                'alkaloid': 10,
                'flavonoid': 18,
                'quinone': 20,
                'essential oil': 15,
                'saponin': 8,
                'tannin': 16
            }
            
            chemical_class = compound_data.get('chemical_class', '').lower()
            for class_name, bonus in antimicrobial_classes.items():
                if class_name in chemical_class:
                    drug_like_score += bonus
                    break
            
            # Normalize score
            qsar_score = max(0, min(100, drug_like_score))
            
            # Confidence based on data availability
            confidence = 0.6 if mw > 0 else 0.2
            if chemical_class:
                confidence += 0.2
            
            return {
                'score': qsar_score,
                'confidence': min(1.0, confidence),
                'notes': f'Based on molecular weight ({mw}) and chemical class ({chemical_class})'
            }
            
        except Exception as e:
            return {'score': 0, 'confidence': 0.0, 'notes': f'QSAR calculation error: {str(e)}'}
    
    def calculate_literature_score(self, compound_id):
        """
        Calculate literature evidence score based on MIC/ZOI data
        
        Args:
            compound_id: Database ID of the compound
            
        Returns:
            Dictionary with literature score and confidence
        """
        try:
            # Get antimicrobial activity data from literature
            query = """
                SELECT mic_value, zoi_value, confidence_score, pathogen_type
                FROM antimicrobial_activity
                WHERE compound_id = %s AND (mic_value IS NOT NULL OR zoi_value IS NOT NULL)
            """
            
            activity_data = execute_query(query, (compound_id,))
            
            if activity_data.empty:
                return {'score': 0, 'confidence': 0.0, 'notes': 'No literature activity data available'}
            
            scores = []
            
            for _, row in activity_data.iterrows():
                mic_val = row['mic_value']
                zoi_val = row['zoi_value']
                conf_score = row['confidence_score'] or 0.5
                
                # Score based on MIC value (lower MIC = higher score)
                if pd.notna(mic_val) and mic_val > 0:
                    # Convert MIC to activity score (inverted log scale)
                    mic_score = max(0, 100 - (np.log10(mic_val) + 2) * 20)
                    scores.append(mic_score * conf_score)
                
                # Score based on ZOI value (higher ZOI = higher score)
                if pd.notna(zoi_val) and zoi_val > 0:
                    zoi_score = min(100, zoi_val * 5)  # Normalize ZOI to 0-100 scale
                    scores.append(zoi_score * conf_score)
            
            if not scores:
                return {'score': 0, 'confidence': 0.0, 'notes': 'No valid activity measurements'}
            
            # Calculate weighted average
            literature_score = np.mean(scores)
            
            # Confidence based on number of studies and average confidence
            avg_confidence = activity_data['confidence_score'].fillna(0.5).mean()
            num_studies = len(activity_data)
            confidence = min(1.0, avg_confidence * (1 + np.log10(num_studies)))
            
            return {
                'score': literature_score,
                'confidence': confidence,
                'notes': f'Based on {num_studies} activity measurements from literature'
            }
            
        except Exception as e:
            return {'score': 0, 'confidence': 0.0, 'notes': f'Literature score error: {str(e)}'}
    
    def calculate_admet_score(self, compound_id):
        """
        Calculate ADMET (Absorption, Distribution, Metabolism, Excretion, Toxicity) score
        
        Args:
            compound_id: Database ID of the compound
            
        Returns:
            Dictionary with ADMET score and confidence
        """
        try:
            query = """
                SELECT absorption, distribution, toxicity_score, 
                       skin_permeability, solubility, predicted, prediction_confidence
                FROM admet_properties
                WHERE compound_id = %s
            """
            
            admet_data = execute_query(query, (compound_id,))
            
            if admet_data.empty:
                return {'score': 50, 'confidence': 0.1, 'notes': 'No ADMET data available - default score assigned'}
            
            row = admet_data.iloc[0]
            
            # Calculate ADMET score components
            admet_score = 0
            component_count = 0
            
            # Absorption (higher is better for topical)
            if pd.notna(row['absorption']):
                admet_score += row['absorption'] * 100
                component_count += 1
            
            # Skin permeability (important for topical applications)
            if pd.notna(row['skin_permeability']):
                # Normalize permeability to 0-100 scale
                perm_score = min(100, max(0, np.log10(row['skin_permeability'] + 1e-10) + 50))
                admet_score += perm_score
                component_count += 1
            
            # Toxicity (lower toxicity score is better)
            if pd.notna(row['toxicity_score']):
                tox_score = max(0, 100 - row['toxicity_score'] * 100)
                admet_score += tox_score
                component_count += 1
            
            # Solubility (important for formulation)
            if pd.notna(row['solubility']):
                sol_score = min(100, max(0, np.log10(row['solubility'] + 1e-10) + 50))
                admet_score += sol_score
                component_count += 1
            
            if component_count == 0:
                return {'score': 50, 'confidence': 0.1, 'notes': 'No valid ADMET values'}
            
            final_admet_score = admet_score / component_count
            
            # Confidence based on prediction confidence and data completeness
            confidence = row['prediction_confidence'] or 0.5
            if not row['predicted']:  # Experimental data is more reliable
                confidence = min(1.0, confidence + 0.3)
            
            return {
                'score': final_admet_score,
                'confidence': confidence,
                'notes': f'Based on {component_count} ADMET parameters'
            }
            
        except Exception as e:
            return {'score': 50, 'confidence': 0.1, 'notes': f'ADMET calculation error: {str(e)}'}
    
    def calculate_docking_score(self, compound_id):
        """
        Calculate molecular docking score
        
        Args:
            compound_id: Database ID of the compound
            
        Returns:
            Dictionary with docking score and confidence
        """
        try:
            query = """
                SELECT binding_affinity, ligand_efficiency, target_protein
                FROM docking_results
                WHERE compound_id = %s
                ORDER BY binding_affinity DESC
            """
            
            docking_data = execute_query(query, (compound_id,))
            
            if docking_data.empty:
                return {'score': 0, 'confidence': 0.0, 'notes': 'No docking data available'}
            
            # Use best binding affinity
            best_affinity = docking_data.iloc[0]['binding_affinity']
            
            # Convert binding affinity to score (more negative = better binding = higher score)
            # Typical range: -12 to 0 kcal/mol
            if best_affinity <= -8:
                docking_score = 100
            elif best_affinity >= 0:
                docking_score = 0
            else:
                # Linear scaling between 0 and 100
                docking_score = (abs(best_affinity) / 8) * 100
            
            # Consider ligand efficiency if available
            if pd.notna(docking_data.iloc[0]['ligand_efficiency']):
                le_score = min(100, docking_data.iloc[0]['ligand_efficiency'] * 200)
                docking_score = (docking_score + le_score) / 2
            
            # Confidence is moderate for docking (computational prediction)
            confidence = 0.6
            
            # Bonus for multiple target predictions
            num_targets = len(docking_data)
            confidence = min(1.0, confidence + (num_targets - 1) * 0.1)
            
            return {
                'score': docking_score,
                'confidence': confidence,
                'notes': f'Best binding affinity: {best_affinity:.2f} kcal/mol ({num_targets} targets)'
            }
            
        except Exception as e:
            return {'score': 0, 'confidence': 0.0, 'notes': f'Docking score error: {str(e)}'}
    
    def calculate_formulation_score(self, compound_data, wound_type="general"):
        """
        Calculate formulation feasibility score
        
        Args:
            compound_data: Dictionary with compound properties
            wound_type: Type of wound for formulation considerations
            
        Returns:
            Dictionary with formulation score and confidence
        """
        try:
            formulation_score = 70  # Base score
            
            mw = compound_data.get('molecular_weight', 0)
            chemical_class = compound_data.get('chemical_class', '').lower()
            
            # Molecular weight considerations for topical delivery
            if 200 <= mw <= 500:
                formulation_score += 20  # Optimal range
            elif mw < 200:
                formulation_score += 10  # May be volatile
            else:
                formulation_score -= 15  # May have poor penetration
            
            # Chemical class considerations for formulation
            formulation_friendly = {
                'phenolic': 15,      # Generally stable and soluble
                'terpenoid': 10,     # May be volatile but extractable
                'flavonoid': 18,     # Good stability in formulations
                'alkaloid': 5,       # May have stability issues
                'essential oil': -5, # Volatile and may cause irritation
                'saponin': 12,       # Good emulsifying properties
                'tannin': 8          # May have compatibility issues
            }
            
            for class_name, modifier in formulation_friendly.items():
                if class_name in chemical_class:
                    formulation_score += modifier
                    break
            
            # Wound type specific considerations
            wound_modifiers = {
                'acute': 5,    # Less challenging formulation requirements
                'chronic': -5, # May need specialized delivery
                'infected': 10, # Antimicrobial activity is primary concern
                'burn': -10,   # Requires gentle, non-irritating formulation
                'surgical': 0  # Standard requirements
            }
            
            formulation_score += wound_modifiers.get(wound_type.lower(), 0)
            
            # Normalize score
            formulation_score = max(0, min(100, formulation_score))
            
            # Confidence based on available data
            confidence = 0.7
            if mw > 0:
                confidence += 0.1
            if chemical_class:
                confidence += 0.1
            
            return {
                'score': formulation_score,
                'confidence': min(1.0, confidence),
                'notes': f'Formulation assessment for {wound_type} wounds'
            }
            
        except Exception as e:
            return {'score': 50, 'confidence': 0.3, 'notes': f'Formulation score error: {str(e)}'}
    
    def calculate_overall_score(self, compound_id, compound_data, wound_type="general"):
        """
        Calculate overall multi-evidence score
        
        Args:
            compound_id: Database ID of the compound
            compound_data: Dictionary with compound properties
            wound_type: Type of wound for context
            
        Returns:
            Dictionary with overall score and detailed breakdown
        """
        try:
            # Calculate individual scores
            qsar_result = self.calculate_qsar_score(compound_data)
            literature_result = self.calculate_literature_score(compound_id)
            admet_result = self.calculate_admet_score(compound_id)
            docking_result = self.calculate_docking_score(compound_id)
            formulation_result = self.calculate_formulation_score(compound_data, wound_type)
            
            # Extract scores and confidences
            scores = {
                'qsar_ml': qsar_result['score'],
                'literature': literature_result['score'],
                'admet': admet_result['score'],
                'docking': docking_result['score'],
                'formulation': formulation_result['score']
            }
            
            confidences = {
                'qsar_ml': qsar_result['confidence'],
                'literature': literature_result['confidence'],
                'admet': admet_result['confidence'],
                'docking': docking_result['confidence'],
                'formulation': formulation_result['confidence']
            }
            
            # Calculate weighted overall score
            overall_score = sum(scores[key] * self.weights[key] for key in scores)
            
            # Calculate overall confidence (weighted average)
            overall_confidence = sum(confidences[key] * self.weights[key] for key in confidences)
            
            # Uncertainty assessment
            uncertainty_factors = []
            
            if literature_result['score'] == 0:
                uncertainty_factors.append("No experimental antimicrobial data available")
            
            if docking_result['score'] == 0:
                uncertainty_factors.append("No molecular docking predictions available")
            
            if admet_result['confidence'] < 0.5:
                uncertainty_factors.append("Limited ADMET property data")
            
            if overall_confidence < 0.6:
                uncertainty_factors.append("Overall low confidence due to limited data")
            
            # Evidence strength assessment
            if overall_confidence >= 0.8:
                evidence_strength = "Strong"
            elif overall_confidence >= 0.6:
                evidence_strength = "Moderate"
            else:
                evidence_strength = "Weak"
            
            return {
                'overall_score': round(overall_score, 1),
                'overall_confidence': round(overall_confidence, 3),
                'evidence_strength': evidence_strength,
                'individual_scores': {
                    'qsar_ml': {
                        'score': round(scores['qsar_ml'], 1),
                        'confidence': round(confidences['qsar_ml'], 3),
                        'weight': self.weights['qsar_ml'],
                        'notes': qsar_result['notes']
                    },
                    'literature': {
                        'score': round(scores['literature'], 1),
                        'confidence': round(confidences['literature'], 3),
                        'weight': self.weights['literature'],
                        'notes': literature_result['notes']
                    },
                    'admet': {
                        'score': round(scores['admet'], 1),
                        'confidence': round(confidences['admet'], 3),
                        'weight': self.weights['admet'],
                        'notes': admet_result['notes']
                    },
                    'docking': {
                        'score': round(scores['docking'], 1),
                        'confidence': round(confidences['docking'], 3),
                        'weight': self.weights['docking'],
                        'notes': docking_result['notes']
                    },
                    'formulation': {
                        'score': round(scores['formulation'], 1),
                        'confidence': round(confidences['formulation'], 3),
                        'weight': self.weights['formulation'],
                        'notes': formulation_result['notes']
                    }
                },
                'uncertainty_factors': uncertainty_factors,
                'recommendations': self._generate_recommendations(scores, confidences, uncertainty_factors)
            }
            
        except Exception as e:
            st.error(f"Overall scoring error: {str(e)}")
            return {
                'overall_score': 0,
                'overall_confidence': 0,
                'evidence_strength': 'Insufficient',
                'error': str(e)
            }
    
    def _generate_recommendations(self, scores, confidences, uncertainty_factors):
        """Generate recommendations based on scoring results"""
        recommendations = []
        
        # High potential recommendations
        if scores['literature'] > 70:
            recommendations.append("Strong literature evidence supports antimicrobial potential")
        
        if scores['qsar_ml'] > 70 and confidences['qsar_ml'] > 0.7:
            recommendations.append("QSAR predictions indicate favorable drug-like properties")
        
        if scores['admet'] > 70:
            recommendations.append("Favorable ADMET profile for topical application")
        
        # Areas needing attention
        if scores['literature'] < 30:
            recommendations.append("Experimental validation needed - limited literature evidence")
        
        if scores['docking'] < 30:
            recommendations.append("Consider molecular docking studies to identify target proteins")
        
        if scores['formulation'] < 50:
            recommendations.append("Formulation challenges may need to be addressed")
        
        # Data gap recommendations
        if 'No experimental antimicrobial data available' in uncertainty_factors:
            recommendations.append("Priority: Conduct MIC/ZOI assays against target pathogens")
        
        if 'Limited ADMET property data' in uncertainty_factors:
            recommendations.append("Consider ADMET studies for safety and efficacy prediction")
        
        return recommendations

def rank_compounds_by_evidence(compounds_df, wound_type="general"):
    """
    Rank multiple compounds using multi-evidence scoring
    
    Args:
        compounds_df: DataFrame with compound information
        wound_type: Type of wound for context
        
    Returns:
        DataFrame with compounds ranked by overall score
    """
    scorer = MultiEvidenceScorer()
    results = []
    
    for _, compound in compounds_df.iterrows():
        compound_data = {
            'molecular_weight': compound.get('molecular_weight', 0),
            'chemical_class': compound.get('chemical_class', ''),
            'name': compound.get('name', '')
        }
        
        score_result = scorer.calculate_overall_score(
            compound.get('id'), 
            compound_data, 
            wound_type
        )
        
        results.append({
            'compound_id': compound.get('id'),
            'compound_name': compound.get('name', 'Unknown'),
            'overall_score': score_result['overall_score'],
            'overall_confidence': score_result['overall_confidence'],
            'evidence_strength': score_result['evidence_strength'],
            'qsar_score': score_result['individual_scores']['qsar_ml']['score'],
            'literature_score': score_result['individual_scores']['literature']['score'],
            'admet_score': score_result['individual_scores']['admet']['score'],
            'docking_score': score_result['individual_scores']['docking']['score'],
            'formulation_score': score_result['individual_scores']['formulation']['score']
        })
    
    results_df = pd.DataFrame(results)
    return results_df.sort_values('overall_score', ascending=False)
