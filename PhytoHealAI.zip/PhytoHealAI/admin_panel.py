import streamlit as st
import pandas as pd
import json
import os
import hashlib
from database import insert_data, update_data, execute_query, get_db_cursor
from utils import validate_chemical_formula, validate_doi, validate_smiles

def admin_authentication():
    """Simple admin authentication"""
    if 'admin_authenticated' not in st.session_state:
        st.session_state.admin_authenticated = False
    
    if not st.session_state.admin_authenticated:
        st.subheader("🔐 Admin Authentication Required")
        
        col1, col2 = st.columns([1, 2])
        with col1:
            password = st.text_input("Admin Password", type="password", key="admin_password")
            
        with col2:
            if st.button("Login", key="admin_login"):
                # Use environment variable for password, fallback to demo for development
                admin_password = os.getenv("ADMIN_PASSWORD", "admin123")
                
                # Hash the input password for comparison (in production, store hashed passwords)
                input_hash = hashlib.sha256(password.encode()).hexdigest()
                stored_hash = hashlib.sha256(admin_password.encode()).hexdigest()
                
                if input_hash == stored_hash:
                    st.session_state.admin_authenticated = True
                    st.success("Authentication successful!")
                    st.rerun()
                else:
                    st.error("Invalid password")
        
        if os.getenv("ADMIN_PASSWORD") is None:
            st.info("**Demo Password**: admin123 (Set ADMIN_PASSWORD environment variable for production)")
        return False
    
    return True

def add_plant_form():
    """Form for adding new plant data"""
    st.subheader("🌿 Add New Plant Species")
    
    with st.form("add_plant_form"):
        col1, col2 = st.columns(2)
        
        with col1:
            scientific_name = st.text_input(
                "Scientific Name *", 
                help="Binomial nomenclature (e.g., Aloe vera)"
            )
            common_name = st.text_input(
                "Common Name",
                help="Popular or vernacular name"
            )
            family = st.text_input(
                "Plant Family",
                help="Taxonomic family (e.g., Asphodelaceae)"
            )
        
        with col2:
            traditional_use = st.text_area(
                "Traditional Use",
                help="Historical or traditional medicinal applications",
                height=100
            )
            safety_profile = st.text_area(
                "Safety Profile",
                help="Known safety information, contraindications, or adverse effects",
                height=100
            )
        
        submitted = st.form_submit_button("Add Plant Species")
        
        if submitted:
            if not scientific_name.strip():
                st.error("Scientific name is required")
                return
            
            try:
                plant_data = {
                    'scientific_name': scientific_name.strip(),
                    'common_name': common_name.strip() if common_name.strip() else None,
                    'family': family.strip() if family.strip() else None,
                    'traditional_use': traditional_use.strip() if traditional_use.strip() else None,
                    'safety_profile': safety_profile.strip() if safety_profile.strip() else None
                }
                
                plant_id = insert_data('plants', plant_data)
                
                if plant_id:
                    st.success(f"Plant species '{scientific_name}' added successfully! (ID: {plant_id})")
                else:
                    st.error("Failed to add plant species. It may already exist.")
                    
            except Exception as e:
                st.error(f"Error adding plant: {str(e)}")

def add_phytochemical_form():
    """Form for adding new phytochemical data"""
    st.subheader("⚗️ Add New Phytochemical")
    
    with st.form("add_phytochemical_form"):
        col1, col2 = st.columns(2)
        
        with col1:
            name = st.text_input(
                "Compound Name *",
                help="Chemical name or common name"
            )
            chemical_formula = st.text_input(
                "Chemical Formula",
                help="Molecular formula (e.g., C10H12N2O)"
            )
            molecular_weight = st.number_input(
                "Molecular Weight (g/mol)",
                min_value=0.0,
                value=0.0,
                step=0.01
            )
        
        with col2:
            smiles = st.text_input(
                "SMILES",
                help="Simplified molecular-input line-entry system"
            )
            chemical_class = st.selectbox(
                "Chemical Class",
                ["", "Phenolic", "Terpenoid", "Alkaloid", "Flavonoid", 
                 "Quinone", "Essential Oil", "Saponin", "Tannin", "Glycoside", "Other"]
            )
            biological_activity = st.text_area(
                "Biological Activity",
                help="Known biological activities and mechanisms",
                height=100
            )
        
        submitted = st.form_submit_button("Add Phytochemical")
        
        if submitted:
            if not name.strip():
                st.error("Compound name is required")
                return
            
            # Validate inputs
            if chemical_formula and not validate_chemical_formula(chemical_formula):
                st.error("Invalid chemical formula format")
                return
            
            if smiles and not validate_smiles(smiles):
                st.error("Invalid SMILES format")
                return
            
            try:
                compound_data = {
                    'name': name.strip(),
                    'chemical_formula': chemical_formula.strip() if chemical_formula.strip() else None,
                    'molecular_weight': molecular_weight if molecular_weight > 0 else None,
                    'smiles': smiles.strip() if smiles.strip() else None,
                    'chemical_class': chemical_class if chemical_class else None,
                    'biological_activity': biological_activity.strip() if biological_activity.strip() else None
                }
                
                compound_id = insert_data('phytochemicals', compound_data)
                
                if compound_id:
                    st.success(f"Phytochemical '{name}' added successfully! (ID: {compound_id})")
                else:
                    st.error("Failed to add phytochemical")
                    
            except Exception as e:
                st.error(f"Error adding phytochemical: {str(e)}")

def add_plant_compound_relationship():
    """Form for linking plants with their phytochemicals"""
    st.subheader("🔗 Link Plant with Phytochemical")
    
    # Get available plants and compounds
    plants = execute_query("SELECT id, scientific_name, common_name FROM plants ORDER BY scientific_name")
    compounds = execute_query("SELECT id, name, chemical_class FROM phytochemicals ORDER BY name")
    
    if plants.empty or compounds.empty:
        st.warning("Please add plants and phytochemicals before creating relationships")
        return
    
    with st.form("plant_compound_form"):
        col1, col2 = st.columns(2)
        
        with col1:
            plant_options = [f"{row['scientific_name']} ({row['common_name'] or 'No common name'})" 
                           for _, row in plants.iterrows()]
            selected_plant_idx = st.selectbox("Select Plant *", range(len(plant_options)), 
                                            format_func=lambda x: plant_options[x])
            
            concentration_range = st.text_input(
                "Concentration Range",
                help="e.g., '0.5-2.3%' or '10-50 mg/g'"
            )
        
        with col2:
            compound_options = [f"{row['name']} ({row['chemical_class'] or 'Unknown class'})" 
                              for _, row in compounds.iterrows()]
            selected_compound_idx = st.selectbox("Select Phytochemical *", range(len(compound_options)),
                                                format_func=lambda x: compound_options[x])
            
            extraction_method = st.selectbox(
                "Extraction Method",
                ["", "Water extraction", "Ethanol extraction", "Methanol extraction", 
                 "Steam distillation", "Supercritical CO2", "Hexane extraction", "Other"]
            )
        
        reference_study = st.text_input(
            "Reference Study",
            help="Citation or DOI of the study reporting this data"
        )
        
        submitted = st.form_submit_button("Link Plant-Compound")
        
        if submitted:
            try:
                plant_id = plants.iloc[selected_plant_idx]['id']
                compound_id = compounds.iloc[selected_compound_idx]['id']
                
                relationship_data = {
                    'plant_id': plant_id,
                    'phytochemical_id': compound_id,
                    'concentration_range': concentration_range.strip() if concentration_range.strip() else None,
                    'extraction_method': extraction_method if extraction_method else None,
                    'reference_study': reference_study.strip() if reference_study.strip() else None
                }
                
                relationship_id = insert_data('plant_compounds', relationship_data)
                
                if relationship_id:
                    st.success("Plant-compound relationship added successfully!")
                else:
                    st.error("Failed to add relationship. It may already exist.")
                    
            except Exception as e:
                st.error(f"Error adding relationship: {str(e)}")

def add_antimicrobial_activity():
    """Form for adding antimicrobial activity data"""
    st.subheader("🦠 Add Antimicrobial Activity Data")
    
    compounds = execute_query("SELECT id, name FROM phytochemicals ORDER BY name")
    
    if compounds.empty:
        st.warning("Please add phytochemicals before adding activity data")
        return
    
    with st.form("antimicrobial_activity_form"):
        col1, col2 = st.columns(2)
        
        with col1:
            compound_options = [row['name'] for _, row in compounds.iterrows()]
            selected_compound_idx = st.selectbox("Select Compound *", range(len(compound_options)),
                                                format_func=lambda x: compound_options[x])
            
            pathogen_name = st.text_input(
                "Pathogen Name *",
                help="Scientific name of the microorganism"
            )
            
            pathogen_type = st.selectbox(
                "Pathogen Type *",
                ["bacteria", "fungus", "virus", "parasite"]
            )
            
            test_method = st.selectbox(
                "Test Method",
                ["", "Disc diffusion", "Broth microdilution", "Agar dilution", 
                 "Time-kill assay", "Biofilm assay", "Other"]
            )
        
        with col2:
            mic_value = st.number_input(
                "MIC Value (µg/mL)",
                min_value=0.0,
                value=0.0,
                step=0.001,
                help="Minimum Inhibitory Concentration"
            )
            
            zoi_value = st.number_input(
                "Zone of Inhibition (mm)",
                min_value=0.0,
                value=0.0,
                step=0.1
            )
            
            reference_doi = st.text_input(
                "Reference DOI",
                help="Digital Object Identifier of the source publication"
            )
            
            confidence_score = st.slider(
                "Confidence Score",
                min_value=0.0,
                max_value=1.0,
                value=0.7,
                step=0.1,
                help="Confidence in the reported data (0.0 = low, 1.0 = high)"
            )
        
        submitted = st.form_submit_button("Add Activity Data")
        
        if submitted:
            if not pathogen_name.strip():
                st.error("Pathogen name is required")
                return
            
            if mic_value == 0 and zoi_value == 0:
                st.error("At least one activity measurement (MIC or ZOI) is required")
                return
            
            if reference_doi and not validate_doi(reference_doi):
                st.error("Invalid DOI format")
                return
            
            try:
                compound_id = compounds.iloc[selected_compound_idx]['id']
                
                activity_data = {
                    'compound_id': compound_id,
                    'pathogen_name': pathogen_name.strip(),
                    'pathogen_type': pathogen_type,
                    'mic_value': mic_value if mic_value > 0 else None,
                    'zoi_value': zoi_value if zoi_value > 0 else None,
                    'test_method': test_method if test_method else None,
                    'reference_doi': reference_doi.strip() if reference_doi.strip() else None,
                    'confidence_score': confidence_score
                }
                
                activity_id = insert_data('antimicrobial_activity', activity_data)
                
                if activity_id:
                    st.success("Antimicrobial activity data added successfully!")
                else:
                    st.error("Failed to add activity data")
                    
            except Exception as e:
                st.error(f"Error adding activity data: {str(e)}")

def add_literature_reference():
    """Form for adding literature references"""
    st.subheader("📚 Add Literature Reference")
    
    with st.form("literature_reference_form"):
        col1, col2 = st.columns(2)
        
        with col1:
            doi = st.text_input(
                "DOI",
                help="Digital Object Identifier"
            )
            title = st.text_input(
                "Title *",
                help="Full title of the publication"
            )
            authors = st.text_input(
                "Authors",
                help="Author names (comma-separated)"
            )
            journal = st.text_input(
                "Journal",
                help="Journal or publication name"
            )
        
        with col2:
            publication_year = st.number_input(
                "Publication Year",
                min_value=1900,
                max_value=2025,
                value=2023,
                step=1
            )
            
            study_type = st.selectbox(
                "Study Type",
                ["", "in_vitro", "in_vivo", "clinical_trial", "review", "meta_analysis", "other"]
            )
            
            confidence_rating = st.slider(
                "Confidence Rating",
                min_value=1,
                max_value=5,
                value=3,
                help="Quality rating (1=low, 5=high)"
            )
        
        abstract = st.text_area(
            "Abstract",
            help="Publication abstract or summary",
            height=150
        )
        
        submitted = st.form_submit_button("Add Reference")
        
        if submitted:
            if not title.strip():
                st.error("Title is required")
                return
            
            if doi and not validate_doi(doi):
                st.error("Invalid DOI format")
                return
            
            try:
                reference_data = {
                    'doi': doi.strip() if doi.strip() else None,
                    'title': title.strip(),
                    'authors': authors.strip() if authors.strip() else None,
                    'journal': journal.strip() if journal.strip() else None,
                    'publication_year': publication_year,
                    'abstract': abstract.strip() if abstract.strip() else None,
                    'study_type': study_type if study_type else None,
                    'confidence_rating': confidence_rating
                }
                
                reference_id = insert_data('literature_references', reference_data)
                
                if reference_id:
                    st.success("Literature reference added successfully!")
                else:
                    st.error("Failed to add reference. DOI may already exist.")
                    
            except Exception as e:
                st.error(f"Error adding reference: {str(e)}")

def bulk_data_upload():
    """Bulk data upload functionality"""
    st.subheader("📤 Bulk Data Upload")
    
    upload_type = st.selectbox(
        "Select Data Type",
        ["Plants", "Phytochemicals", "Antimicrobial Activity", "Literature References"]
    )
    
    if upload_type == "Plants":
        st.markdown("""
        **Required columns**: `scientific_name`  
        **Optional columns**: `common_name`, `family`, `traditional_use`, `safety_profile`
        """)
        
    elif upload_type == "Phytochemicals":
        st.markdown("""
        **Required columns**: `name`  
        **Optional columns**: `chemical_formula`, `molecular_weight`, `smiles`, `chemical_class`, `biological_activity`
        """)
        
    elif upload_type == "Antimicrobial Activity":
        st.markdown("""
        **Required columns**: `compound_name`, `pathogen_name`, `pathogen_type`  
        **Optional columns**: `mic_value`, `zoi_value`, `test_method`, `reference_doi`, `confidence_score`
        """)
        
    elif upload_type == "Literature References":
        st.markdown("""
        **Required columns**: `title`  
        **Optional columns**: `doi`, `authors`, `journal`, `publication_year`, `abstract`, `study_type`, `confidence_rating`
        """)
    
    uploaded_file = st.file_uploader(
        "Upload CSV file",
        type=['csv'],
        help="Upload a CSV file with the required columns"
    )
    
    if uploaded_file is not None:
        try:
            df = pd.read_csv(uploaded_file)
            st.subheader("Preview of uploaded data:")
            st.dataframe(df.head())
            
            if st.button("Process Upload"):
                success_count = 0
                error_count = 0
                
                progress_bar = st.progress(0)
                status_text = st.empty()
                
                for idx, row in df.iterrows():
                    try:
                        if upload_type == "Plants":
                            if pd.notna(row['scientific_name']):
                                plant_data = {
                                    'scientific_name': str(row['scientific_name']).strip(),
                                    'common_name': str(row.get('common_name', '')).strip() or None,
                                    'family': str(row.get('family', '')).strip() or None,
                                    'traditional_use': str(row.get('traditional_use', '')).strip() or None,
                                    'safety_profile': str(row.get('safety_profile', '')).strip() or None
                                }
                                if insert_data('plants', plant_data):
                                    success_count += 1
                                else:
                                    error_count += 1
                        
                        # Add similar processing for other upload types...
                        
                    except Exception as e:
                        error_count += 1
                        st.write(f"Error processing row {idx + 1}: {str(e)}")
                    
                    progress_bar.progress((idx + 1) / len(df))
                    status_text.text(f"Processing row {idx + 1} of {len(df)}")
                
                st.success(f"Upload completed! {success_count} records added, {error_count} errors.")
                
        except Exception as e:
            st.error(f"Error processing file: {str(e)}")

def data_management():
    """Data management and editing interface"""
    st.subheader("📝 Data Management")
    
    management_type = st.selectbox(
        "Select Management Type",
        ["View/Edit Plants", "View/Edit Phytochemicals", "View/Edit Activity Data", "Database Statistics"]
    )
    
    if management_type == "Database Statistics":
        col1, col2, col3, col4 = st.columns(4)
        
        with col1:
            plants_count = execute_query("SELECT COUNT(*) as count FROM plants")
            st.metric("Plants", plants_count.iloc[0]['count'] if not plants_count.empty else 0)
        
        with col2:
            compounds_count = execute_query("SELECT COUNT(*) as count FROM phytochemicals")
            st.metric("Compounds", compounds_count.iloc[0]['count'] if not compounds_count.empty else 0)
        
        with col3:
            activity_count = execute_query("SELECT COUNT(*) as count FROM antimicrobial_activity")
            st.metric("Activity Records", activity_count.iloc[0]['count'] if not activity_count.empty else 0)
        
        with col4:
            references_count = execute_query("SELECT COUNT(*) as count FROM literature_references")
            st.metric("References", references_count.iloc[0]['count'] if not references_count.empty else 0)
        
        # Show recent additions
        st.subheader("Recent Additions")
        recent_plants = execute_query("""
            SELECT scientific_name, common_name, created_at
            FROM plants 
            ORDER BY created_at DESC 
            LIMIT 5
        """)
        
        if not recent_plants.empty:
            st.write("**Recent Plants:**")
            st.dataframe(recent_plants)
    
    elif management_type == "View/Edit Plants":
        plants = execute_query("""
            SELECT id, scientific_name, common_name, family, 
                   traditional_use, safety_profile, created_at
            FROM plants 
            ORDER BY scientific_name
        """)
        
        if not plants.empty:
            st.dataframe(plants, use_container_width=True)
            
            # Allow editing selected plant
            if st.checkbox("Edit Plant Data"):
                selected_plant_id = st.selectbox(
                    "Select Plant to Edit",
                    plants['id'].tolist(),
                    format_func=lambda x: plants[plants['id'] == x]['scientific_name'].iloc[0]
                )
                
                if selected_plant_id:
                    plant_data = plants[plants['id'] == selected_plant_id].iloc[0]
                    
                    with st.form("edit_plant_form"):
                        col1, col2 = st.columns(2)
                        
                        with col1:
                            new_scientific_name = st.text_input("Scientific Name", value=plant_data['scientific_name'])
                            new_common_name = st.text_input("Common Name", value=plant_data['common_name'] or "")
                            new_family = st.text_input("Family", value=plant_data['family'] or "")
                        
                        with col2:
                            new_traditional_use = st.text_area("Traditional Use", value=plant_data['traditional_use'] or "", height=100)
                            new_safety_profile = st.text_area("Safety Profile", value=plant_data['safety_profile'] or "", height=100)
                        
                        if st.form_submit_button("Update Plant"):
                            try:
                                update_data_dict = {
                                    'scientific_name': new_scientific_name.strip(),
                                    'common_name': new_common_name.strip() if new_common_name.strip() else None,
                                    'family': new_family.strip() if new_family.strip() else None,
                                    'traditional_use': new_traditional_use.strip() if new_traditional_use.strip() else None,
                                    'safety_profile': new_safety_profile.strip() if new_safety_profile.strip() else None
                                }
                                
                                success = update_data('plants', update_data_dict, {'id': selected_plant_id})
                                if success:
                                    st.success("Plant updated successfully!")
                                    st.rerun()
                                else:
                                    st.error("Failed to update plant")
                            except Exception as e:
                                st.error(f"Error updating plant: {str(e)}")
        else:
            st.info("No plants in database")
    
    elif management_type == "View/Edit Phytochemicals":
        phytochemicals = execute_query("""
            SELECT id, name, chemical_formula, molecular_weight, 
                   chemical_class, biological_activity, created_at
            FROM phytochemicals 
            ORDER BY name
        """)
        
        if not phytochemicals.empty:
            st.dataframe(phytochemicals, use_container_width=True)
            
            # Show plant associations
            st.subheader("Plant-Compound Relationships")
            compound_plants = execute_query("""
                SELECT p.scientific_name, ph.name as compound_name, 
                       pc.concentration_range, pc.extraction_method
                FROM plant_compounds pc
                JOIN plants p ON pc.plant_id = p.id
                JOIN phytochemicals ph ON pc.phytochemical_id = ph.id
                ORDER BY ph.name, p.scientific_name
            """)
            
            if not compound_plants.empty:
                st.dataframe(compound_plants, use_container_width=True)
            else:
                st.info("No plant-compound relationships found")
        else:
            st.info("No phytochemicals in database")
    
    elif management_type == "View/Edit Activity Data":
        activity_data = execute_query("""
            SELECT aa.id, ph.name as compound_name, aa.pathogen_name, 
                   aa.pathogen_type, aa.mic_value, aa.zoi_value, 
                   aa.test_method, aa.reference_doi, aa.confidence_score, aa.created_at
            FROM antimicrobial_activity aa
            JOIN phytochemicals ph ON aa.compound_id = ph.id
            ORDER BY ph.name, aa.pathogen_name
        """)
        
        if not activity_data.empty:
            st.dataframe(activity_data, use_container_width=True)
            
            # Activity statistics
            st.subheader("Activity Data Statistics")
            col1, col2, col3 = st.columns(3)
            
            with col1:
                unique_compounds = activity_data['compound_name'].nunique()
                st.metric("Compounds Tested", unique_compounds)
            
            with col2:
                unique_pathogens = activity_data['pathogen_name'].nunique()
                st.metric("Unique Pathogens", unique_pathogens)
            
            with col3:
                avg_confidence = activity_data['confidence_score'].mean()
                st.metric("Avg Confidence", f"{avg_confidence:.2f}" if not pd.isna(avg_confidence) else "N/A")
            
            # Most active compounds
            st.subheader("Most Active Compounds (Lowest MIC)")
            best_mic = activity_data[activity_data['mic_value'].notna()].nsmallest(10, 'mic_value')
            if not best_mic.empty:
                st.dataframe(best_mic[['compound_name', 'pathogen_name', 'mic_value', 'confidence_score']])
        else:
            st.info("No antimicrobial activity data in database")
