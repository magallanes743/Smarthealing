import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from database import init_database, get_database_connection
from phytochemical_db import get_plant_overview_stats
import warnings
warnings.filterwarnings('ignore')

# Initialize database on startup
init_database()

st.set_page_config(
    page_title="AI Antimicrobial Discovery Assistant",
    page_icon="🧬",
    layout="wide",
    initial_sidebar_state="expanded"
)

st.title("🧬 AI-Powered Scientific Assistant")
st.subheader("Antimicrobial Discovery & Wound-Healing Formulation")

# Sidebar navigation
st.sidebar.title("Navigation")
st.sidebar.markdown("""
**Available Modules:**
- 🔬 Phytochemical Database
- 🤖 AI Analysis
- 🌿 Plant-Wound Matching
- ⚙️ Admin Panel
- 📚 Literature Integration
""")

# Main dashboard content
col1, col2, col3 = st.columns(3)

try:
    stats = get_plant_overview_stats()
    
    with col1:
        st.metric(
            label="Plant Species",
            value=stats.get('total_plants', 0),
            help="Total number of plant species in database"
        )
    
    with col2:
        st.metric(
            label="Phytochemicals",
            value=stats.get('total_compounds', 0),
            help="Total number of identified phytochemicals"
        )
    
    with col3:
        st.metric(
            label="Research Studies",
            value=stats.get('total_studies', 0),
            help="Number of scientific studies referenced"
        )

except Exception as e:
    st.error(f"Error loading dashboard statistics: {str(e)}")
    with col1:
        st.metric("Plant Species", 0)
    with col2:
        st.metric("Phytochemicals", 0)
    with col3:
        st.metric("Research Studies", 0)

st.markdown("---")

# Feature overview
st.subheader("🔬 Scientific Features")

feature_col1, feature_col2 = st.columns(2)

with feature_col1:
    st.markdown("""
    ### Multi-Evidence Scoring System
    - **QSAR/ML Predictions**: Machine learning models for activity prediction
    - **Literature MIC/ZOI Data**: Minimum inhibitory concentration and zone of inhibition data
    - **ADMET Properties**: Absorption, Distribution, Metabolism, Excretion, Toxicity analysis
    - **Molecular Docking Scores**: Protein-ligand binding affinity predictions
    - **Formulation Constraints**: Practical considerations for wound treatment
    """)

with feature_col2:
    st.markdown("""
    ### Evidence-Based Approach
    - **Scientific Validity**: All predictions based on peer-reviewed research
    - **Transparent Assumptions**: Clear documentation of model limitations
    - **Reproducibility**: Machine-readable outputs for workflow integration
    - **Uncertainty Quantification**: Identification of data gaps and confidence intervals
    - **Literature Integration**: Citation tracking and reference validation
    """)

st.markdown("---")

st.subheader("⚠️ Important Scientific Disclaimers")

st.warning("""
**Research Tool Only**: This application is designed for scientific research and hypothesis generation. 
It is not intended for clinical diagnosis or treatment recommendations.
""")

st.info("""
**Docking Limitations**: Molecular docking scores are used for hypothesis generation only. 
High docking scores do not guarantee biological activity or therapeutic efficacy.
""")

st.markdown("""
### Scientific Methodology
- **Multi-Evidence Approach**: Combines computational predictions with experimental data
- **Uncertainty Reporting**: Clearly states confidence levels and data limitations
- **Literature Validation**: Cross-references predictions with published research
- **Experimental Guidance**: Suggests next steps for experimental validation
""")

# Footer
st.markdown("---")
st.markdown("""
<div style='text-align: center; color: #666;'>
<p>AI-Powered Scientific Assistant for Antimicrobial Discovery</p>
<p>Version 1.0 | Built with Streamlit | Scientific Computing Stack</p>
</div>
""", unsafe_allow_html=True)
