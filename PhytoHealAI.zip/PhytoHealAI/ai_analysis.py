import json
import os
import hashlib
from openai import OpenAI
import streamlit as st
from database import execute_query, insert_data

# the newest OpenAI model is "gpt-5" which was released August 7, 2025.
# do not change this unless explicitly requested by the user
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")
openai_client = OpenAI(api_key=OPENAI_API_KEY)

def generate_query_hash(query_params):
    """Generate a hash for query parameters to cache results"""
    query_string = json.dumps(query_params, sort_keys=True)
    return hashlib.sha256(query_string.encode()).hexdigest()

def get_cached_analysis(query_hash):
    """Retrieve cached analysis result"""
    query = """
        SELECT analysis_result, confidence_score 
        FROM ai_analysis_cache 
        WHERE query_hash = %s AND expires_at > NOW()
    """
    result = execute_query(query, (query_hash,))
    
    if not result.empty:
        return result.iloc[0]['analysis_result'], result.iloc[0]['confidence_score']
    return None, None

def cache_analysis_result(query_hash, query_params, result, confidence_score, hours=24):
    """Cache analysis result for future use"""
    try:
        data = {
            'query_hash': query_hash,
            'query_parameters': json.dumps(query_params),
            'analysis_result': json.dumps(result),
            'confidence_score': confidence_score,
            'expires_at': f"NOW() + INTERVAL '{hours} hours'"
        }
        insert_data('ai_analysis_cache', data)
    except Exception as e:
        st.warning(f"Failed to cache analysis result: {str(e)}")

def analyze_antimicrobial_potential(compound_data, pathogen_info, wound_characteristics):
    """
    Analyze antimicrobial potential using multi-evidence approach
    
    Args:
        compound_data: Dictionary with compound information
        pathogen_info: Dictionary with pathogen characteristics
        wound_characteristics: Dictionary with wound type and properties
    
    Returns:
        Dictionary with analysis results and confidence scores
    """
    
    # Generate query hash for caching
    query_params = {
        'compound': compound_data,
        'pathogen': pathogen_info,
        'wound': wound_characteristics
    }
    query_hash = generate_query_hash(query_params)
    
    # Check cache first
    cached_result, cached_confidence = get_cached_analysis(query_hash)
    if cached_result:
        return json.loads(cached_result), cached_confidence
    
    try:
        # Prepare context for AI analysis
        context = f"""
        You are an expert computational biologist specializing in antimicrobial drug discovery.
        Analyze the following data using a multi-evidence approach:

        COMPOUND DATA:
        - Name: {compound_data.get('name', 'Unknown')}
        - Chemical Formula: {compound_data.get('formula', 'Unknown')}
        - Molecular Weight: {compound_data.get('molecular_weight', 'Unknown')}
        - Chemical Class: {compound_data.get('chemical_class', 'Unknown')}
        - Known Activity: {compound_data.get('biological_activity', 'Unknown')}

        PATHOGEN INFORMATION:
        - Species: {pathogen_info.get('name', 'Unknown')}
        - Type: {pathogen_info.get('type', 'Unknown')}
        - Known Resistance: {pathogen_info.get('resistance_profile', 'Unknown')}

        WOUND CHARACTERISTICS:
        - Type: {wound_characteristics.get('type', 'Unknown')}
        - Environment: {wound_characteristics.get('environment', 'Unknown')}
        - Healing Stage: {wound_characteristics.get('healing_stage', 'Unknown')}

        Provide analysis in JSON format with the following structure:
        {{
            "overall_score": <0-100 integer>,
            "evidence_scores": {{
                "qsar_prediction": <0-100 integer>,
                "literature_support": <0-100 integer>,
                "admet_favorability": <0-100 integer>,
                "formulation_feasibility": <0-100 integer>
            }},
            "confidence_assessment": {{
                "overall_confidence": <0-1 decimal>,
                "data_quality": "high|medium|low",
                "evidence_strength": "strong|moderate|weak"
            }},
            "predictions": {{
                "mic_range_estimate": "<range in µg/mL or 'insufficient_data'>",
                "skin_penetration": "high|medium|low|unknown",
                "safety_profile": "favorable|concerning|unknown"
            }},
            "uncertainties": [
                "list of identified uncertainties and data gaps"
            ],
            "recommended_experiments": [
                "list of suggested next experimental steps"
            ],
            "literature_gaps": [
                "specific areas needing more research"
            ],
            "assumptions": [
                "transparent list of assumptions made"
            ]
        }}

        IMPORTANT: Base your analysis on established scientific principles. If data is insufficient,
        clearly state uncertainties and do not make unfounded claims. Treat computational predictions
        as hypothesis generation tools, not definitive proof of efficacy.
        """

        response = openai_client.chat.completions.create(
            model="gpt-5",
            messages=[
                {
                    "role": "system",
                    "content": "You are a scientific AI assistant. Provide evidence-based analysis with clear uncertainty quantification. Always maintain scientific rigor and transparency."
                },
                {
                    "role": "user",
                    "content": context
                }
            ],
            response_format={"type": "json_object"},
            temperature=0.1  # Low temperature for consistent scientific analysis
        )

        result = json.loads(response.choices[0].message.content)
        confidence_score = result.get('confidence_assessment', {}).get('overall_confidence', 0.5)
        
        # Cache the result
        cache_analysis_result(query_hash, query_params, result, confidence_score)
        
        return result, confidence_score

    except Exception as e:
        st.error(f"AI analysis error: {str(e)}")
        return {
            "error": "Analysis failed",
            "message": str(e),
            "overall_score": 0,
            "confidence_assessment": {"overall_confidence": 0.0}
        }, 0.0

def generate_formulation_recommendations(plant_compounds, wound_type, target_pathogens):
    """
    Generate formulation recommendations for wound treatment
    
    Args:
        plant_compounds: List of dictionaries with compound information
        wound_type: String describing wound type
        target_pathogens: List of target pathogen names
    
    Returns:
        Dictionary with formulation recommendations
    """
    
    try:
        compounds_context = "\n".join([
            f"- {comp.get('name', 'Unknown')}: {comp.get('concentration', 'Unknown')} "
            f"(Activity: {comp.get('activity', 'Unknown')})"
            for comp in plant_compounds
        ])
        
        pathogens_context = ", ".join(target_pathogens)
        
        context = f"""
        Design a wound treatment formulation using the following phytochemicals:

        AVAILABLE COMPOUNDS:
        {compounds_context}

        TARGET WOUND TYPE: {wound_type}
        TARGET PATHOGENS: {pathogens_context}

        Provide formulation recommendations in JSON format:
        {{
            "primary_actives": [
                {{
                    "compound": "compound_name",
                    "concentration_percent": <number>,
                    "rationale": "scientific justification"
                }}
            ],
            "formulation_base": {{
                "vehicle": "recommended base (gel, cream, ointment, etc.)",
                "rationale": "why this base is suitable",
                "additional_excipients": ["list of recommended excipients"]
            }},
            "stability_considerations": [
                "factors affecting formulation stability"
            ],
            "application_guidelines": {{
                "frequency": "recommended application frequency",
                "duration": "suggested treatment duration",
                "precautions": ["safety precautions"]
            }},
            "expected_efficacy": {{
                "antimicrobial_spectrum": ["list of likely susceptible pathogens"],
                "healing_promotion": "description of wound healing benefits",
                "onset_of_action": "estimated time to see effects"
            }},
            "limitations": [
                "acknowledged limitations of the formulation"
            ],
            "quality_control": [
                "recommended quality control tests"
            ],
            "regulatory_considerations": [
                "regulatory pathway considerations"
            ]
        }}

        Base recommendations on established pharmaceutical principles and phytochemical properties.
        Consider stability, bioavailability, and safety in your recommendations.
        """

        response = openai_client.chat.completions.create(
            model="gpt-5",
            messages=[
                {
                    "role": "system",
                    "content": "You are an expert pharmaceutical formulation scientist with expertise in phytochemical formulations. Provide scientifically sound formulation recommendations."
                },
                {
                    "role": "user",
                    "content": context
                }
            ],
            response_format={"type": "json_object"},
            temperature=0.1
        )

        return json.loads(response.choices[0].message.content)

    except Exception as e:
        st.error(f"Formulation recommendation error: {str(e)}")
        return {"error": "Failed to generate formulation recommendations", "message": str(e)}

def predict_drug_drug_interactions(compounds_list):
    """
    Predict potential drug-drug interactions between compounds
    
    Args:
        compounds_list: List of compound dictionaries
    
    Returns:
        Dictionary with interaction predictions
    """
    
    try:
        compounds_info = "\n".join([
            f"- {comp.get('name', 'Unknown')}: {comp.get('chemical_class', 'Unknown class')} "
            f"(MW: {comp.get('molecular_weight', 'Unknown')})"
            for comp in compounds_list
        ])
        
        context = f"""
        Analyze potential interactions between these phytochemicals:

        COMPOUNDS TO ANALYZE:
        {compounds_info}

        Provide interaction analysis in JSON format:
        {{
            "interaction_risk": "low|medium|high",
            "potential_interactions": [
                {{
                    "compound_pair": ["compound1", "compound2"],
                    "interaction_type": "synergistic|antagonistic|additive|unknown",
                    "mechanism": "description of interaction mechanism",
                    "clinical_significance": "description of potential clinical impact",
                    "confidence": <0-1 decimal>
                }}
            ],
            "safety_assessment": {{
                "overall_safety": "description of overall safety profile",
                "contraindications": ["list of potential contraindications"],
                "monitoring_parameters": ["parameters to monitor"]
            }},
            "dosing_considerations": [
                "factors to consider for dosing adjustments"
            ],
            "research_gaps": [
                "areas needing more interaction research"
            ]
        }}

        Base analysis on known pharmacological principles and chemical structure relationships.
        Clearly indicate when data is limited or predictions are uncertain.
        """

        response = openai_client.chat.completions.create(
            model="gpt-5",
            messages=[
                {
                    "role": "system",
                    "content": "You are a clinical pharmacologist with expertise in drug interactions and phytochemical safety. Provide evidence-based interaction analysis."
                },
                {
                    "role": "user",
                    "content": context
                }
            ],
            response_format={"type": "json_object"},
            temperature=0.1
        )

        return json.loads(response.choices[0].message.content)

    except Exception as e:
        st.error(f"Drug interaction analysis error: {str(e)}")
        return {"error": "Failed to analyze drug interactions", "message": str(e)}
