import psycopg2
import pandas as pd
import os
from contextlib import contextmanager
import streamlit as st

def get_database_connection():
    """Get database connection using environment variables"""
    try:
        conn = psycopg2.connect(
            host=os.getenv("PGHOST", "localhost"),
            database=os.getenv("PGDATABASE", "antimicrobial_db"),
            user=os.getenv("PGUSER", "postgres"),
            password=os.getenv("PGPASSWORD", ""),
            port=os.getenv("PGPORT", "5432")
        )
        return conn
    except psycopg2.Error as e:
        st.error(f"Database connection error: {str(e)}")
        return None

@contextmanager
def get_db_cursor():
    """Context manager for database operations"""
    conn = get_database_connection()
    if conn is None:
        yield None
        return
    
    cursor = None
    try:
        cursor = conn.cursor()
        yield cursor
        conn.commit()
    except Exception as e:
        # Check if connection is still alive before attempting rollback
        try:
            if conn and not conn.closed:
                conn.rollback()
        except:
            pass  # Connection is already closed, ignore rollback error
        st.error(f"Database operation error: {str(e)}")
        yield None
    finally:
        try:
            if cursor:
                cursor.close()
            if conn and not conn.closed:
                conn.close()
        except:
            pass  # Connection may already be closed

def init_database():
    """Initialize database tables"""
    with get_db_cursor() as cursor:
        if cursor is None:
            return False
        
        try:
            # Plants table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS plants (
                    id SERIAL PRIMARY KEY,
                    scientific_name VARCHAR(255) UNIQUE NOT NULL,
                    common_name VARCHAR(255),
                    family VARCHAR(255),
                    traditional_use TEXT,
                    safety_profile TEXT,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            """)
            
            # Phytochemicals table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS phytochemicals (
                    id SERIAL PRIMARY KEY,
                    name VARCHAR(255) NOT NULL,
                    chemical_formula VARCHAR(255),
                    molecular_weight DECIMAL(10,4),
                    smiles TEXT,
                    chemical_class VARCHAR(255),
                    biological_activity TEXT,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            """)
            
            # Plant-phytochemical relationships
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS plant_compounds (
                    id SERIAL PRIMARY KEY,
                    plant_id INTEGER REFERENCES plants(id) ON DELETE CASCADE,
                    phytochemical_id INTEGER REFERENCES phytochemicals(id) ON DELETE CASCADE,
                    concentration_range VARCHAR(255),
                    extraction_method VARCHAR(255),
                    reference_study VARCHAR(500),
                    UNIQUE(plant_id, phytochemical_id)
                )
            """)
            
            # Antimicrobial activity data
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS antimicrobial_activity (
                    id SERIAL PRIMARY KEY,
                    compound_id INTEGER REFERENCES phytochemicals(id) ON DELETE CASCADE,
                    pathogen_name VARCHAR(255) NOT NULL,
                    pathogen_type VARCHAR(100), -- bacteria, fungus, virus
                    mic_value DECIMAL(10,6), -- µg/mL
                    zoi_value DECIMAL(6,2), -- mm
                    test_method VARCHAR(255),
                    reference_doi VARCHAR(255),
                    confidence_score DECIMAL(3,2),
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            """)
            
            # ADMET properties
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS admet_properties (
                    id SERIAL PRIMARY KEY,
                    compound_id INTEGER REFERENCES phytochemicals(id) ON DELETE CASCADE,
                    absorption DECIMAL(5,3),
                    distribution DECIMAL(5,3),
                    metabolism TEXT,
                    excretion TEXT,
                    toxicity_score DECIMAL(5,3),
                    skin_permeability DECIMAL(10,6),
                    solubility DECIMAL(10,6),
                    predicted BOOLEAN DEFAULT TRUE,
                    prediction_confidence DECIMAL(3,2)
                )
            """)
            
            # Molecular docking results
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS docking_results (
                    id SERIAL PRIMARY KEY,
                    compound_id INTEGER REFERENCES phytochemicals(id) ON DELETE CASCADE,
                    target_protein VARCHAR(255),
                    binding_affinity DECIMAL(8,3), -- kcal/mol
                    rmsd DECIMAL(6,3),
                    docking_software VARCHAR(100),
                    protein_pdb_id VARCHAR(10),
                    ligand_efficiency DECIMAL(6,3),
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            """)
            
            # Wound types and characteristics
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS wound_types (
                    id SERIAL PRIMARY KEY,
                    wound_type VARCHAR(255) UNIQUE NOT NULL,
                    description TEXT,
                    common_pathogens TEXT[], -- Array of pathogen names
                    healing_factors TEXT[], -- Array of important healing factors
                    formulation_requirements TEXT
                )
            """)
            
            # Scientific literature references
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS literature_references (
                    id SERIAL PRIMARY KEY,
                    doi VARCHAR(255) UNIQUE,
                    title TEXT NOT NULL,
                    authors TEXT,
                    journal VARCHAR(255),
                    publication_year INTEGER,
                    abstract TEXT,
                    study_type VARCHAR(100), -- in_vitro, in_vivo, clinical_trial, review
                    confidence_rating INTEGER CHECK (confidence_rating >= 1 AND confidence_rating <= 5),
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            """)
            
            # AI analysis results cache
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS ai_analysis_cache (
                    id SERIAL PRIMARY KEY,
                    query_hash VARCHAR(64) UNIQUE NOT NULL,
                    query_parameters JSONB,
                    analysis_result JSONB,
                    confidence_score DECIMAL(3,2),
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    expires_at TIMESTAMP
                )
            """)
            
            return True
            
        except psycopg2.Error as e:
            st.error(f"Database initialization error: {str(e)}")
            return False

def execute_query(query, params=None):
    """Execute a SELECT query and return results as DataFrame"""
    with get_db_cursor() as cursor:
        if cursor is None:
            return pd.DataFrame()
        
        try:
            cursor.execute(query, params)
            columns = [desc[0] for desc in cursor.description]
            data = cursor.fetchall()
            return pd.DataFrame(data, columns=columns)
        except Exception as e:
            st.error(f"Query execution error: {str(e)}")
            return pd.DataFrame()

def insert_data(table, data_dict):
    """Insert data into specified table"""
    with get_db_cursor() as cursor:
        if cursor is None:
            return False
        
        try:
            columns = list(data_dict.keys())
            values = list(data_dict.values())
            placeholders = ', '.join(['%s'] * len(values))
            
            query = f"""
                INSERT INTO {table} ({', '.join(columns)})
                VALUES ({placeholders})
                RETURNING id
            """
            
            cursor.execute(query, values)
            return cursor.fetchone()[0]
            
        except Exception as e:
            st.error(f"Data insertion error: {str(e)}")
            return False

def update_data(table, data_dict, condition_dict):
    """Update data in specified table"""
    with get_db_cursor() as cursor:
        if cursor is None:
            return False
        
        try:
            set_clause = ', '.join([f"{k} = %s" for k in data_dict.keys()])
            where_clause = ' AND '.join([f"{k} = %s" for k in condition_dict.keys()])
            
            query = f"""
                UPDATE {table}
                SET {set_clause}
                WHERE {where_clause}
            """
            
            values = list(data_dict.values()) + list(condition_dict.values())
            cursor.execute(query, values)
            return cursor.rowcount > 0
            
        except Exception as e:
            st.error(f"Data update error: {str(e)}")
            return False
